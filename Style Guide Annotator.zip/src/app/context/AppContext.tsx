import React, { createContext, useContext, useState, useCallback } from "react";

export interface Attribute {
  id: string;
  name: string;
  type: "text" | "boolean" | "select" | "numeric";
  description: string;
  validationRule?: string;
  exampleFromStyleGuide?: string;
  usageCount: number;
}

export interface ImageItem {
  id: string;
  pdfName: string;
  pageNumber: number;
  imageUrl: string;
  thumbUrl: string;
}

export interface Annotation {
  imageId: string;
  checkedAttributes: string[];
  missingAttributes: string;
  notes: string;
  savedAt?: string;
}

interface AppState {
  folderPath: string;
  setFolderPath: (path: string) => void;
  pdfCount: number;
  setPdfCount: (n: number) => void;
  images: ImageItem[];
  currentIndex: number;
  setCurrentIndex: (i: number) => void;
  annotations: Record<string, Annotation>;
  saveAnnotation: (ann: Annotation) => void;
  attributes: Attribute[];
  setAttributes: React.Dispatch<React.SetStateAction<Attribute[]>>;
  processingComplete: boolean;
  setProcessingComplete: (v: boolean) => void;
  exportComplete: boolean;
  setExportComplete: (v: boolean) => void;
}

const SAMPLE_IMAGES: ImageItem[] = [
  {
    id: "img-001",
    pdfName: "BrandGuidelines_2024.pdf",
    pageNumber: 4,
    imageUrl: "https://images.unsplash.com/photo-1761896902115-49793a359daf?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxmYXNoaW9uJTIwc3R5bGUlMjBndWlkZSUyMGNsb3RoaW5nJTIwY2F0YWxvZ3xlbnwxfHx8fDE3NzYzNDAzMDl8MA&ixlib=rb-4.1.0&q=80&w=1080",
    thumbUrl: "https://images.unsplash.com/photo-1761896902115-49793a359daf?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxmYXNoaW9uJTIwc3R5bGUlMjBndWlkZSUyMGNsb3RoaW5nJTIwY2F0YWxvZ3xlbnwxfHx8fDE3NzYzNDAzMDl8MA&ixlib=rb-4.1.0&q=80&w=400",
  },
  {
    id: "img-002",
    pdfName: "ColorPalette_Spring2024.pdf",
    pageNumber: 2,
    imageUrl: "https://images.unsplash.com/photo-1771335976693-8c70d24acebb?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxwcm9kdWN0JTIwZGVzaWduJTIwY29sb3IlMjBwYWxldHRlJTIwYnJhbmRpbmd8ZW58MXx8fHwxNzc2MzQwMzA5fDA&ixlib=rb-4.1.0&q=80&w=1080",
    thumbUrl: "https://images.unsplash.com/photo-1771335976693-8c70d24acebb?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxwcm9kdWN0JTIwZGVzaWduJTIwY29sb3IlMjBwYWxldHRlJTIwYnJhbmRpbmd8ZW58MXx8fHwxNzc2MzQwMzA5fDA&ixlib=rb-4.1.0&q=80&w=400",
  },
  {
    id: "img-003",
    pdfName: "Typography_Standards.pdf",
    pageNumber: 7,
    imageUrl: "https://images.unsplash.com/photo-1769836074206-d4ed294895de?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx0eXBvZ3JhcGh5JTIwZm9udCUyMGRlc2lnbiUyMGxheW91dHxlbnwxfHx8fDE3NzYzNDAzMDl8MA&ixlib=rb-4.1.0&q=80&w=1080",
    thumbUrl: "https://images.unsplash.com/photo-1769836074206-d4ed294895de?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx0eXBvZ3JhcGh5JTIwZm9udCUyMGRlc2lnbiUyMGxheW91dHxlbnwxfHx8fDE3NzYzNDAzMDl8MA&ixlib=rb-4.1.0&q=80&w=400",
  },
];

const SAMPLE_ATTRIBUTES: Attribute[] = [
  { id: "attr-01", name: "Primary Color", type: "text", description: "Main color used in the image", validationRule: "Hex or named color", exampleFromStyleGuide: "#1A2B3C", usageCount: 42 },
  { id: "attr-02", name: "Secondary Color", type: "text", description: "Supporting color used alongside primary", validationRule: "Hex or named color", exampleFromStyleGuide: "#E5E7EB", usageCount: 38 },
  { id: "attr-03", name: "Typography Present", type: "boolean", description: "Image contains visible text or type treatment", usageCount: 71 },
  { id: "attr-04", name: "Logo Visible", type: "boolean", description: "Brand logo is present in the image", usageCount: 29 },
  { id: "attr-05", name: "Background Style", type: "select", description: "Type of background used (solid, gradient, textured, transparent)", exampleFromStyleGuide: "solid white", usageCount: 55 },
  { id: "attr-06", name: "Image Orientation", type: "select", description: "Portrait, landscape, or square", usageCount: 83 },
  { id: "attr-07", name: "Mood / Tone", type: "text", description: "Emotional tone of the image (e.g. minimal, bold, warm)", usageCount: 20 },
  { id: "attr-08", name: "Contains People", type: "boolean", description: "Whether the image shows human figures or faces", usageCount: 18 },
  { id: "attr-09", name: "Grid / Layout Pattern", type: "text", description: "Structural layout pattern used (e.g. 2-column, hero, card)", usageCount: 14 },
  { id: "attr-10", name: "Asset Type", type: "select", description: "Category of visual asset (photo, illustration, icon, diagram)", usageCount: 61 },
  { id: "attr-11", name: "Brand Tier", type: "select", description: "Which brand tier or product line this image belongs to", usageCount: 9 },
  { id: "attr-12", name: "Annotation Confidence", type: "numeric", description: "Reviewer confidence score 1–5", usageCount: 46 },
];

const AppContext = createContext<AppState | null>(null);

export function AppProvider({ children }: { children: React.ReactNode }) {
  const [folderPath, setFolderPath] = useState("/Users/designer/StyleGuides");
  const [pdfCount, setPdfCount] = useState(0);
  const [images] = useState<ImageItem[]>(SAMPLE_IMAGES);
  const [currentIndex, setCurrentIndex] = useState(0);
  const [annotations, setAnnotations] = useState<Record<string, Annotation>>({});
  const [attributes, setAttributes] = useState<Attribute[]>(SAMPLE_ATTRIBUTES);
  const [processingComplete, setProcessingComplete] = useState(false);
  const [exportComplete, setExportComplete] = useState(false);

  const saveAnnotation = useCallback((ann: Annotation) => {
    setAnnotations((prev) => ({
      ...prev,
      [ann.imageId]: { ...ann, savedAt: new Date().toISOString() },
    }));
  }, []);

  return (
    <AppContext.Provider
      value={{
        folderPath,
        setFolderPath,
        pdfCount,
        setPdfCount,
        images,
        currentIndex,
        setCurrentIndex,
        annotations,
        saveAnnotation,
        attributes,
        setAttributes,
        processingComplete,
        setProcessingComplete,
        exportComplete,
        setExportComplete,
      }}
    >
      {children}
    </AppContext.Provider>
  );
}

export function useApp() {
  const ctx = useContext(AppContext);
  if (!ctx) throw new Error("useApp must be used within AppProvider");
  return ctx;
}
