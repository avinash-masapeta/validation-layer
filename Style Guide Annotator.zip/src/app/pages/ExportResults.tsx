import React, { useState } from "react";
import {
  Download,
  FileSpreadsheet,
  CheckCircle2,
  FileText,
  Image as ImageIcon,
  Tag,
  Sparkles,
  Loader2,
  Eye,
  BarChart2,
} from "lucide-react";
import { useApp } from "../context/AppContext";

export function ExportResults() {
  const { images, annotations, attributes } = useApp();
  const [exporting, setExporting] = useState(false);
  const [exported, setExported] = useState(false);
  const [exportedFile, setExportedFile] = useState("");

  const reviewedCount = Object.keys(annotations).length;
  const totalAttrsUsed = Object.values(annotations).reduce(
    (sum, ann) => sum + ann.checkedAttributes.length,
    0
  );
  const newAttrsCount = Object.values(annotations).filter(
    (ann) => ann.missingAttributes && ann.missingAttributes.trim() !== ""
  ).length;

  const summaryCards = [
    {
      label: "PDFs Processed",
      value: 3,
      icon: FileText,
      color: "bg-blue-50 text-blue-600",
      iconBg: "bg-blue-100",
    },
    {
      label: "Images Reviewed",
      value: reviewedCount,
      icon: ImageIcon,
      color: "bg-green-50 text-green-600",
      iconBg: "bg-green-100",
    },
    {
      label: "Annotations Captured",
      value: totalAttrsUsed,
      icon: Tag,
      color: "bg-purple-50 text-purple-600",
      iconBg: "bg-purple-100",
    },
    {
      label: "New Attributes Identified",
      value: newAttrsCount,
      icon: Sparkles,
      color: "bg-amber-50 text-amber-700",
      iconBg: "bg-amber-100",
    },
  ];

  function handleExport() {
    setExporting(true);
    setTimeout(() => {
      setExporting(false);
      setExported(true);
      const date = new Date().toISOString().slice(0, 10).replace(/-/g, "");
      setExportedFile(`attribute_annotations_${date}.xlsx`);
    }, 2200);
  }

  const annotatedImages = images.filter((img) => annotations[img.id]);
  const skippedImages = images.filter((img) => !annotations[img.id]);

  return (
    <div className="h-full overflow-y-auto bg-gray-50">
      <div className="max-w-[900px] mx-auto px-6 py-8">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-gray-900 mb-2 flex items-center gap-3" style={{ fontSize: 26, fontWeight: 600 }}>
            <div className="w-8 h-8 rounded-lg bg-blue-600 flex items-center justify-center">
              <Download className="w-4 h-4 text-white" />
            </div>
            Export Results
          </h1>
          <p className="text-[15px] text-gray-500">
            Review your annotation summary and export the results to Excel.
          </p>
        </div>

        {/* Summary cards */}
        <div className="grid grid-cols-4 gap-4 mb-6">
          {summaryCards.map((card, i) => {
            const Icon = card.icon;
            return (
              <div key={i} className="bg-white rounded-xl border border-gray-200 shadow-sm p-5">
                <div className={`w-9 h-9 rounded-lg ${card.iconBg} flex items-center justify-center mb-3`}>
                  <Icon className={`w-5 h-5 ${card.color.split(" ")[1]}`} />
                </div>
                <p className="text-gray-900 font-semibold mb-1" style={{ fontSize: 28 }}>
                  {card.value}
                </p>
                <p className="text-[13px] text-gray-500">{card.label}</p>
              </div>
            );
          })}
        </div>

        {/* Annotation detail table */}
        <div className="bg-white rounded-xl border border-gray-200 shadow-sm overflow-hidden mb-6">
          <div className="px-5 py-4 border-b border-gray-100 flex items-center justify-between">
            <div>
              <h3 className="text-[15px] font-semibold text-gray-800 flex items-center gap-2">
                <BarChart2 className="w-4 h-4 text-blue-500" />
                Annotation Summary
              </h3>
              <p className="text-[13px] text-gray-400 mt-0.5">
                Per-image breakdown of annotation status
              </p>
            </div>
            <span className="text-[13px] text-gray-500">
              {reviewedCount} / {images.length} images annotated
            </span>
          </div>

          {images.length === 0 ? (
            <div className="px-5 py-10 text-center text-[14px] text-gray-400">
              No images have been extracted yet. Go through the load and review steps first.
            </div>
          ) : (
            <table className="w-full text-left">
              <thead className="bg-gray-50 border-b border-gray-100">
                <tr>
                  <th className="px-5 py-3 text-[12px] font-semibold text-gray-500 uppercase tracking-wide">Image ID</th>
                  <th className="px-4 py-3 text-[12px] font-semibold text-gray-500 uppercase tracking-wide">PDF Source</th>
                  <th className="px-4 py-3 text-[12px] font-semibold text-gray-500 uppercase tracking-wide">Attributes Tagged</th>
                  <th className="px-4 py-3 text-[12px] font-semibold text-gray-500 uppercase tracking-wide">Notes</th>
                  <th className="px-4 py-3 text-[12px] font-semibold text-gray-500 uppercase tracking-wide">Status</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-100">
                {images.map((img) => {
                  const ann = annotations[img.id];
                  const attrsTagged = ann ? ann.checkedAttributes.length : 0;
                  const attrNames = ann
                    ? ann.checkedAttributes
                        .map((id) => attributes.find((a) => a.id === id)?.name)
                        .filter(Boolean)
                        .slice(0, 3)
                        .join(", ")
                    : "";
                  const hasMore = ann && ann.checkedAttributes.length > 3;

                  return (
                    <tr key={img.id} className="hover:bg-gray-50 transition-colors">
                      <td className="px-5 py-3.5">
                        <span className="text-[13px] font-mono text-blue-600">{img.id}</span>
                      </td>
                      <td className="px-4 py-3.5">
                        <p className="text-[13px] text-gray-700">{img.pdfName}</p>
                        <p className="text-[12px] text-gray-400">Page {img.pageNumber}</p>
                      </td>
                      <td className="px-4 py-3.5">
                        {attrsTagged > 0 ? (
                          <div>
                            <p className="text-[13px] text-gray-700">
                              {attrNames}
                              {hasMore && <span className="text-gray-400"> +{ann!.checkedAttributes.length - 3} more</span>}
                            </p>
                            <p className="text-[12px] text-blue-500 mt-0.5">{attrsTagged} attributes</p>
                          </div>
                        ) : (
                          <span className="text-[13px] text-gray-300">—</span>
                        )}
                      </td>
                      <td className="px-4 py-3.5">
                        {ann?.notes ? (
                          <p className="text-[13px] text-gray-600 line-clamp-1 max-w-[160px]">{ann.notes}</p>
                        ) : (
                          <span className="text-[13px] text-gray-300">—</span>
                        )}
                      </td>
                      <td className="px-4 py-3.5">
                        {ann ? (
                          <span className="inline-flex items-center gap-1 text-[12px] text-green-700 bg-green-50 px-2.5 py-1 rounded-full">
                            <CheckCircle2 className="w-3 h-3" />
                            Annotated
                          </span>
                        ) : (
                          <span className="inline-flex items-center gap-1 text-[12px] text-amber-600 bg-amber-50 px-2.5 py-1 rounded-full">
                            Pending
                          </span>
                        )}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          )}
        </div>

        {/* Export card */}
        <div className="bg-white rounded-xl border border-gray-200 shadow-sm overflow-hidden">
          <div className="px-5 py-4 border-b border-gray-100">
            <h3 className="text-[15px] font-semibold text-gray-800">Export to Excel</h3>
            <p className="text-[13px] text-gray-500 mt-0.5">
              Generate an Excel file with all annotation data, attribute mappings, and image metadata
            </p>
          </div>
          <div className="px-5 py-5">
            {/* What's included */}
            <div className="mb-5 grid grid-cols-2 gap-3">
              {[
                "All annotated image IDs and PDF sources",
                "Checked canonical attributes per image",
                "Free-text missing/new attributes",
                "Reviewer notes and timestamps",
                "Attribute usage statistics",
                "Skipped image list",
              ].map((item, i) => (
                <div key={i} className="flex items-start gap-2 text-[13px] text-gray-600">
                  <CheckCircle2 className="w-4 h-4 text-green-500 shrink-0 mt-0.5" />
                  {item}
                </div>
              ))}
            </div>

            {exported ? (
              <div>
                <div className="flex items-center gap-4 p-4 bg-green-50 border border-green-100 rounded-xl mb-4">
                  <div className="w-10 h-10 rounded-lg bg-green-100 flex items-center justify-center shrink-0">
                    <FileSpreadsheet className="w-5 h-5 text-green-600" />
                  </div>
                  <div className="flex-1">
                    <p className="text-[14px] font-semibold text-green-800">Export Complete!</p>
                    <p className="text-[13px] text-green-700 mt-0.5">
                      File generated: <span className="font-mono">{exportedFile}</span>
                    </p>
                  </div>
                  <CheckCircle2 className="w-6 h-6 text-green-500 shrink-0" />
                </div>
                <div className="flex gap-3">
                  <button className="flex items-center gap-2 px-5 py-2.5 bg-green-600 text-white rounded-lg text-[14px] font-medium hover:bg-green-700 transition-colors">
                    <Download className="w-4 h-4" />
                    Download {exportedFile}
                  </button>
                  <button
                    onClick={() => { setExported(false); setExportedFile(""); }}
                    className="flex items-center gap-2 px-4 py-2.5 border border-gray-200 rounded-lg text-[14px] font-medium text-gray-600 hover:bg-gray-50 transition-colors"
                  >
                    <Eye className="w-4 h-4" />
                    Export Again
                  </button>
                </div>
              </div>
            ) : (
              <button
                onClick={handleExport}
                disabled={exporting || reviewedCount === 0}
                className="flex items-center gap-2 px-6 py-3 bg-blue-600 text-white rounded-lg text-[14px] font-semibold hover:bg-blue-700 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
              >
                {exporting ? (
                  <>
                    <Loader2 className="w-4 h-4 animate-spin" />
                    Generating Excel file…
                  </>
                ) : (
                  <>
                    <FileSpreadsheet className="w-4 h-4" />
                    Save Results to Excel
                  </>
                )}
              </button>
            )}
            {reviewedCount === 0 && !exporting && !exported && (
              <p className="text-[13px] text-amber-600 mt-3 flex items-center gap-1.5">
                <Eye className="w-4 h-4" />
                Review at least one image before exporting.
              </p>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
