import React, { useState } from "react";
import { useNavigate } from "react-router";
import { FolderOpen, FileText, ArrowRight, CheckCircle2, AlertCircle, ChevronRight } from "lucide-react";
import { useApp } from "../context/AppContext";

const SAMPLE_PDFS = [
  "BrandGuidelines_2024.pdf",
  "ColorPalette_Spring2024.pdf",
  "Typography_Standards.pdf",
];

export function Home() {
  const navigate = useNavigate();
  const { folderPath, setFolderPath, setPdfCount } = useApp();
  const [status, setStatus] = useState<"idle" | "ready" | "error">("idle");
  const [pdfList, setPdfList] = useState<string[]>([]);

  function handleBrowse() {
    setFolderPath("/Users/designer/StyleGuides/Q1_2024");
    setStatus("idle");
    setPdfList([]);
  }

  function handleReadPdfs() {
    if (!folderPath) {
      setStatus("error");
      return;
    }
    setStatus("ready");
    setPdfList(SAMPLE_PDFS);
    setPdfCount(SAMPLE_PDFS.length);
  }

  function handleContinue() {
    navigate("/processing");
  }

  return (
    <div className="min-h-screen bg-gray-50 flex flex-col">
      {/* Top bar */}
      <header className="bg-white border-b border-gray-200 px-8 h-[72px] flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 rounded-lg bg-blue-600 flex items-center justify-center">
            <FileText className="w-4 h-4 text-white" />
          </div>
          <div>
            <p className="text-[14px] font-semibold text-gray-900 leading-tight">Style Guide Annotator</p>
            <p className="text-[11px] text-gray-400 leading-tight">Image Attribute Annotation Tool</p>
          </div>
        </div>
        <div className="flex items-center gap-2 text-[13px] text-gray-400">
          <span className="px-2 py-1 bg-blue-50 text-blue-600 rounded text-[12px] font-medium">Step 1 of 3</span>
          <span>Load PDFs</span>
          <ChevronRight className="w-4 h-4" />
          <span className="text-gray-300">Process</span>
          <ChevronRight className="w-4 h-4 text-gray-300" />
          <span className="text-gray-300">Review</span>
          <div className="w-px h-4 bg-gray-200 mx-2" />
          <button
            onClick={() => navigate("/app/dashboard")}
            className="text-blue-600 hover:underline text-[13px] font-medium"
          >
            Skip to App →
          </button>
        </div>
      </header>

      {/* Content */}
      <div className="flex-1 flex items-start justify-center pt-16 px-8">
        <div className="w-full max-w-[720px]">
          {/* Page heading */}
          <div className="mb-8">
            <h1 className="text-gray-900 mb-2" style={{ fontSize: 28, fontWeight: 600 }}>
              Load Style Guide PDFs
            </h1>
            <p className="text-[15px] text-gray-500">
              Select the folder containing your style guide PDF files to begin the extraction and annotation process.
            </p>
          </div>

          {/* Main card */}
          <div className="bg-white rounded-xl border border-gray-200 shadow-sm overflow-hidden">
            <div className="px-6 py-5 border-b border-gray-100">
              <h2 className="text-[15px] font-semibold text-gray-800">Folder Selection</h2>
              <p className="text-[13px] text-gray-500 mt-0.5">Point the app to the folder containing your PDFs</p>
            </div>
            <div className="px-6 py-6 space-y-4">
              {/* Folder path input */}
              <div>
                <label className="block text-[13px] font-medium text-gray-700 mb-1.5">
                  Folder Path
                </label>
                <div className="flex gap-2">
                  <div className="flex-1 flex items-center gap-2 px-3 py-2.5 border border-gray-200 rounded-lg bg-gray-50 text-[14px] text-gray-700">
                    <FolderOpen className="w-4 h-4 text-gray-400 shrink-0" />
                    <span className="flex-1 truncate">{folderPath || "No folder selected"}</span>
                  </div>
                  <button
                    onClick={handleBrowse}
                    className="px-4 py-2.5 border border-gray-200 rounded-lg text-[14px] font-medium text-gray-700 bg-white hover:bg-gray-50 transition-colors whitespace-nowrap"
                  >
                    Browse…
                  </button>
                </div>
                <p className="text-[12px] text-gray-400 mt-1.5">
                  All PDF files in this folder (and subfolders) will be processed
                </p>
              </div>

              {/* Read button */}
              <div className="flex items-center gap-3 pt-2">
                <button
                  onClick={handleReadPdfs}
                  disabled={!folderPath}
                  className="flex items-center gap-2 px-5 py-2.5 bg-blue-600 text-white rounded-lg text-[14px] font-medium hover:bg-blue-700 disabled:opacity-40 disabled:cursor-not-allowed transition-colors"
                >
                  <FileText className="w-4 h-4" />
                  Read All PDFs
                </button>
                {status === "error" && (
                  <div className="flex items-center gap-1.5 text-[13px] text-red-600">
                    <AlertCircle className="w-4 h-4" />
                    Please select a valid folder first
                  </div>
                )}
              </div>
            </div>
          </div>

          {/* Status area */}
          {status === "ready" && (
            <div className="mt-4 bg-white rounded-xl border border-gray-200 shadow-sm overflow-hidden">
              <div className="px-6 py-5 border-b border-gray-100 flex items-center justify-between">
                <div>
                  <h2 className="text-[15px] font-semibold text-gray-800">Detection Results</h2>
                  <p className="text-[13px] text-gray-500 mt-0.5">PDFs found in the selected folder</p>
                </div>
                <div className="flex items-center gap-1.5 px-3 py-1.5 bg-green-50 text-green-700 rounded-full text-[13px] font-medium">
                  <CheckCircle2 className="w-3.5 h-3.5" />
                  {pdfList.length} PDFs ready
                </div>
              </div>
              <div className="divide-y divide-gray-100">
                {pdfList.map((pdf, i) => (
                  <div key={i} className="px-6 py-3.5 flex items-center gap-3">
                    <div className="w-7 h-7 rounded bg-red-50 flex items-center justify-center shrink-0">
                      <FileText className="w-4 h-4 text-red-500" />
                    </div>
                    <div className="flex-1">
                      <p className="text-[14px] text-gray-800 font-medium">{pdf}</p>
                      <p className="text-[12px] text-gray-400">Ready to process</p>
                    </div>
                    <span className="text-[12px] text-green-600 bg-green-50 px-2 py-0.5 rounded-full">
                      Detected
                    </span>
                  </div>
                ))}
              </div>
              <div className="px-6 py-4 bg-gray-50 border-t border-gray-100 flex items-center justify-between">
                <p className="text-[13px] text-gray-500">
                  <span className="font-semibold text-gray-700">{pdfList.length}</span> PDF files · Ready for image extraction
                </p>
                <button
                  onClick={handleContinue}
                  className="flex items-center gap-2 px-5 py-2.5 bg-blue-600 text-white rounded-lg text-[14px] font-medium hover:bg-blue-700 transition-colors"
                >
                  Continue to Processing
                  <ArrowRight className="w-4 h-4" />
                </button>
              </div>
            </div>
          )}

          {/* Empty state hint */}
          {status === "idle" && (
            <div className="mt-6 flex items-start gap-3 p-4 bg-blue-50 rounded-lg border border-blue-100">
              <AlertCircle className="w-4 h-4 text-blue-500 shrink-0 mt-0.5" />
              <div>
                <p className="text-[13px] font-medium text-blue-800">How it works</p>
                <p className="text-[13px] text-blue-700 mt-0.5">
                  Browse to a folder, click "Read All PDFs" to detect files, then proceed to the extraction step where images will be pulled from each PDF for annotation.
                </p>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
