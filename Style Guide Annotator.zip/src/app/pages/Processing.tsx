import React, { useState, useEffect } from "react";
import { useNavigate } from "react-router";
import {
  CheckCircle2,
  Loader2,
  Circle,
  ArrowRight,
  FileText,
  Image as ImageIcon,
  ChevronRight,
  ListChecks,
} from "lucide-react";
import { useApp } from "../context/AppContext";

type StepStatus = "pending" | "running" | "done";

interface Step {
  id: number;
  label: string;
  description: string;
  icon: React.ElementType;
}

const STEPS: Step[] = [
  { id: 0, label: "Reading PDFs", description: "Parsing PDF documents and extracting metadata", icon: FileText },
  { id: 1, label: "Extracting Images", description: "Pulling raster images from each page", icon: ImageIcon },
  { id: 2, label: "Preparing Review Queue", description: "Building annotation queue and deduplicating assets", icon: ListChecks },
];

export function Processing() {
  const navigate = useNavigate();
  const { pdfCount, images, setProcessingComplete } = useApp();
  const [statuses, setStatuses] = useState<StepStatus[]>(["pending", "pending", "pending"]);
  const [progress, setProgress] = useState(0);
  const [pdfsProcessed, setPdfsProcessed] = useState(0);
  const [imagesExtracted, setImagesExtracted] = useState(0);
  const [started, setStarted] = useState(false);
  const [complete, setComplete] = useState(false);

  const totalPdfs = Math.max(pdfCount, 3);
  const totalImages = images.length + 80;

  function startProcessing() {
    setStarted(true);
  }

  useEffect(() => {
    if (!started) return;

    // Step 0: Reading PDFs
    setStatuses(["running", "pending", "pending"]);
    let pdfInterval = setInterval(() => {
      setPdfsProcessed((prev) => {
        if (prev >= totalPdfs) {
          clearInterval(pdfInterval);
          return prev;
        }
        return prev + 1;
      });
    }, 300);

    let step1Timeout = setTimeout(() => {
      clearInterval(pdfInterval);
      setPdfsProcessed(totalPdfs);
      setStatuses(["done", "running", "pending"]);
      setProgress(33);

      // Step 1: Extracting images
      let imgInterval = setInterval(() => {
        setImagesExtracted((prev) => {
          if (prev >= totalImages) {
            clearInterval(imgInterval);
            return prev;
          }
          return prev + Math.floor(Math.random() * 5) + 1;
        });
        setProgress((p) => Math.min(p + 1.5, 66));
      }, 120);

      let step2Timeout = setTimeout(() => {
        clearInterval(imgInterval);
        setImagesExtracted(totalImages);
        setStatuses(["done", "done", "running"]);
        setProgress(66);

        // Step 2: Preparing queue
        let queueInterval = setInterval(() => {
          setProgress((p) => {
            if (p >= 100) {
              clearInterval(queueInterval);
              return 100;
            }
            return p + 2;
          });
        }, 80);

        let doneTimeout = setTimeout(() => {
          clearInterval(queueInterval);
          setProgress(100);
          setStatuses(["done", "done", "done"]);
          setComplete(true);
          setProcessingComplete(true);
        }, 1500);

        return () => { clearInterval(queueInterval); clearTimeout(doneTimeout); };
      }, 2500);

      return () => { clearInterval(imgInterval); clearTimeout(step2Timeout); };
    }, 1200);

    return () => { clearInterval(pdfInterval); clearTimeout(step1Timeout); };
  }, [started]);

  return (
    <div className="min-h-screen bg-gray-50 flex flex-col">
      {/* Top bar */}
      <header className="bg-white border-b border-gray-200 px-8 h-[72px] flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 rounded-lg bg-blue-600 flex items-center justify-center">
            <FileText className="w-4 h-4 text-white" />
          </div>
          <div>
            <p className="text-[14px] font-semibold text-gray-900 leading-tight">Style Guide Annotator</p>
            <p className="text-[11px] text-gray-400 leading-tight">Image Attribute Annotation Tool</p>
          </div>
        </div>
        <div className="flex items-center gap-2 text-[13px] text-gray-400">
          <span className="text-gray-400">Load PDFs</span>
          <ChevronRight className="w-4 h-4" />
          <span className="px-2 py-1 bg-blue-50 text-blue-600 rounded text-[12px] font-medium">Step 2 of 3</span>
          <span>Process</span>
          <ChevronRight className="w-4 h-4" />
          <span className="text-gray-300">Review</span>
        </div>
      </header>

      {/* Content */}
      <div className="flex-1 flex items-start justify-center pt-16 px-8">
        <div className="w-full max-w-[640px]">
          {/* Heading */}
          <div className="mb-8">
            <h1 className="text-gray-900 mb-2" style={{ fontSize: 28, fontWeight: 600 }}>
              Processing &amp; Extraction
            </h1>
            <p className="text-[15px] text-gray-500">
              Extracting images from your PDFs and building the annotation queue.
            </p>
          </div>

          {/* Progress card */}
          <div className="bg-white rounded-xl border border-gray-200 shadow-sm overflow-hidden mb-4">
            <div className="px-6 py-5 border-b border-gray-100 flex items-center justify-between">
              <div>
                <h2 className="text-[15px] font-semibold text-gray-800">Extraction Progress</h2>
                <p className="text-[13px] text-gray-500 mt-0.5">
                  {complete ? "All steps completed successfully" : started ? "Processing in progress…" : "Ready to start"}
                </p>
              </div>
              <span
                className={`text-[13px] font-semibold px-3 py-1 rounded-full ${
                  complete
                    ? "bg-green-50 text-green-700"
                    : started
                    ? "bg-blue-50 text-blue-700"
                    : "bg-gray-100 text-gray-500"
                }`}
              >
                {Math.round(progress)}%
              </span>
            </div>

            {/* Progress bar */}
            <div className="px-6 pt-5">
              <div className="h-2 bg-gray-100 rounded-full overflow-hidden mb-6">
                <div
                  className="h-full bg-blue-500 rounded-full transition-all duration-300"
                  style={{ width: `${progress}%` }}
                />
              </div>

              {/* Steps */}
              <div className="space-y-4 pb-5">
                {STEPS.map((step, i) => {
                  const status = statuses[i];
                  const Icon = step.icon;
                  return (
                    <div key={step.id} className="flex items-start gap-4">
                      <div className="shrink-0 mt-0.5">
                        {status === "done" ? (
                          <CheckCircle2 className="w-5 h-5 text-green-500" />
                        ) : status === "running" ? (
                          <Loader2 className="w-5 h-5 text-blue-500 animate-spin" />
                        ) : (
                          <Circle className="w-5 h-5 text-gray-300" />
                        )}
                      </div>
                      <div className="flex-1">
                        <div className="flex items-center justify-between">
                          <p
                            className={`text-[14px] font-medium ${
                              status === "done"
                                ? "text-green-700"
                                : status === "running"
                                ? "text-blue-700"
                                : "text-gray-400"
                            }`}
                          >
                            {step.label}
                          </p>
                          {status === "done" && (
                            <span className="text-[12px] text-green-600 bg-green-50 px-2 py-0.5 rounded-full">
                              Complete
                            </span>
                          )}
                          {status === "running" && (
                            <span className="text-[12px] text-blue-600 bg-blue-50 px-2 py-0.5 rounded-full">
                              Running…
                            </span>
                          )}
                        </div>
                        <p className="text-[13px] text-gray-400 mt-0.5">{step.description}</p>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          </div>

          {/* Counters */}
          <div className="grid grid-cols-2 gap-4 mb-6">
            <div className="bg-white rounded-xl border border-gray-200 shadow-sm px-5 py-4">
              <p className="text-[12px] text-gray-500 uppercase tracking-wide mb-1">PDFs Processed</p>
              <p className="text-gray-900 font-semibold" style={{ fontSize: 28 }}>
                {pdfsProcessed}
                <span className="text-[16px] font-normal text-gray-400"> / {totalPdfs}</span>
              </p>
            </div>
            <div className="bg-white rounded-xl border border-gray-200 shadow-sm px-5 py-4">
              <p className="text-[12px] text-gray-500 uppercase tracking-wide mb-1">Images Extracted</p>
              <p className="text-gray-900 font-semibold" style={{ fontSize: 28 }}>
                {imagesExtracted}
                <span className="text-[16px] font-normal text-gray-400"> found</span>
              </p>
            </div>
          </div>

          {/* Actions */}
          {!started && (
            <button
              onClick={startProcessing}
              className="w-full flex items-center justify-center gap-2 px-5 py-3 bg-blue-600 text-white rounded-lg text-[15px] font-medium hover:bg-blue-700 transition-colors"
            >
              Start Extraction
              <ArrowRight className="w-4 h-4" />
            </button>
          )}

          {started && !complete && (
            <div className="flex items-center justify-center gap-2 py-3 text-[14px] text-gray-500">
              <Loader2 className="w-4 h-4 animate-spin text-blue-500" />
              Processing, please wait…
            </div>
          )}

          {complete && (
            <button
              onClick={() => navigate("/app/review")}
              className="w-full flex items-center justify-center gap-2 px-5 py-3 bg-blue-600 text-white rounded-lg text-[15px] font-medium hover:bg-blue-700 transition-colors"
            >
              Go to Review
              <ArrowRight className="w-4 h-4" />
            </button>
          )}
        </div>
      </div>
    </div>
  );
}