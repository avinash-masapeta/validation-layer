import React, { useState, useEffect } from "react";
import {
  Search,
  ChevronLeft,
  ChevronRight,
  SkipForward,
  Save,
  Check,
  StickyNote,
  Tag,
  AlertCircle,
  CheckCircle2,
  ZoomIn,
} from "lucide-react";
import { useApp } from "../context/AppContext";

export function ReviewImages() {
  const {
    images,
    currentIndex,
    setCurrentIndex,
    annotations,
    saveAnnotation,
    attributes,
  } = useApp();

  const [searchQuery, setSearchQuery] = useState("");
  const [checkedAttrs, setCheckedAttrs] = useState<string[]>([]);
  const [missingAttrs, setMissingAttrs] = useState("");
  const [notes, setNotes] = useState("");
  const [savedFlash, setSavedFlash] = useState(false);
  const [previewZoom, setPreviewZoom] = useState(false);

  const currentImage = images[currentIndex];
  const currentAnnotation = currentImage ? annotations[currentImage.id] : undefined;
  const reviewedCount = Object.keys(annotations).length;
  const totalImages = images.length;

  // Load existing annotation when image changes
  useEffect(() => {
    if (currentAnnotation) {
      setCheckedAttrs(currentAnnotation.checkedAttributes);
      setMissingAttrs(currentAnnotation.missingAttributes);
      setNotes(currentAnnotation.notes);
    } else {
      setCheckedAttrs([]);
      setMissingAttrs("");
      setNotes("");
    }
    setSavedFlash(false);
    setSearchQuery("");
  }, [currentIndex]);

  const filteredAttributes = attributes.filter((attr) =>
    attr.name.toLowerCase().includes(searchQuery.toLowerCase())
  );

  function toggleAttr(id: string) {
    setCheckedAttrs((prev) =>
      prev.includes(id) ? prev.filter((a) => a !== id) : [...prev, id]
    );
  }

  function handleSave() {
    if (!currentImage) return;
    saveAnnotation({
      imageId: currentImage.id,
      checkedAttributes: checkedAttrs,
      missingAttributes: missingAttrs,
      notes,
    });
    setSavedFlash(true);
    setTimeout(() => setSavedFlash(false), 2000);
  }

  function handleSaveAndNext() {
    handleSave();
    if (currentIndex < images.length - 1) {
      setTimeout(() => setCurrentIndex(currentIndex + 1), 100);
    }
  }

  function handleSkip() {
    if (currentIndex < images.length - 1) {
      setCurrentIndex(currentIndex + 1);
    }
  }

  function handlePrev() {
    if (currentIndex > 0) setCurrentIndex(currentIndex - 1);
  }

  function handleNext() {
    if (currentIndex < images.length - 1) setCurrentIndex(currentIndex + 1);
  }

  const isEmpty = checkedAttrs.length === 0 && !missingAttrs && !notes;
  const progressPct = totalImages > 0 ? (reviewedCount / totalImages) * 100 : 0;

  return (
    <div className="flex flex-col h-full overflow-hidden">
      {/* Sub-header */}
      <div className="bg-white border-b border-gray-200 px-6 py-3 flex items-center justify-between shrink-0">
        <div>
          <h1 className="text-[17px] font-semibold text-gray-900">Review Images</h1>
          <p className="text-[13px] text-gray-500">Annotate each extracted image with relevant attributes</p>
        </div>
        {/* Progress indicator */}
        <div className="flex items-center gap-4">
          <div className="text-right">
            <p className="text-[13px] font-semibold text-gray-800">
              {reviewedCount} of {totalImages} reviewed
            </p>
            <div className="flex items-center gap-2 mt-1">
              <div className="w-32 h-1.5 bg-gray-100 rounded-full overflow-hidden">
                <div
                  className="h-full bg-blue-500 rounded-full transition-all"
                  style={{ width: `${progressPct}%` }}
                />
              </div>
              <span className="text-[12px] text-gray-400">{Math.round(progressPct)}%</span>
            </div>
          </div>
          {currentAnnotation && (
            <div className="flex items-center gap-1 text-[12px] text-green-600 bg-green-50 px-2.5 py-1 rounded-full">
              <CheckCircle2 className="w-3.5 h-3.5" />
              Saved
            </div>
          )}
        </div>
      </div>

      {/* Main layout */}
      <div className="flex flex-1 min-h-0 overflow-hidden">
        {/* Left metadata panel */}
        <div
          className="bg-white border-r border-gray-200 flex flex-col shrink-0 overflow-y-auto"
          style={{ width: 220 }}
        >
          <div className="p-4 border-b border-gray-100">
            <p className="text-[11px] font-semibold uppercase tracking-widest text-gray-400 mb-3">
              Image Info
            </p>
            {currentImage ? (
              <div className="space-y-2.5">
                <div>
                  <p className="text-[11px] text-gray-400">PDF File</p>
                  <p className="text-[13px] font-medium text-gray-800 break-words leading-tight mt-0.5">
                    {currentImage.pdfName}
                  </p>
                </div>
                <div>
                  <p className="text-[11px] text-gray-400">Page Number</p>
                  <p className="text-[13px] font-medium text-gray-800 mt-0.5">
                    Page {currentImage.pageNumber}
                  </p>
                </div>
                <div>
                  <p className="text-[11px] text-gray-400">Image ID</p>
                  <p className="text-[13px] font-mono text-blue-600 mt-0.5">{currentImage.id}</p>
                </div>
                <div>
                  <p className="text-[11px] text-gray-400">Status</p>
                  <div className="mt-0.5">
                    {currentAnnotation ? (
                      <span className="inline-flex items-center gap-1 text-[12px] text-green-700 bg-green-50 px-2 py-0.5 rounded-full">
                        <Check className="w-3 h-3" />
                        Annotated
                      </span>
                    ) : (
                      <span className="inline-flex items-center gap-1 text-[12px] text-amber-600 bg-amber-50 px-2 py-0.5 rounded-full">
                        <AlertCircle className="w-3 h-3" />
                        Pending
                      </span>
                    )}
                  </div>
                </div>
              </div>
            ) : (
              <p className="text-[13px] text-gray-400">No image selected</p>
            )}
          </div>

          {/* Navigation controls */}
          <div className="p-4">
            <p className="text-[11px] font-semibold uppercase tracking-widest text-gray-400 mb-3">
              Navigation
            </p>
            <div className="grid grid-cols-3 gap-2">
              <button
                onClick={handlePrev}
                disabled={currentIndex === 0}
                title="Previous"
                className="flex items-center justify-center p-2 rounded-lg border border-gray-200 text-gray-600 hover:bg-gray-50 disabled:opacity-30 disabled:cursor-not-allowed transition-colors"
              >
                <ChevronLeft className="w-4 h-4" />
              </button>
              <button
                onClick={handleSkip}
                disabled={currentIndex >= images.length - 1}
                title="Skip"
                className="flex items-center justify-center p-2 rounded-lg border border-gray-200 text-gray-600 hover:bg-gray-50 disabled:opacity-30 disabled:cursor-not-allowed transition-colors"
              >
                <SkipForward className="w-4 h-4" />
              </button>
              <button
                onClick={handleNext}
                disabled={currentIndex >= images.length - 1}
                title="Next"
                className="flex items-center justify-center p-2 rounded-lg border border-gray-200 text-gray-600 hover:bg-gray-50 disabled:opacity-30 disabled:cursor-not-allowed transition-colors"
              >
                <ChevronRight className="w-4 h-4" />
              </button>
            </div>
            <p className="text-[12px] text-gray-400 text-center mt-2">
              {currentIndex + 1} / {totalImages}
            </p>

            {/* Thumbnail strip */}
            <div className="mt-4 space-y-2">
              {images.map((img, i) => (
                <button
                  key={img.id}
                  onClick={() => setCurrentIndex(i)}
                  className={`w-full flex items-center gap-2 p-2 rounded-lg border transition-colors ${
                    i === currentIndex
                      ? "border-blue-300 bg-blue-50"
                      : "border-gray-100 hover:bg-gray-50"
                  }`}
                >
                  <div className="w-10 h-8 rounded overflow-hidden shrink-0 bg-gray-100">
                    <img src={img.thumbUrl} alt="" className="w-full h-full object-cover" />
                  </div>
                  <div className="text-left min-w-0">
                    <p className="text-[11px] font-medium text-gray-700 truncate">{img.id}</p>
                    <p className="text-[11px] text-gray-400 truncate">Pg {img.pageNumber}</p>
                  </div>
                  {annotations[img.id] && (
                    <Check className="w-3 h-3 text-green-500 shrink-0 ml-auto" />
                  )}
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* Center image preview */}
        <div className="flex-1 flex flex-col bg-gray-100 min-w-0 overflow-hidden">
          <div className="flex-1 flex items-center justify-center p-6 relative">
            {currentImage ? (
              <>
                <div
                  className={`relative bg-white rounded-xl shadow-md overflow-hidden transition-all duration-200 ${
                    previewZoom ? "scale-110" : "scale-100"
                  }`}
                  style={{ maxWidth: "100%", maxHeight: "100%" }}
                >
                  <img
                    src={currentImage.imageUrl}
                    alt={`Preview ${currentImage.id}`}
                    className="max-w-full max-h-full object-contain"
                    style={{ maxHeight: "calc(100vh - 280px)", display: "block" }}
                  />
                  {/* Zoom button */}
                  <button
                    onClick={() => setPreviewZoom(!previewZoom)}
                    className="absolute top-3 right-3 w-8 h-8 bg-white/90 backdrop-blur-sm rounded-lg shadow flex items-center justify-center text-gray-600 hover:bg-white transition-colors"
                  >
                    <ZoomIn className="w-4 h-4" />
                  </button>
                </div>
              </>
            ) : (
              <div className="text-center text-gray-400">
                <AlertCircle className="w-12 h-12 mx-auto mb-3 text-gray-300" />
                <p className="text-[15px]">No images available</p>
              </div>
            )}
          </div>

          {/* Image label bar */}
          {currentImage && (
            <div className="px-6 py-3 bg-white border-t border-gray-200 flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="w-2 h-2 bg-blue-500 rounded-full" />
                <span className="text-[13px] font-medium text-gray-700">{currentImage.pdfName}</span>
                <span className="text-[12px] text-gray-400">·</span>
                <span className="text-[13px] text-gray-500">Page {currentImage.pageNumber}</span>
                <span className="text-[12px] text-gray-400">·</span>
                <span className="text-[13px] font-mono text-gray-500">{currentImage.id}</span>
              </div>
              <div className="text-[13px] text-gray-400">
                Image {currentIndex + 1} of {totalImages}
              </div>
            </div>
          )}
        </div>

        {/* Right annotation panel */}
        <div
          className="bg-white border-l border-gray-200 flex flex-col shrink-0 overflow-hidden"
          style={{ width: 340 }}
        >
          {/* Panel header */}
          <div className="px-5 py-4 border-b border-gray-100">
            <div className="flex items-center gap-2">
              <Tag className="w-4 h-4 text-blue-500" />
              <h3 className="text-[15px] font-semibold text-gray-800">Annotations</h3>
            </div>
            <p className="text-[12px] text-gray-400 mt-0.5">
              {isEmpty ? "No annotations yet for this image" : `${checkedAttrs.length} attribute${checkedAttrs.length !== 1 ? "s" : ""} selected`}
            </p>
          </div>

          {/* Scrollable content */}
          <div className="flex-1 overflow-y-auto">
            {/* Attribute search */}
            <div className="px-4 pt-4 pb-2">
              <div className="flex items-center gap-2 px-3 py-2 border border-gray-200 rounded-lg bg-gray-50">
                <Search className="w-4 h-4 text-gray-400 shrink-0" />
                <input
                  type="text"
                  placeholder="Search attributes…"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="flex-1 bg-transparent text-[13px] text-gray-700 placeholder-gray-400 outline-none"
                />
              </div>
            </div>

            {/* Attributes header */}
            <div className="px-4 pb-2 pt-2">
              <p className="text-[11px] font-semibold uppercase tracking-widest text-gray-400">
                Canonical Attributes
              </p>
            </div>

            {/* Checkbox list */}
            <div className="px-4 space-y-1 pb-3">
              {filteredAttributes.length === 0 ? (
                <p className="text-[13px] text-gray-400 py-2">No attributes match your search</p>
              ) : (
                filteredAttributes.map((attr) => {
                  const checked = checkedAttrs.includes(attr.id);
                  return (
                    <label
                      key={attr.id}
                      className={`flex items-start gap-3 p-2.5 rounded-lg cursor-pointer transition-colors ${
                        checked ? "bg-blue-50 border border-blue-100" : "hover:bg-gray-50 border border-transparent"
                      }`}
                    >
                      <div
                        className={`w-4 h-4 mt-0.5 rounded border-2 flex items-center justify-center shrink-0 transition-colors ${
                          checked ? "bg-blue-600 border-blue-600" : "border-gray-300"
                        }`}
                        onClick={() => toggleAttr(attr.id)}
                      >
                        {checked && <Check className="w-2.5 h-2.5 text-white" />}
                      </div>
                      <div className="flex-1 min-w-0" onClick={() => toggleAttr(attr.id)}>
                        <p className={`text-[13px] font-medium leading-tight ${checked ? "text-blue-800" : "text-gray-700"}`}>
                          {attr.name}
                        </p>
                        <p className="text-[12px] text-gray-400 leading-tight mt-0.5 line-clamp-1">
                          {attr.description}
                        </p>
                      </div>
                      <span className={`text-[11px] px-1.5 py-0.5 rounded shrink-0 ${
                        checked ? "bg-blue-100 text-blue-600" : "bg-gray-100 text-gray-400"
                      }`}>
                        {attr.type}
                      </span>
                    </label>
                  );
                })
              )}
            </div>

            {/* Missing / New Attributes */}
            <div className="px-4 pt-2 pb-3">
              <div className="border-t border-gray-100 pt-3">
                <label className="block text-[11px] font-semibold uppercase tracking-widest text-gray-400 mb-2">
                  Missing / New Attributes
                </label>
                <textarea
                  value={missingAttrs}
                  onChange={(e) => setMissingAttrs(e.target.value)}
                  placeholder="Enter attribute names not found in the list above, one per line…"
                  rows={3}
                  className="w-full px-3 py-2.5 border border-gray-200 rounded-lg text-[13px] text-gray-700 placeholder-gray-400 resize-none focus:outline-none focus:ring-2 focus:ring-blue-100 focus:border-blue-300 transition-all"
                />
              </div>
            </div>

            {/* Notes */}
            <div className="px-4 pb-4">
              <label className="flex items-center gap-1.5 text-[11px] font-semibold uppercase tracking-widest text-gray-400 mb-2">
                <StickyNote className="w-3.5 h-3.5" />
                Notes
              </label>
              <textarea
                value={notes}
                onChange={(e) => setNotes(e.target.value)}
                placeholder="Optional reviewer notes or observations…"
                rows={3}
                className="w-full px-3 py-2.5 border border-gray-200 rounded-lg text-[13px] text-gray-700 placeholder-gray-400 resize-none focus:outline-none focus:ring-2 focus:ring-blue-100 focus:border-blue-300 transition-all"
              />
            </div>
          </div>

          {/* Actions */}
          <div className="px-4 py-4 border-t border-gray-200 space-y-2 shrink-0 bg-gray-50">
            {savedFlash && (
              <div className="flex items-center gap-2 px-3 py-2 bg-green-50 border border-green-100 rounded-lg text-[13px] text-green-700">
                <CheckCircle2 className="w-4 h-4" />
                Annotation saved successfully
              </div>
            )}
            <button
              onClick={handleSaveAndNext}
              disabled={!currentImage}
              className="w-full flex items-center justify-center gap-2 px-4 py-2.5 bg-blue-600 text-white rounded-lg text-[14px] font-semibold hover:bg-blue-700 disabled:opacity-40 disabled:cursor-not-allowed transition-colors"
            >
              <Save className="w-4 h-4" />
              Save &amp; Next
            </button>
            <div className="flex gap-2">
              <button
                onClick={handleSave}
                disabled={!currentImage}
                className="flex-1 flex items-center justify-center gap-1.5 px-3 py-2 border border-gray-200 rounded-lg text-[13px] font-medium text-gray-600 bg-white hover:bg-gray-50 disabled:opacity-40 disabled:cursor-not-allowed transition-colors"
              >
                <Save className="w-3.5 h-3.5" />
                Save
              </button>
              <button
                onClick={handleSkip}
                disabled={currentIndex >= images.length - 1}
                className="flex-1 flex items-center justify-center gap-1.5 px-3 py-2 border border-gray-200 rounded-lg text-[13px] font-medium text-gray-600 bg-white hover:bg-gray-50 disabled:opacity-40 disabled:cursor-not-allowed transition-colors"
              >
                <SkipForward className="w-3.5 h-3.5" />
                Skip
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
