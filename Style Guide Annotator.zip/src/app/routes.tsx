import React from "react";
import { createBrowserRouter, Navigate } from "react-router";
import { Layout } from "./components/Layout";
import { Home } from "./pages/Home";
import { Processing } from "./pages/Processing";
import { ReviewImages } from "./pages/ReviewImages";
import { AttributeStore } from "./pages/AttributeStore";
import { ExportResults } from "./pages/ExportResults";
import { Dashboard } from "./pages/Dashboard";

function AppRedirect() {
  return <Navigate to="/app/dashboard" replace />;
}

export const router = createBrowserRouter([
  {
    path: "/",
    Component: Home,
  },
  {
    path: "/processing",
    Component: Processing,
  },
  {
    path: "/app",
    Component: Layout,
    children: [
      {
        index: true,
        Component: AppRedirect,
      },
      {
        path: "dashboard",
        Component: Dashboard,
      },
      {
        path: "review",
        Component: ReviewImages,
      },
      {
        path: "attributes",
        Component: AttributeStore,
      },
      {
        path: "export",
        Component: ExportResults,
      },
    ],
  },
]);
