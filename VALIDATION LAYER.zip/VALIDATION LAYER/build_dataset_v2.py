"""
Build v2 dataset for image2text extraction P/R evaluation.

Final design:
  Real PASS       :  46  (ALIEN 16 + Disney Princess 7 + Minnie 23)
  Synthetic PASS  :  70  (9 guides x ~8 images each)
  Controlled FAIL :  96  (3 per attribute x 32 attrs = 96 exactly)
  ──────────────────────────────────────────────────
  Total to generate: 166 synthetic images
  Grand total      : 212 images

  PASS: 116  FAIL: 96  Ratio: 1.2:1

Evaluation:
  Primary   — P/R across all 32 attributes (all 212 images)
  Secondary — P/R for fixed 23 attributes
  Tertiary  — P/R for open-ended 9 attributes

  NEVER mix evaluation levels into one combined metric.

Open-ended 9: color_palette, background_color, element_color, text_color,
               font_family, logo_hierarchy, font_style, qr_code_position,
               spacing_rules

Fixed 23: all remaining attributes
"""

import csv
import random

random.seed(42)

SOURCE_CSV  = "prompt_dataset_all33.csv"
OUT_PROMPTS = "prompt_dataset_v2.csv"
OUT_GT      = "ground_truth_v2.csv"

REAL_IMAGE_GUIDES = {
    "467122_3_minnie_mouse_packaging_guide",
    "alien_2053001",
    "disney_princess_2338550",
}

SYNTHETIC_PASS_GUIDES = [
    "466910", "470161", "471448_3", "481751", "604555_4",
    "607552_2", "646642_sw_visions_pkg", "943479", "955092_2"
]

assert not any(g in REAL_IMAGE_GUIDES for g in SYNTHETIC_PASS_GUIDES), \
    "Real guide found in SYNTHETIC_PASS_GUIDES."

OPEN_ENDED_ATTRS = {
    "color_palette", "background_color", "element_color", "text_color",
    "font_family", "logo_hierarchy", "font_style", "qr_code_position",
    "spacing_rules"
}

PASS_VARIANTS = [
    "",
    " Show a slightly different product angle with the same branding.",
    " Use a different background scene but maintain all brand compliance rules.",
    " Feature a different product size variant, fully compliant.",
    " Show the product from a slight left perspective, all elements compliant.",
    " Alternate composition with character slightly repositioned but compliant.",
    " Show a front-facing view, all brand elements correctly placed.",
    " Different lighting but all compliance elements clearly visible.",
]


def load_source():
    rows = list(csv.DictReader(open(SOURCE_CSV, encoding="utf-8", errors="replace")))
    pass_by_guide = {}
    fail_by_attr  = {}
    for r in rows:
        if r["label"] == "PASS":
            pass_by_guide[r["guide_id"]] = r
        elif r["label"] == "FAIL":
            attr = r["attribute_tested"]
            if attr not in fail_by_attr:
                fail_by_attr[attr] = []
            fail_by_attr[attr].append(r)
    return pass_by_guide, fail_by_attr


def build_synthetic_pass(pass_by_guide):
    """
    70 synthetic PASS images across 9 guides.
    9 guides: 7 guides get 8 images, 2 guides get 7 images = 56 + 14 = 70
    """
    prompts = []
    counter = 1
    counts  = [8] * 7 + [7] * 2   # 7x8 + 2x7 = 56+14 = 70

    for guide_id, n in zip(SYNTHETIC_PASS_GUIDES, counts):
        if guide_id in REAL_IMAGE_GUIDES:
            continue
        base = pass_by_guide[guide_id]
        for v in range(n):
            prompts.append({
                "prompt_id":        f"SP{counter:03d}",
                "guide_id":         guide_id,
                "property":         base["property"],
                "variant":          f"FULL_PASS_v{v+1}",
                "attribute_tested": "ALL",
                "eval_type":        "synthetic_pass",
                "label":            "PASS",
                "violations":       "",
                "prompt":           base["prompt"].strip() + PASS_VARIANTS[v % len(PASS_VARIANTS)],
            })
            counter += 1

    print(f"Synthetic PASS: {len(prompts)}")
    return prompts


def build_controlled_fail(fail_by_attr):
    """
    96 controlled FAIL — 1 violation per image.
    32 attributes x 3 images each = 96 exactly.
    Spread across different guides for variety.
    """
    attrs = sorted(fail_by_attr.keys())
    assert len(attrs) == 32, f"Expected 32 attributes, got {len(attrs)}"

    attr_counts = {attr: 3 for attr in attrs}

    assert sum(attr_counts.values()) == 96, f"FAIL count mismatch: {sum(attr_counts.values())}"

    selected = []
    for attr in attrs:
        rows  = fail_by_attr[attr]
        count = attr_counts[attr]
        for i in range(count):
            selected.append((attr, rows[i % len(rows)]))

    prompts = []
    counter = 1
    for attr, r in selected:
        prompts.append({
            "prompt_id":        f"CF{counter:03d}",
            "guide_id":         r["guide_id"],
            "property":         r["property"],
            "variant":          r["variant"],
            "attribute_tested": attr,
            "eval_type":        "controlled_fail",
            "label":            "FAIL",
            "violations":       attr,
            "prompt":           r["prompt"],
        })
        counter += 1

    print(f"Controlled FAIL: {len(prompts)}")
    return prompts


def build_ground_truth(all_prompts):
    rows = []
    for p in all_prompts:
        rows.append({
            "prompt_id":        p["prompt_id"],
            "guide_id":         p["guide_id"],
            "property":         p["property"],
            "eval_type":        p["eval_type"],
            "label":            p["label"],
            "attribute_tested": p["attribute_tested"],
            "violations":       p["violations"],
            "attr_type":        "open_ended" if p["attribute_tested"] in OPEN_ENDED_ATTRS else "fixed",
        })
    return rows


def main():
    print("Loading source prompts...")
    pass_by_guide, fail_by_attr = load_source()
    print(f"  PASS guides: {len(pass_by_guide)}, FAIL attrs: {len(fail_by_attr)}")

    syn_pass  = build_synthetic_pass(pass_by_guide)
    ctrl_fail = build_controlled_fail(fail_by_attr)

    all_prompts = syn_pass + ctrl_fail

    fields = ["prompt_id", "guide_id", "property", "variant", "attribute_tested",
              "eval_type", "label", "violations", "prompt"]
    with open(OUT_PROMPTS, "w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=fields)
        w.writeheader()
        w.writerows(all_prompts)

    gt_rows   = build_ground_truth(all_prompts)
    gt_fields = ["prompt_id", "guide_id", "property", "eval_type",
                 "label", "attribute_tested", "violations", "attr_type"]
    with open(OUT_GT, "w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=gt_fields)
        w.writeheader()
        w.writerows(gt_rows)

    print("\n=== Final Dataset ===")
    print("Real PASS (not generated)  :  46  (ALIEN 16, Disney Princess 7, Minnie 23)")
    print(f"Synthetic PASS             :  {len(syn_pass)}")
    print(f"Controlled FAIL            :  {len(ctrl_fail)}  (3 per attribute x 32 attrs)")
    print(f"Total to generate          :  {len(all_prompts)}")
    print(f"Grand total                :  {len(all_prompts) + 46}")
    print(f"PASS : FAIL                :  {len(syn_pass)+46} : {len(ctrl_fail)}  (ratio {(len(syn_pass)+46)/len(ctrl_fail):.2f}:1)")
    print(f"\nSaved: {OUT_PROMPTS}")
    print(f"Saved: {OUT_GT}")


if __name__ == "__main__":
    main()
