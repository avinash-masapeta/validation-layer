"""
Build ground truth CSV from generation prompts and real image metadata.

Auto-labels attribute values from DALL-E prompt text (source="prompt").
Real images get blank rows (source="manual") for human labeling.
Gate dependencies enforced: child attrs set to not_applicable when parent absent.

Output: ground_truth_v3.csv (base for ground_truth_v4.csv after manual labeling + migration)
"""

import csv
import json
import re

PROMPT_CSV       = "prompt_dataset_v2.csv"
GEN_LOG          = "generation_log_v2.json"
REAL_IMAGES_FILE = "real_images_v2.json"
OUTPUT_CSV       = "ground_truth_v3.csv"


# ═══════════════════════════════════════════════════════════
# COLOR NORMALIZATION
# ═══════════════════════════════════════════════════════════

COLOR_NORM_MAP = {
    # Pink variants
    "light pink": "pink", "soft pink": "pink", "pinkish": "pink",
    "hot pink": "pink", "rose": "pink", "blush": "pink",
    # Blue variants
    "icy blue": "blue", "sky blue": "blue", "light blue": "blue",
    "tropical blue": "blue", "medium blue": "blue", "cobalt": "blue",
    "pantone medium blue": "blue",
    # Dark blue variants — fold into blue (no separate dark_blue canonical)
    "dark blue": "blue", "deep blue": "blue", "navy": "blue",
    "navy blue": "blue", "midnight blue": "blue",
    # Black variants
    "dark": "black", "very dark": "black", "jet black": "black",
    "dark space": "black", "space black": "black",
    # White variants
    "off white": "white", "cream": "white", "ivory": "white",
    "light": "white",
    # Grey variants — canonical spelling is "grey"
    "gray": "grey", "light gray": "grey", "dark gray": "grey",
    "silver": "grey",
    # Red variants
    "bold red": "red", "bright red": "red", "crimson": "red",
    "dark red": "red",
    # Green variants
    "dark green": "green", "lime": "green", "olive": "green",
    # Yellow variants
    "gold": "yellow", "golden": "yellow", "bright yellow": "yellow",
    # Orange variants
    "burnt orange": "orange", "amber": "orange",
    # Brown variants
    "brown": "brown", "tan": "brown", "beige": "brown",
}

CANONICAL_COLORS = [
    "black", "white", "pink", "blue", "red",
    "green", "yellow", "grey", "orange", "purple", "brown", "other"
]

def normalize_color(raw: str) -> str:
    if not raw:
        return ""
    raw = raw.lower().strip()
    # Preserve special non-color values
    if raw in ("multicolor", "not_applicable"):
        return raw
    if raw in CANONICAL_COLORS:
        return raw
    if raw in COLOR_NORM_MAP:
        return COLOR_NORM_MAP[raw]
    for canonical in CANONICAL_COLORS[:-1]:
        base = canonical.replace("_", " ")
        if base in raw:
            return canonical
    return "other"


# ═══════════════════════════════════════════════════════════
# SCHEMA
# ═══════════════════════════════════════════════════════════

SCHEMA = {

    # ── LOGO (4) ──────────────────────────────────────────
    "logo_presence": {
        "type": "categorical",
        "values": ["present", "absent"],
        "note": "Is the brand logo visible in the image? Gate for all logo_* detail attributes."
    },
    "logo_position": {
        "type": "categorical",
        "values": [
            "top-left",    "top-center",    "top-right",
            "center-left", "center",        "center-right",
            "bottom-left", "bottom-center", "bottom-right",
            "not_applicable"
        ],
        "note": "Full 3x3 grid. Where on packaging is the brand logo? not_applicable when logo_presence=absent."
    },
    "logo_scale": {
        "type": "categorical",
        "values": ["small", "medium", "large", "not_applicable"],
        "note": "Logo size relative to packaging face. small <10% | medium 10-25% | large >25%"
    },
    "logo_proportion": {
        "type": "categorical",
        "values": ["proportional", "distorted", "not_applicable"],
        "note": "Defined purely visually, independent of brand specification. proportional=visually undistorted (no stretching, squishing, skewing) | distorted=visibly warped. not_applicable when logo_presence=absent. NOTE: no FAIL samples yet — plan distortion-based test cases."
    },

    # ── CHARACTER (5) ─────────────────────────────────────
    "character_presence": {
        "type": "categorical",
        "values": ["present", "absent"],
        "note": "Is there a character/hero figure in the image? Gate for all character_* detail attributes."
    },
    "character_position": {
        "type": "categorical",
        "values": ["center", "left", "right", "top", "bottom", "not_applicable"],
        "note": "Spatial location of the character/hero image. full-width removed — scale/span captured by character_scale. not_applicable when character_presence=absent."
    },
    "character_scale": {
        "type": "categorical",
        "values": ["small", "medium", "large", "not_applicable"],
        "note": "Character size relative to packaging face. small <20% | medium 20-50% | large >50%"
    },
    "character_orientation": {
        "type": "categorical",
        "values": ["facing_forward", "facing_left", "facing_right", "angled", "back_view", "not_applicable"],
        "note": "Direction the character faces. 'angled' captures 3/4 poses — most common real-world case, not covered by cardinal directions. not_applicable when character_presence=absent."
    },
    "character_proportion": {
        "type": "categorical",
        "values": ["proportional", "distorted", "not_applicable"],
        "note": "Defined purely visually, independent of brand specification. proportional=visually undistorted (no stretching, squishing, skewing) | distorted=visibly warped. not_applicable when character_presence=absent. NOTE: no FAIL samples yet — plan distortion-based test cases."
    },
    "character_color": {
        "type": "open_ended",
        "values": CANONICAL_COLORS + ["multicolor"],
        "note": "Dominant color of the character/hero figure. Same normalization as text_color and background_color — beige->brown, navy->blue etc. Use multicolor if no single dominant color. not_applicable auto-set when character_presence=absent."
    },

    # ── TEXT (5) ──────────────────────────────────────────
    "text_presence": {
        "type": "categorical",
        "values": ["present", "absent"],
        "note": "Is text visible on the packaging face? Gate for text_color, text_position, text_scale, font_family."
    },
    "text_color": {
        "type": "open_ended",
        "values": CANONICAL_COLORS,
        "note": "Color of the main product name/title text. Normalize. not_applicable when text_presence=absent."
    },
    "text_position": {
        "type": "categorical",
        "values": [
            "top-left",    "top-center",    "top-right",
            "center-left", "center",        "center-right",
            "bottom-left", "bottom-center", "bottom-right",
            "not_applicable"
        ],
        "note": "Same 3x3 grid as logo_position — consistent schema design. not_applicable when text_presence=absent."
    },
    "text_scale": {
        "type": "categorical",
        "values": ["small", "medium", "large", "not_applicable"],
        "note": "Scale of main text relative to packaging face. not_applicable when text_presence=absent."
    },
    "font_family": {
        "type": "open_ended",
        "values": ["sans-serif", "serif", "script", "decorative", "unknown"],
        "note": "Typeface category of main text. not_applicable when text_presence=absent."
    },

    # ── BACKGROUND (2) ────────────────────────────────────
    "background_color": {
        "type": "open_ended",
        "values": CANONICAL_COLORS,
        "note": "Dominant background color. Normalize variants: 'light pink'->pink, 'navy'->blue, 'silver'->grey"
    },
    "background_pattern": {
        "type": "categorical",
        "values": ["solid", "gradient", "patterned", "photographic", "illustrated"],
        "note": "RULE: real photo->photographic | drawn/art->illustrated | repeating shapes->patterned | plain single color->solid | blend of colors->gradient"
    },

    # ── SNIPE / CALLOUT (3) ───────────────────────────────
    "snipe_presence": {
        "type": "categorical",
        "values": ["present", "absent"],
        "note": "Are promotional badge/snipe callouts visible? Gate for snipe_count and snipe_shape."
    },
    "snipe_count": {
        "type": "categorical",
        "values": ["1", "2", "3", "4+", "not_applicable"],
        "note": "Count of snipes/callouts when present. not_applicable when snipe_presence=absent."
    },
    "snipe_shape": {
        "type": "categorical",
        "values": ["circle", "rectangle", "irregular", "not_applicable"],
        "note": "Shape of the snipe/callout badge. not_applicable when snipe_presence=absent."
    },

    # ── BARCODE / QR (2) ──────────────────────────────────
    "barcode_presence": {
        "type": "categorical",
        "values": ["present", "absent"],
        "note": "Is a barcode/QR code visible anywhere on packaging? Gate for barcode_position."
    },
    "barcode_position": {
        "type": "categorical",
        "values": [
            "top-left",    "top-center",    "top-right",
            "center-left", "center",        "center-right",
            "bottom-left", "bottom-center", "bottom-right",
            "not_applicable"
        ],
        "note": "Same 3x3 grid as logo_position — consistent schema design. not_applicable when barcode_presence=absent."
    },
}

ALL_ATTRS = list(SCHEMA.keys())


# ═══════════════════════════════════════════════════════════
# ATTRIBUTE DEPENDENCY MAP
# ═══════════════════════════════════════════════════════════

DEPENDENCIES = {
    # Logo detail attributes — only if logo is present
    "logo_position":    ("logo_presence", ["present"]),
    "logo_scale":       ("logo_presence", ["present"]),
    "logo_proportion":  ("logo_presence", ["present"]),

    # Character detail attributes — only if character is present
    "character_position":    ("character_presence", ["present"]),
    "character_scale":       ("character_presence", ["present"]),
    "character_orientation": ("character_presence", ["present"]),
    "character_proportion":  ("character_presence", ["present"]),
    "character_color":       ("character_presence", ["present"]),

    # Text detail attributes — only if text is present
    "text_color":    ("text_presence", ["present"]),
    "text_position": ("text_presence", ["present"]),
    "text_scale":    ("text_presence", ["present"]),
    "font_family":   ("text_presence", ["present"]),

    # Snipe details — only if snipes are present
    "snipe_count": ("snipe_presence", ["present"]),
    "snipe_shape": ("snipe_presence", ["present"]),

    # Barcode position — only if barcode is present
    "barcode_position": ("barcode_presence", ["present"]),
}

def is_applicable(attr: str, row: dict) -> bool:
    """Return True if this attribute should be evaluated for this image."""
    if attr not in DEPENDENCIES:
        return True
    dep_attr, required_values = DEPENDENCIES[attr]
    return row.get(dep_attr, "") in required_values


def apply_dependencies(row: dict) -> dict:
    for attr in ALL_ATTRS:
        if not is_applicable(attr, row):
            row[attr] = "not_applicable"
    return row


# ═══════════════════════════════════════════════════════════
# SCHEMA VALIDATOR
# ═══════════════════════════════════════════════════════════

def validate_value(attr: str, value: str) -> bool:
    if not value or value.startswith("[VIOLATION]"):
        return True
    if value == "not_applicable":
        return True
    spec = SCHEMA[attr]
    if spec["values"] is None:
        return True  # TBD — no schema yet, skip validation
    if spec["type"] == "categorical":
        return value in spec["values"]
    else:
        parts = [v.strip() for v in value.split(",")]
        return all(p in spec["values"] for p in parts)


# ═══════════════════════════════════════════════════════════
# PROMPT PARSERS
# ═══════════════════════════════════════════════════════════

def parse_logo_presence(prompt):
    pl = prompt.lower()
    if any(x in pl for x in ["no logo", "logo absent", "without logo"]):
        return "absent"
    if any(x in pl for x in ["logo", "brand mark"]):
        return "present"
    return ""


def parse_logo_position(prompt):
    pl = prompt.lower()
    candidates = [
        ("bottom-left",   ["bottom-left", "bottom left", "lower left"]),
        ("bottom-right",  ["bottom-right", "bottom right", "lower right"]),
        ("bottom-center", ["bottom-center", "bottom center"]),
        ("top-left",      ["top-left", "top left", "upper left"]),
        ("top-right",     ["top-right", "top right", "upper right"]),
        ("top-center",    ["top-center", "top center", "centered top"]),
        ("center",        ["centered", "center of"]),
    ]
    for canonical, variants in candidates:
        for v in variants:
            idx = pl.find(v)
            if idx == -1:
                continue
            nearby = pl[max(0, idx - 70): idx + 10]
            if "logo" in nearby:
                return canonical
    return ""


def parse_logo_scale(prompt):
    pl = prompt.lower()
    if any(x in pl for x in ["small logo", "tiny logo", "logo small"]):
        return "small"
    if any(x in pl for x in ["medium logo", "logo medium"]):
        return "medium"
    if any(x in pl for x in ["large logo", "prominent logo", "logo large"]):
        return "large"
    return ""


def parse_logo_proportion(prompt):
    return ""


def parse_character_presence(prompt):
    pl = prompt.lower()
    if any(x in pl for x in ["no character", "product-focused", "logo and label focused",
                               "product imagery", "label focused"]):
        return "absent"
    if any(x in pl for x in ["character art", "character crop", "character in",
                               "character pose", "wildlife image", "hero image",
                               "photographic wildlife"]):
        return "present"
    return ""


def parse_character_position(prompt):
    pl = prompt.lower()
    if "left side" in pl or "left of" in pl:
        return "left"
    if "right side" in pl or "right of" in pl:
        return "right"
    # full-width removed from character_position — span captured by character_scale
    if "top of" in pl or "upper area" in pl:
        return "top"
    if "bottom of" in pl or "lower area" in pl:
        return "bottom"
    if any(x in pl for x in ["character art", "character crop", "character in", "character pose"]):
        return "center"
    return ""


def parse_character_scale(prompt):
    pl = prompt.lower()
    if any(x in pl for x in ["small character", "tiny character", "small figure"]):
        return "small"
    if any(x in pl for x in ["medium character", "mid-size"]):
        return "medium"
    if any(x in pl for x in ["character art", "character crop", "large character",
                               "dominant character", "full character"]):
        return "large"
    return ""


def parse_character_orientation(prompt):
    pl = prompt.lower()
    if "facing left" in pl:
        return "facing_left"
    if "facing right" in pl:
        return "facing_right"
    if "back view" in pl or "rear view" in pl:
        return "back_view"
    if any(x in pl for x in ["3/4", "three quarter", "angled", "diagonal pose"]):
        return "angled"
    if any(x in pl for x in ["approved pose", "playful pose", "dynamic pose",
                               "frontal", "front view", "forward"]):
        return "facing_forward"
    return ""


def parse_character_proportion(prompt):
    return ""


def parse_character_color(prompt):
    return ""


def parse_text_presence(prompt):
    pl = prompt.lower()
    if any(x in pl for x in ["no text", "text absent"]):
        return "absent"
    if any(x in pl for x in ["product name", "title text", "text", "font", "typography",
                               "callout text", "headline"]):
        return "present"
    return ""


def parse_text_color(prompt):
    pl = prompt.lower()
    for raw, canonical in COLOR_NORM_MAP.items():
        if raw in pl and any(t in pl[max(0, pl.find(raw)-30):pl.find(raw)+len(raw)+30]
                             for t in ["text", "font", "title", "word"]):
            return canonical
    return ""


def parse_text_position(prompt):
    return ""


def parse_text_scale(prompt):
    return ""


def parse_font_family(prompt):
    pl = prompt.lower()
    if any(x in pl for x in ["sans-serif", "sans serif"]):
        return "sans-serif"
    if "serif" in pl:
        return "serif"
    if "script" in pl or "handwritten" in pl or "cursive" in pl:
        return "script"
    if "decorative" in pl or "display" in pl:
        return "decorative"
    return ""


def parse_background_color(prompt):
    pl = prompt.lower()
    for raw, canonical in COLOR_NORM_MAP.items():
        if raw in pl:
            return canonical
    return ""


def parse_background_pattern(prompt):
    pl = prompt.lower()
    if any(x in pl for x in ["polka-dot", "polka dot", "pattern liner"]):
        return "patterned"
    if any(x in pl for x in ["photographic", "wildlife image", "hero image", "product-focused"]):
        return "photographic"
    if any(x in pl for x in ["solid color", "bold red background", "bold background"]):
        return "solid"
    if any(x in pl for x in ["icy", "glacial", "underwater", "tropical", "environmental",
                               "illustrated", "dark space", "space background"]):
        return "illustrated"
    if any(x in pl for x in ["gradient", "fade", "ombre"]):
        return "gradient"
    return ""


def parse_snipe_presence(prompt):
    pl = prompt.lower()
    if re.search(r'no callout|without callout|0 callout|no snipe', pl):
        return "absent"
    if re.search(r'callout|snipe', pl):
        return "present"
    return ""


def parse_snipe_count(prompt):
    m = re.search(r'(\d+)\s+product feature callout', prompt, re.IGNORECASE)
    if m:
        n = int(m.group(1))
        return str(n) if n <= 3 else "4+"
    return ""


def parse_snipe_shape(prompt):
    return ""


def parse_barcode_presence(prompt):
    pl = prompt.lower()
    if re.search(r'no qr|without qr|qr.*absent|no barcode', pl):
        return "absent"
    if re.search(r'qr code|barcode', pl):
        return "present"
    return ""


def parse_barcode_position(prompt):
    pl = prompt.lower()
    candidates = [
        ("bottom-right", ["bottom-right corner", "bottom right corner", "bottom-right"]),
        ("bottom-left",  ["bottom-left corner",  "bottom left corner"]),
        ("top-right",    ["top-right corner",    "top right corner"]),
        ("top-left",     ["top-left corner",     "top left corner"]),
    ]
    for canonical, variants in candidates:
        for v in variants:
            idx = pl.find(v)
            if idx == -1:
                continue
            nearby = pl[max(0, idx - 80): idx + 5]
            if "qr" in nearby or "barcode" in nearby:
                return canonical
    return ""


# ═══════════════════════════════════════════════════════════
# LABEL EXTRACTION
# ═══════════════════════════════════════════════════════════

def extract_pass_labels(prompt, guide_id):
    labels = {a: "" for a in ALL_ATTRS}
    src    = {a: "" for a in ALL_ATTRS}

    def set_val(attr, val):
        if val:
            labels[attr] = val
            src[attr]    = "prompt"

    # ── Step 1: Gate attributes first ────────────────────
    set_val("logo_presence",      parse_logo_presence(prompt))
    set_val("character_presence", parse_character_presence(prompt))
    set_val("text_presence",      parse_text_presence(prompt))
    set_val("snipe_presence",     parse_snipe_presence(prompt))
    set_val("barcode_presence",   parse_barcode_presence(prompt))

    # ── Step 2: Always-on attributes ─────────────────────
    set_val("background_color",   parse_background_color(prompt))
    set_val("background_pattern", parse_background_pattern(prompt))

    # ── Step 3: Logo details — only if logo present ───────
    if labels.get("logo_presence") == "present":
        set_val("logo_position",   parse_logo_position(prompt))
        set_val("logo_scale",      parse_logo_scale(prompt))
        set_val("logo_proportion", parse_logo_proportion(prompt))

    # ── Step 4: Character details — only if character present ──
    if labels.get("character_presence") == "present":
        set_val("character_position",    parse_character_position(prompt))
        set_val("character_scale",       parse_character_scale(prompt))
        set_val("character_orientation", parse_character_orientation(prompt))
        set_val("character_proportion",  parse_character_proportion(prompt))
        set_val("character_color",       parse_character_color(prompt))

    # ── Step 5: Text details — only if text present ───────
    if labels.get("text_presence") == "present":
        set_val("text_color",    parse_text_color(prompt))
        set_val("text_position", parse_text_position(prompt))
        set_val("text_scale",    parse_text_scale(prompt))
        set_val("font_family",   parse_font_family(prompt))

    # ── Step 6: Snipe details — only if snipes present ───
    if labels.get("snipe_presence") == "present":
        set_val("snipe_count", parse_snipe_count(prompt))
        set_val("snipe_shape", parse_snipe_shape(prompt))

    # ── Step 7: Barcode position — only if barcode present ─
    if labels.get("barcode_presence") == "present":
        set_val("barcode_position", parse_barcode_position(prompt))

    # ── Step 8: Enforce dependencies ─────────────────────
    apply_dependencies(labels)

    return labels, src


def extract_fail_labels(prompt, attribute_tested):
    labels = {a: "" for a in ALL_ATTRS}
    src    = {a: "" for a in ALL_ATTRS}
    m = re.match(r'CRITICAL:\s*(.+?)(?:\s*[.\-])', prompt)
    if m and attribute_tested in ALL_ATTRS:
        labels[attribute_tested] = f"[VIOLATION] {m.group(1).strip()}"
        src[attribute_tested]    = "prompt"
    return labels, src


# ═══════════════════════════════════════════════════════════
# MAIN
# ═══════════════════════════════════════════════════════════

def main():
    prompts = {}
    with open(PROMPT_CSV, encoding="utf-8") as f:
        for row in csv.DictReader(f):
            prompts[row["prompt_id"]] = row

    with open(GEN_LOG, encoding="utf-8") as f:
        gen_log = json.load(f)
    with open(REAL_IMAGES_FILE, encoding="utf-8") as f:
        real_images = json.load(f)

    rows = []

    for pid, entry in gen_log.items():
        img_file    = entry.get("file") or ""
        prompt_row  = prompts.get(pid, {})
        prompt_text = prompt_row.get("prompt", "")
        guide_id    = entry.get("guide_id", "")
        label       = entry.get("label", "PASS")
        attr_tested = entry.get("attribute_tested", "ALL")
        eval_type   = entry.get("eval_type", "synthetic_pass")

        if label == "PASS":
            labels, src = extract_pass_labels(prompt_text, guide_id)
        else:
            labels, src = extract_fail_labels(prompt_text, attr_tested)

        row = {
            "image_id": pid, "image_file": img_file, "guide_id": guide_id,
            "brand": prompt_row.get("property", ""), "eval_type": eval_type,
            "label": label, "attribute_tested": attr_tested,
        }
        for a in ALL_ATTRS:
            row[a]             = labels[a]
            row[f"{a}_source"] = src[a]
        rows.append(row)

    for img in real_images:
        row = {
            "image_id": img["image_id"],
            "image_file": img.get("image_file", img.get("image_id", "")),
            "guide_id": img.get("guide_id", ""),
            "brand": img.get("brand", ""),
            "eval_type": "real_pass", "label": "PASS", "attribute_tested": "ALL",
        }
        for a in ALL_ATTRS:
            row[a]             = ""
            row[f"{a}_source"] = "manual"
        rows.append(row)

    # Write CSV
    base_fields = ["image_id", "image_file", "guide_id", "brand",
                   "eval_type", "label", "attribute_tested"]
    attr_fields = []
    for a in ALL_ATTRS:
        attr_fields += [a, f"{a}_source"]

    with open(OUTPUT_CSV, "w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=base_fields + attr_fields)
        w.writeheader()
        w.writerows(rows)

    # Validate auto-labeled values against schema
    violations = []
    for r in rows:
        for a in ALL_ATTRS:
            v = r[a]
            if v and r[f"{a}_source"] == "prompt" and not validate_value(a, v):
                violations.append(f"  {r['image_id']} | {a} | {v!r} not in schema")

    # Summary
    syn_pass  = sum(1 for r in rows if r["eval_type"] == "synthetic_pass")
    syn_fail  = sum(1 for r in rows if r["eval_type"] == "controlled_fail")
    real_pass = sum(1 for r in rows if r["eval_type"] == "real_pass")
    auto      = sum(1 for r in rows for a in ALL_ATTRS
                    if r[f"{a}_source"] == "prompt" and r[a] and not r[a].startswith("[VIOLATION]"))
    total     = len(rows) * len(ALL_ATTRS)

    print(f"\nground_truth_v3.csv  |  {len(rows)} images  |  {len(ALL_ATTRS)} attributes")
    print(f"  Synthetic PASS : {syn_pass}  |  Controlled FAIL : {syn_fail}  |  Real PASS : {real_pass}")
    print(f"  Auto-labeled   : {auto}/{total} ({auto/total*100:.1f}%)")
    print(f"  Schema violations in auto-labels: {len(violations)}")
    for v in violations[:10]:
        print(v)

    print(f"\nSCHEMA ({len(ALL_ATTRS)} attributes)")
    print(f"  {'Attribute':<28} {'Type':<12} Values / Status")
    print(f"  {'-'*80}")
    for a, spec in SCHEMA.items():
        if spec["values"] is None:
            vals = "[TBD - awaiting schema]"
        elif spec["type"] == "open_ended":
            vals = f"open-ended: {', '.join(str(v) for v in spec['values'])}"
        else:
            vals = " | ".join(str(v) for v in spec["values"])
        print(f"  {a:<28} {spec['type']:<12} {vals}")

    print("\nAuto-label coverage (synthetic PASS):")
    syn = [r for r in rows if r["eval_type"] == "synthetic_pass"]
    if syn:
        for a in ALL_ATTRS:
            n = sum(1 for r in syn if r[a] and r[f"{a}_source"] == "prompt")
            bar = "#" * int(n / len(syn) * 20)
            tbd = " [TBD schema]" if SCHEMA[a]["values"] is None else ""
            print(f"  {a:<28} {n:>3}/{len(syn)}  {bar}{tbd}")

    print("\nAttributes with TBD schema (need values before running evaluation):")
    tbd_attrs = [a for a, spec in SCHEMA.items() if spec["values"] is None]
    for a in tbd_attrs:
        print(f"  - {a}")


if __name__ == "__main__":
    main()
