"""
Extraction accuracy evaluation — 24-attribute SOW schema.

Usage:
  python evaluate_v3.py              # full extraction + scoring
  python evaluate_v3.py --rescore    # re-score only (reuses extraction cache, no API cost)

Dataset: 208 images (46 real PASS + 70 synthetic PASS + 92 controlled FAIL)
"""

import csv
import json
import os
import sys
import io
import time
import base64
import re
from rapidfuzz import fuzz

try:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    sys.stderr.reconfigure(encoding="utf-8", errors="replace")
except Exception:
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8", errors="replace", line_buffering=True)
    sys.stderr = io.TextIOWrapper(sys.stderr.buffer, encoding="utf-8", errors="replace", line_buffering=True)

_here = os.path.dirname(os.path.abspath(__file__))
try:
    from dotenv import load_dotenv
    load_dotenv(os.path.join(_here, ".env"), override=True)
except ImportError:
    pass

from jedai_client import ensure_jedai_configured, jedai_complete  # noqa: E402

ensure_jedai_configured()

# ─── CONFIG ───────────────────────────────────────────────────────────────────
# Vision model id must match a JedAI gateway model (default gpt-4.1).
_eval_default = "gpt-4.1"
MODEL = (
    os.environ.get("EVAL_MODEL", "").strip()
    or os.environ.get("JEDAI_MODEL", "").strip()
    or _eval_default
)
GT_CSV           = "ground_truth_v4.csv"
GEN_DIR          = "generated_images_v2"
REAL_IMAGES_FILE = "real_images_v2.json"
SLEEP_SECS       = 5
FUZZY_THRESHOLD  = 0.8

_model_tag        = MODEL.replace("-", "_").replace(".", "_")
OUTPUT_EXTRACTION = f"extraction_results_{_model_tag}.json"
OUTPUT_RESULTS    = f"evaluation_results_{_model_tag}.json"
OUTPUT_SUMMARY    = f"evaluation_summary_{_model_tag}.json"


# ─── SCHEMA ───────────────────────────────────────────────────────────────────
ALL_ATTRS = [
    "logo_presence", "logo_horizontal", "logo_vertical",
    "logo_prominence", "logo_proportion",
    "character_presence", "character_position", "character_scale",
    "character_orientation", "character_proportion", "character_color",
    "text_presence", "text_color", "text_position", "text_scale", "font_family",
    "background_color", "background_pattern",
    "snipe_presence", "snipe_density", "snipe_shape",
    "barcode_presence", "barcode_horizontal", "barcode_vertical",
]

OPEN_ENDED = {
    "character_color", "text_color", "background_color", "font_family",
}

CATEGORICAL = [a for a in ALL_ATTRS if a not in OPEN_ENDED]

# Color attributes get extra normalization before fuzzy scoring
COLOR_ATTRS = {"character_color", "text_color", "background_color"}

# Gate rules: dependent attr -> (gate attr, required gate value)
DEPS = {
    "logo_horizontal":       ("logo_presence",      "present"),
    "logo_vertical":         ("logo_presence",      "present"),
    "logo_prominence":       ("logo_presence",      "present"),
    "logo_proportion":       ("logo_presence",      "present"),
    "character_position":    ("character_presence", "present"),
    "character_scale":       ("character_presence", "present"),
    "character_orientation": ("character_presence", "present"),
    "character_proportion":  ("character_presence", "present"),
    "character_color":       ("character_presence", "present"),
    "text_color":            ("text_presence",      "present"),
    "text_position":         ("text_presence",      "present"),
    "text_scale":            ("text_presence",      "present"),
    "font_family":           ("text_presence",      "present"),
    "snipe_density":         ("snipe_presence",     "present"),
    "snipe_shape":           ("snipe_presence",     "present"),
    "barcode_horizontal":    ("barcode_presence",   "present"),
    "barcode_vertical":      ("barcode_presence",   "present"),
}

# ─── COLOR NORMALIZATION ──────────────────────────────────────────────────────
COLOR_NORM_MAP = {
    # Pink
    "light pink": "pink", "soft pink": "pink", "hot pink": "pink",
    "rose": "pink", "blush": "pink", "pinkish": "pink", "salmon pink": "pink",
    # Blue
    "sky blue": "blue", "light blue": "blue", "icy blue": "blue",
    "cobalt": "blue", "cobalt blue": "blue", "teal": "blue",
    "turquoise": "blue", "aqua": "blue", "cyan": "blue",
    "navy": "blue", "navy blue": "blue", "dark blue": "blue",
    "deep blue": "blue", "midnight blue": "blue", "tropical blue": "blue",
    "medium blue": "blue", "steel blue": "blue",
    # Black
    "jet black": "black", "dark": "black", "very dark": "black",
    "space black": "black", "charcoal": "black",
    # White
    "off white": "white", "cream": "white", "ivory": "white",
    "beige": "white", "light": "white", "pale": "white", "off-white": "white",
    # Grey
    "gray": "grey", "light gray": "grey", "dark gray": "grey",
    "light grey": "grey", "dark grey": "grey", "silver": "grey",
    "metallic": "grey", "slate": "grey",
    # Green
    "olive": "green", "lime": "green", "lime green": "green",
    "dark green": "green", "forest green": "green", "mint": "green",
    "emerald": "green",
    # Yellow
    "gold": "yellow", "golden": "yellow", "amber": "yellow",
    "mustard": "yellow", "lemon": "yellow",
    # Orange
    "coral": "orange", "peach": "orange", "salmon": "orange",
    "burnt orange": "orange", "tangerine": "orange",
    # Red
    "burgundy": "red", "crimson": "red", "maroon": "red",
    "scarlet": "red", "dark red": "red", "wine": "red",
    # Brown
    "tan": "brown", "khaki": "brown", "chocolate": "brown",
    "dark brown": "brown", "caramel": "brown", "mocha": "brown",
    # Purple
    "lavender": "purple", "violet": "purple", "magenta": "purple",
    "indigo": "purple", "lilac": "purple", "plum": "purple",
}


def normalize_color(text):
    t = text.lower().strip()
    return COLOR_NORM_MAP.get(t, t)


# ─── EXTRACTION PROMPT ────────────────────────────────────────────────────────
EXTRACTION_PROMPT = """You are labeling a product packaging image for a compliance dataset.

STRICT RULES — READ BEFORE ANSWERING:
1. For every attribute, you MUST write EXACTLY one value from its allowed list.
2. Do NOT write "not_applicable" unless the NOTE section explicitly says to.
3. Do NOT write "not_visible", "unknown", "n/a", or anything outside the allowed list.
4. When uncertain, pick the CLOSEST matching value — never refuse to answer.
5. Return ONLY valid JSON. No explanation text outside the JSON.

ATTRIBUTE GUIDE:

  logo_presence       : Is a brand logo visible? → present | absent
  logo_horizontal     : Mentally divide the image into 3 equal vertical columns (left / center / right).
                        Which column contains the majority of the brand logo?
                        → left | center | right
  logo_vertical       : Mentally divide the image into 3 equal horizontal rows (top / middle / bottom).
                        Which row contains the majority of the brand logo?
                        → top | middle | bottom
  logo_prominence     : Compare the logo size to the character art and product name text combined.
                        Logo is clearly smaller / less eye-catching than everything else → low
                        Logo is a normal label size, noticeable but not the hero element → medium
                        Logo is the largest or most visually dominant element on the pack → high
                        → low | medium | high
  logo_proportion     : Does the logo look visually normal (not stretched or squished)?
                        Looks normal → proportional | Visibly stretched or skewed → distorted
                        You MUST pick proportional or distorted. Do not write not_applicable.

  character_presence  : Is a mascot, cartoon, or hero figure visible? → present | absent
  character_position  : Where is the character on the image? → center | left | right | top | bottom
  character_scale     : Estimate character art area as a fraction of the entire front panel face.
                        Fills less than 20% of the panel → small
                        Fills roughly 20–50% of the panel → medium
                        Fills more than 50% of the panel → large
                        → small | medium | large
  character_orientation: Which direction does the character face?
                        Faces viewer (±15° tolerance) → facing_forward
                        Clearly turns left → facing_left | Clearly turns right → facing_right
                        3/4 diagonal view → angled | Facing away → back_view
  character_proportion: Does the character look visually normal (not stretched or squished)?
                        Looks normal → proportional | Visibly stretched or skewed → distorted
                        You MUST pick proportional or distorted. Do not write not_applicable.
  character_color     : Dominant color of the character →
                        black | white | pink | blue | red | green | yellow | grey |
                        orange | purple | brown | multicolor | other

  text_presence       : Is any text visible? → present | absent
  text_color          : Color of the main/largest text →
                        black | white | pink | blue | red | green | yellow | grey |
                        orange | purple | brown | other
                        NOTE: warm dark tone = brown (not black)
  text_position       : Where is the dominant text block located on the packaging? →
                        top-left | top-center | top-right | center-left | center |
                        center-right | bottom-left | bottom-center | bottom-right
  text_scale          : How large is the main text relative to the overall packaging face? →
                        small (subtle/fine print) | medium (standard label text) | large (headline/dominant)
  font_family         : Typeface style of the main text —
                        sans-serif  = clean letters, NO small strokes at letter ends (most common)
                        serif       = has small horizontal strokes at letter ends (like Times New Roman)
                        script      = mimics handwriting or calligraphy, letters often connected
                        decorative  = ONLY if letters have clearly unusual shapes that cannot fit
                                      the above categories (e.g. bubble letters, horror fonts, pixel art)
                        unknown     = truly unreadable
                        RULE: Default to sans-serif or serif when in doubt. Only use decorative for
                              unmistakably artistic/themed letterforms.
                        → sans-serif | serif | script | decorative | unknown

  background_color    : Dominant background color of the overall image →
                        black | white | pink | blue | red | green | yellow | grey |
                        orange | purple | brown | other
  background_pattern  : Overall background type of the image:
                        solid       = single flat color, no texture
                        gradient    = smooth transition between colors
                        patterned   = repeating geometric or decorative motif
                        photographic = real-world photo (food, people, nature, lifestyle scene)
                        illustrated  = drawn/rendered art that is NOT a real photograph
                        → solid | gradient | patterned | photographic | illustrated

  snipe_presence      : Look for small badge-like graphic overlays separate from the main artwork —
                        round burst shapes, rectangular callout boxes, star stamps, circular seals —
                        typically containing a short phrase ("New!", an award claim, a number, or a
                        feature highlight like "1 Metre"). These are NOT the character art or logo.
                        → present | absent
  snipe_density       : Are there one or more than one callout badge(s)?
                        Exactly one badge → single | More than one badge → multiple
                        You MUST pick one — never write not_applicable here.
                        → single | multiple
  snipe_shape         : What is the shape of the callout badge(s)?
                        Pick the CLOSEST shape — never write not_applicable.
                        → circle | rectangle | irregular

  barcode_presence    : Is a barcode or QR code visible? → present | absent
  barcode_horizontal  : Mentally divide the image into 3 equal vertical columns.
                        Which column contains the majority of the barcode/QR code?
                        → left | center | right
  barcode_vertical    : Mentally divide the image into 3 equal horizontal rows.
                        Which row contains the majority of the barcode/QR code?
                        → top | middle | bottom

NOTE: Write "not_applicable" ONLY for these detail attributes when their gate is absent:
      - logo_horizontal / logo_vertical / logo_prominence / logo_proportion
                                              -> only if logo_presence = absent
      - character_position / character_scale / character_orientation /
        character_proportion / character_color -> only if character_presence = absent
      - text_color / text_position / text_scale / font_family
                                              -> only if text_presence = absent
      - snipe_density / snipe_shape           -> only if snipe_presence = absent
      - barcode_horizontal / barcode_vertical -> only if barcode_presence = absent
      All presence attributes (logo_presence, character_presence, text_presence,
      snipe_presence, barcode_presence) ALWAYS get present or absent — never not_applicable.

{
  "logo_presence": "...",
  "logo_horizontal": "...",
  "logo_vertical": "...",
  "logo_prominence": "...",
  "logo_proportion": "...",
  "character_presence": "...",
  "character_position": "...",
  "character_scale": "...",
  "character_orientation": "...",
  "character_proportion": "...",
  "character_color": "...",
  "text_presence": "...",
  "text_color": "...",
  "text_position": "...",
  "text_scale": "...",
  "font_family": "...",
  "background_color": "...",
  "background_pattern": "...",
  "snipe_presence": "...",
  "snipe_density": "...",
  "snipe_shape": "...",
  "barcode_presence": "...",
  "barcode_horizontal": "...",
  "barcode_vertical": "..."
}"""


# ─── EXTRACTION ──────────────────────────────────────────────────────────────
def load_image_b64(path):
    with open(path, "rb") as f:
        return base64.b64encode(f.read()).decode("utf-8")


def extract_attributes(image_path):
    ext  = os.path.splitext(image_path)[1].lower()
    mime = "image/jpeg" if ext in (".jpg", ".jpeg") else "image/png"
    b64  = load_image_b64(image_path)

    # o-series models (o1, o3, o4-mini): gateway may ignore temperature
    is_o_series = MODEL.startswith("o") and any(c.isdigit() for c in MODEL)
    messages = [{
        "role": "user",
        "content": [
            {"type": "text", "text": EXTRACTION_PROMPT},
            {"type": "image_url", "image_url": {
                "url":    f"data:{mime};base64,{b64}",
                "detail": "high",
            }},
        ],
    }]

    max_tok = 800 if is_o_series else 600
    raw = jedai_complete(
        MODEL, messages, temperature=0.0, max_tokens=max_tok, timeout=180
    ).strip()
    if raw.startswith("```"):
        lines = raw.split("\n")
        raw = "\n".join(lines[1:-1] if lines[-1].strip() == "```" else lines[1:])
    try:
        return json.loads(raw)
    except json.JSONDecodeError:
        start, end = raw.find("{"), raw.rfind("}") + 1
        if start >= 0 and end > start:
            try:
                return json.loads(raw[start:end])
            except Exception:
                pass
    print(f"  [WARN] JSON parse failed: {raw[:120]}")
    return {}


# ─── SCORING ──────────────────────────────────────────────────────────────────
def normalize(text):
    text = text.lower().strip()
    text = re.sub(r"[-_/]", " ", text)
    text = re.sub(r"[^\w\s]", "", text)
    return re.sub(r"\s+", " ", text).strip()


def score_attr(extracted, expected, attr):
    """Returns (outcome, score). 'na' entries are excluded from accuracy denominator."""
    if not expected or expected.strip().lower() == "not_applicable":
        return "na", 0.0

    ext = normalize(str(extracted)) if extracted else ""
    exp = normalize(str(expected))

    # absent==absent is always correct
    if ext == "absent" and exp == "absent":
        return "correct", 1.0

    if not ext or ext in ("not applicable", "not visible", "n/a", "absent", "none"):
        return "incorrect", 0.0

    # Color attributes: normalize synonyms first, then exact match, then fuzzy
    if attr in COLOR_ATTRS:
        ext_c = normalize_color(ext)
        exp_c = normalize_color(exp)
        if ext_c == exp_c:
            return "correct", 1.0
        score = fuzz.token_set_ratio(ext_c, exp_c) / 100.0
        return ("correct" if score >= FUZZY_THRESHOLD else "incorrect"), round(score, 4)

    if attr in OPEN_ENDED:
        score = fuzz.token_set_ratio(ext, exp) / 100.0
        return ("correct" if score >= FUZZY_THRESHOLD else "incorrect"), round(score, 4)

    # Categorical: exact match (substring tolerance kept for multi-word labels)
    match = ext == exp or exp in ext or ext in exp
    return ("correct" if match else "incorrect"), (1.0 if match else 0.0)


# ─── LOAD DATASET ─────────────────────────────────────────────────────────────
def load_dataset():
    real_map = {}
    with open(REAL_IMAGES_FILE, encoding="utf-8") as f:
        for r in json.load(f):
            real_map[r["image_id"]] = r["image_path"]

    images = []
    with open(GT_CSV, encoding="utf-8") as f:
        for row in csv.DictReader(f):
            if not row["image_file"]:
                continue  # 4 content-policy-rejected images

            if row["eval_type"] == "real_pass":
                img_path = real_map.get(row["image_id"], "")
            else:
                img_path = os.path.join(GEN_DIR, row["image_file"])

            if not img_path or not os.path.exists(img_path):
                print(f"  [SKIP] {row['image_id']} — image not found")
                continue

            images.append({
                "image_id":         row["image_id"],
                "image_path":       img_path,
                "eval_type":        row["eval_type"],
                "label":            row["label"],
                "attribute_tested": row["attribute_tested"],
                "ground_truth":     {a: row.get(a, "") for a in ALL_ATTRS},
            })

    return images


# ─── SCORING ─────────────────────────────────────────────────────────────────
def run_scoring(images, cache):
    all_results = []
    for img in images:
        entry = cache.get(img["image_id"])
        if not entry:
            print(f"  [SKIP] {img['image_id']} — no extraction in cache")
            continue

        extracted = entry.get("extracted", {})
        gt        = img["ground_truth"]

        for attr in ALL_ATTRS:
            ext_val = str(extracted.get(attr, "")).strip()
            gt_val  = str(gt.get(attr, "")).strip()
            outcome, score = score_attr(ext_val, gt_val, attr)

            all_results.append({
                "image_id":     img["image_id"],
                "eval_type":    img["eval_type"],
                "label":        img["label"],
                "attribute":    attr,
                "attr_type":    "open_ended" if attr in OPEN_ENDED else "categorical",
                "ground_truth": gt_val,
                "extracted":    ext_val,
                "score":        score,
                "outcome":      outcome,
            })

    return all_results


# ─── METRICS ──────────────────────────────────────────────────────────────────
def compute(results):
    correct   = sum(1 for r in results if r["outcome"] == "correct")
    incorrect = sum(1 for r in results if r["outcome"] == "incorrect")
    na        = sum(1 for r in results if r["outcome"] == "na")
    total     = correct + incorrect
    return {
        "correct": correct, "incorrect": incorrect, "na": na,
        "total": total,
        "accuracy": round(correct / total, 4) if total else 0.0,
    }


def build_summary(images, all_results, n_pass, n_fail):
    n_attrs = len(ALL_ATTRS)
    overall  = compute(all_results)
    cat_res  = compute([r for r in all_results if r["attr_type"] == "categorical"])
    oe_res   = compute([r for r in all_results if r["attr_type"] == "open_ended"])

    per_attr = {}
    for attr in ALL_ATTRS:
        per_attr[attr] = compute([r for r in all_results if r["attribute"] == attr])
        per_attr[attr]["attr_type"] = "open_ended" if attr in OPEN_ENDED else "categorical"

    return {
        "config": {
            "model":           MODEL,
            "total_images":    len(images),
            "pass_images":     n_pass,
            "fail_images":     n_fail,
            "total_pairs":     len(all_results),
            "fuzzy_threshold": FUZZY_THRESHOLD,
            "attributes":      n_attrs,
        },
        f"overall_{n_attrs}":           overall,
        f"categorical_{len(CATEGORICAL)}": cat_res,
        f"open_ended_{len(OPEN_ENDED)}": oe_res,
        "per_attribute":                per_attr,
    }


def print_summary(summary):
    n = summary["config"]["attributes"]
    n_cat = len(CATEGORICAL)
    n_oe  = len(OPEN_ENDED)
    imgs  = summary["config"]["total_images"]
    n_pass = summary["config"]["pass_images"]
    n_fail = summary["config"]["fail_images"]

    print(f"\n{'='*65}")
    print(f"EXTRACTION ACCURACY — {n}-ATTRIBUTE SOW SCHEMA  [model: {MODEL}]")
    print(f"{'='*65}")
    print(f"  Images : {imgs}  (PASS={n_pass}, FAIL={n_fail})")
    print()
    print(f"  {'Level':<30}  {'Correct':>8}  {'Total':>7}  {'Accuracy':>9}")
    print(f"  {'-'*59}")

    for label, key in [
        (f"All {n} attributes",         f"overall_{n}"),
        (f"Categorical {n_cat} attrs",  f"categorical_{n_cat}"),
        (f"Open-ended {n_oe} attrs",    f"open_ended_{n_oe}"),
    ]:
        m = summary[key]
        print(f"  {label:<30}  {m['correct']:>8}  {m['total']:>7}  {m['accuracy']:>9.4f}")

    print()
    print(f"  {'Attribute':<26}  {'Type':<12}  {'Correct':>8}  {'Total':>6}  {'Accuracy':>9}")
    print(f"  {'-'*67}")
    for attr, m in sorted(summary["per_attribute"].items(), key=lambda x: -x[1]["accuracy"]):
        t = "open" if attr in OPEN_ENDED else "categorical"
        print(f"  {attr:<26}  {t:<12}  {m['correct']:>8}  {m['total']:>6}  {m['accuracy']:>9.4f}")


# ─── MAIN ─────────────────────────────────────────────────────────────────────
def main():
    rescore_only = "--rescore" in sys.argv
    images       = load_dataset()
    n_pass       = sum(1 for i in images if i["label"] == "PASS")
    n_fail       = sum(1 for i in images if i["label"] == "FAIL")

    print(f"Images loaded : {len(images)}  (PASS={n_pass}, FAIL={n_fail})")
    print(f"Total pairs   : {len(images) * len(ALL_ATTRS)}  ({len(images)} x {len(ALL_ATTRS)})")
    print(f"Model         : {MODEL}")
    print("LLM backend   : JedAI")

    # ── Load or build extraction cache ─────────────────────────────────────
    cache = {}
    if rescore_only:
        if not os.path.exists(OUTPUT_EXTRACTION):
            print("[ERROR] No extraction cache found. Run without --rescore first.")
            sys.exit(1)
        with open(OUTPUT_EXTRACTION, encoding="utf-8") as f:
            cache = json.load(f)
        print(f"--rescore mode: loaded {len(cache)} extractions from {OUTPUT_EXTRACTION}")
        print("Skipping API calls — re-scoring with updated COLOR_NORM_MAP.\n")
    else:
        if os.path.exists(OUTPUT_EXTRACTION):
            with open(OUTPUT_EXTRACTION, encoding="utf-8") as f:
                cache = json.load(f)
            print(f"Cached: {len(cache)} images already extracted")

        remaining = [img for img in images if img["image_id"] not in cache]
        print(f"Remaining: {len(remaining)} images to extract\n")

        errors = 0
        for i, img in enumerate(remaining):
            print(f"[{i+1}/{len(remaining)}] {img['image_id']} | {img['eval_type']} | {img['label']}")
            try:
                extracted = extract_attributes(img["image_path"])
                cache[img["image_id"]] = {
                    "image_id":         img["image_id"],
                    "eval_type":        img["eval_type"],
                    "label":            img["label"],
                    "attribute_tested": img["attribute_tested"],
                    "extracted":        extracted,
                }
                with open(OUTPUT_EXTRACTION, "w", encoding="utf-8") as f:
                    json.dump(cache, f, indent=2, ensure_ascii=False)
                print(f"  -> {len(extracted)}/{len(ALL_ATTRS)} attributes extracted")
            except Exception as e:
                print(f"  -> ERROR: {str(e)[:120]}")
                errors += 1

            if i < len(remaining) - 1:
                time.sleep(SLEEP_SECS)

        print(f"\nExtraction done. Errors: {errors}")

    # ── Score ───────────────────────────────────────────────────────────────
    print("\nScoring against ground truth...")
    all_results = run_scoring(images, cache)

    with open(OUTPUT_RESULTS, "w", encoding="utf-8") as f:
        json.dump(all_results, f, indent=2, ensure_ascii=False)

    # ── Summary ─────────────────────────────────────────────────────────────
    summary = build_summary(images, all_results, n_pass, n_fail)
    with open(OUTPUT_SUMMARY, "w", encoding="utf-8") as f:
        json.dump(summary, f, indent=2, ensure_ascii=False)

    print_summary(summary)

    print(f"\nSaved: {OUTPUT_EXTRACTION if not rescore_only else '(extraction reused)'}")
    print(f"Saved: {OUTPUT_RESULTS}")
    print(f"Saved: {OUTPUT_SUMMARY}")


if __name__ == "__main__":
    main()
