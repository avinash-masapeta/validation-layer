"""
Generate PASS/FAIL prompts for ALL 33 taxonomy attributes across 10 guides.
Each attribute tagged with tier (1=visual, 2=partial, 3=non-visual).

Key design decisions:
- Base prompt is LEAN — only essential visual elements, not all 33 at once
- FAIL prompts lead with the violation as the DOMINANT signal
- Tier 3 attributes are included but flagged — results reflect generation model limitation
- Coupled neighbors labeled UNKNOWN

Outputs:
  prompt_dataset_all33.csv
  ground_truth_all33.csv
"""

import csv

OUTPUT_PROMPTS = "prompt_dataset_all33.csv"
OUTPUT_GT      = "ground_truth_all33.csv"


# ═══════════════════════════════════════════════════════════
# GUIDE PROFILES
# ═══════════════════════════════════════════════════════════

GUIDE_PROFILES = {
    "467122_3_minnie_mouse_packaging_guide": {
        "property": "Disney Minnie Mouse",
        "character_desc": "Minnie Mouse in her classic red polka-dot dress and bow",
        "palette": "pink, black, white, red",
        "logo_desc": "Disney Minnie Mouse logo in black holding shape",
        "logo_position": "top-left",
        "background": "pink polka-dot pattern liner",
        "pose": "upper body crop",
        "font": "Beloved Sans Bold",
        "product_type": "toy packaging box",
    },
    "466910": {
        "property": "Disney General",
        "character_desc": "Disney character art in approved pose",
        "palette": "brand-approved Pantone colors",
        "logo_desc": "Core Disney Brand Logo",
        "logo_position": "top-left",
        "background": "environmental themed background",
        "pose": "approved character crop",
        "font": "Helvetica Neue LT STD 67 Medium Condensed",
        "product_type": "toy packaging window box",
    },
    "470161": {
        "property": "Ice Age",
        "character_desc": "Scrat the saber-toothed squirrel holding his acorn",
        "palette": "icy blue, brown, white",
        "logo_desc": "Ice Age franchise logo",
        "logo_position": "top-left",
        "background": "icy glacial environmental background",
        "pose": "character crop above wrist",
        "font": "Inspire Black all caps",
        "product_type": "toy packaging closed box",
    },
    "471448_3": {
        "property": "Disney Lilo and Stitch",
        "character_desc": "Stitch the blue alien in playful pose",
        "palette": "Pantone Medium Blue, 3255 C, 2728 C",
        "logo_desc": "Disney Lilo and Stitch property logo",
        "logo_position": "top-left",
        "background": "tropical Hawaiian themed background",
        "pose": "approved character crop",
        "font": "approved franchise font",
        "product_type": "toy packaging open box",
    },
    "481751": {
        "property": "National Geographic",
        "character_desc": "large engaging photographic wildlife image",
        "palette": "yellow, beige, black, white",
        "logo_desc": "National Geographic yellow rectangular frame logo",
        "logo_position": "top-left",
        "background": "paper stock with topographic lines",
        "pose": "photographic hero image",
        "font": "Geograph",
        "product_type": "window box packaging",
    },
    "604555_4": {
        "property": "Disney Princess Ariel",
        "character_desc": "Ariel showing upper body and part of her tail",
        "palette": "ocean blues Pantone 7461 C with white",
        "logo_desc": "Disney Princess logo",
        "logo_position": "top-left",
        "background": "underwater ocean themed background",
        "pose": "upper body with tail visible",
        "font": "BauerBodoniStd-Bold",
        "product_type": "window box packaging",
    },
    "607552_2": {
        "property": "ESPN",
        "character_desc": "sports-themed product imagery",
        "palette": "Pantone 032 red, black, white",
        "logo_desc": "ESPN logo",
        "logo_position": "top-left",
        "background": "bold red background with black trade dress line",
        "pose": "product-focused hero image",
        "font": "Playoff Pro Sans Heavy all caps",
        "product_type": "sports product packaging",
    },
    "646642_sw_visions_pkg": {
        "property": "Star Wars Visions",
        "character_desc": "anime-style Star Wars Visions character in dynamic pose",
        "palette": "dark background with neon accents",
        "logo_desc": "Star Wars Visions logo",
        "logo_position": "centered top",
        "background": "dark space themed anime aesthetic background",
        "pose": "dynamic action pose",
        "font": "UWR DIN Black",
        "product_type": "hang tag packaging",
    },
    "943479": {
        "property": "National Geographic Apparel",
        "character_desc": "National Geographic yellow icon and wordmark on garment",
        "palette": "Nat Geo Yellow, black, white",
        "logo_desc": "National Geographic yellow rectangle icon with wordmark",
        "logo_position": "top-left",
        "background": "garment fabric background",
        "pose": "logo and label focused",
        "font": "brand-approved label typography",
        "product_type": "apparel T-shirt with hang tag",
    },
    "955092_2": {
        "property": "Disney Iwaju",
        "character_desc": "Ethan with natural locs hairstyle alongside Legend the three-legged dog",
        "palette": "vibrant Afrofuturist colors",
        "logo_desc": "Disney Iwaju logo in black holding shape",
        "logo_position": "top-center",
        "background": "Afrofuturist Lagos-inspired environmental background",
        "pose": "character grouping two or more characters",
        "font": "Bebas Neue Regular all caps",
        "product_type": "toy packaging box",
    },
}


# ═══════════════════════════════════════════════════════════
# TIER MAP + COUPLING
# ═══════════════════════════════════════════════════════════

TIER_MAP = {
    # Tier 1 — Visual
    "logo_position": 1, "logo_visibility": 1, "logo_scale": 1,
    "logo_hierarchy": 1, "logo_background": 1, "logo_style": 1, "logo_alignment": 1,
    "character_position": 1, "character_cropping": 1, "character_orientation": 1,
    "character_scale": 1, "character_integrity": 1,
    "background_type": 1, "background_alignment": 1, "background_constraints": 1,
    "callout_count": 1, "callout_presence": 1,
    "qr_code_presence": 1, "qr_code_position": 1,
    # Tier 2 — Partial
    "color_palette": 2, "background_color": 2, "element_color": 2,
    "element_position": 2, "element_alignment": 2, "spacing_rules": 2,
    "text_color": 2, "text_effect": 2, "qr_code_quality": 2, "element_size": 2,
    # Tier 3 — Non-visual
    "font_family": 3, "font_style": 3, "element_dimensions": 3,
}

TIER_NOTES = {
    1: "",
    2: "partially visual — requires comparison judgment",
    3: "non-visual — DALL-E cannot reliably control this; results reflect generation model limitation, not pipeline failure",
}

COUPLED_GROUPS = {
    "spatial": ["logo_position", "element_position", "element_alignment",
                "spacing_rules", "character_position"],
    "char_spatial": ["character_position", "character_cropping",
                     "character_scale", "background_alignment"],
    "color": ["color_palette", "background_color", "element_color"],
    "logo_spatial": ["logo_position", "logo_alignment"],
}

_attr_to_groups = {}
for grp, members in COUPLED_GROUPS.items():
    for attr in members:
        _attr_to_groups.setdefault(attr, []).append(grp)


def get_coupled_neighbors(attr_name):
    neighbors = set()
    for g in _attr_to_groups.get(attr_name, []):
        for a in COUPLED_GROUPS[g]:
            if a != attr_name:
                neighbors.add(a)
    return list(neighbors)


def is_independent(attr_name):
    return attr_name not in _attr_to_groups


ALL_ATTRS = sorted(TIER_MAP.keys())


# ═══════════════════════════════════════════════════════════
# VIOLATION TEMPLATES — DOMINANT signal per attribute
# ═══════════════════════════════════════════════════════════

VIOLATIONS = {
    # ── TIER 1: Logo ──
    "logo_position":     {"fail": "CRITICAL: The brand logo is clearly placed at BOTTOM-RIGHT corner, NOT at {logo_position}. This is the main visible difference.", "label": "logo at wrong position"},
    "logo_visibility":   {"fail": "CRITICAL: The brand logo is extremely tiny, barely 5% of its normal size, almost invisible in the far corner.", "label": "logo not visible"},
    "logo_scale":        {"fail": "CRITICAL: The brand logo is heavily stretched horizontally to twice its width, visibly distorted.", "label": "logo distorted/stretched"},
    "logo_hierarchy":    {"fail": "CRITICAL: A large secondary licensee logo dominates the packaging, while the brand logo is much smaller below it.", "label": "brand logo not dominant"},
    "logo_background":   {"fail": "CRITICAL: The brand logo is placed directly on a busy multicolored patterned area making it completely unreadable.", "label": "logo on unreadable background"},
    "logo_style":        {"fail": "CRITICAL: The brand logo appears without any holding shape or frame, floating freely on the background.", "label": "logo missing holding shape"},
    "logo_alignment":    {"fail": "CRITICAL: The brand logo is visibly tilted and misaligned, shifted far from the text elements.", "label": "logo misaligned"},

    # ── TIER 1: Character ──
    "character_position":    {"fail": "CRITICAL: The character art is pushed to the far TOP-RIGHT corner of the packaging, away from its normal position.", "label": "character at wrong position"},
    "character_cropping":    {"fail": "CRITICAL: The character art is heavily cropped showing ONLY THE FACE, no body visible at all.", "label": "character over-cropped to face only"},
    "character_orientation": {"fail": "CRITICAL: The character art is HORIZONTALLY FLIPPED, appearing as a mirror image of the original.", "label": "character flipped/mirrored"},
    "character_scale":       {"fail": "CRITICAL: The character art is extremely small, barely visible, taking up less than 10% of the packaging.", "label": "character too small"},
    "character_integrity":   {"fail": "CRITICAL: The character art has completely WRONG COLORS — skin is blue, outfit is green, nothing matches the original.", "label": "character colors altered"},

    # ── TIER 1: Background ──
    "background_type":        {"fail": "CRITICAL: The background is PLAIN SOLID WHITE with absolutely no theming, pattern, or brand elements.", "label": "wrong background type"},
    "background_alignment":   {"fail": "CRITICAL: The background image is visibly TILTED at a 15-degree angle, misaligned with the packaging edges.", "label": "background tilted/misaligned"},
    "background_constraints": {"fail": "CRITICAL: The background pattern OVERLAPS heavily with the logo and text, making both unreadable.", "label": "background overlaps elements"},

    # ── TIER 1: Callouts & QR ──
    "callout_count":    {"fail": "CRITICAL: There are SEVEN callout snipes cluttering the packaging, far more than the allowed maximum.", "label": "too many callouts (7)"},
    "callout_presence": {"fail": "CRITICAL: There are ZERO product feature callouts on the packaging, completely absent.", "label": "callouts missing entirely"},
    "qr_code_presence": {"fail": "CRITICAL: There is NO QR code anywhere on the packaging.", "label": "QR code missing"},
    "qr_code_position": {"fail": "CRITICAL: The QR code is placed directly over the character art in the CENTER of the packaging.", "label": "QR code misplaced on character"},

    # ── TIER 2: Color ──
    "color_palette":    {"fail": "CRITICAL: The packaging uses NEON GREEN and BRIGHT ORANGE colors that are completely off-brand.", "label": "wrong color palette"},
    "background_color": {"fail": "CRITICAL: The background is BRIGHT YELLOW, completely clashing with the brand palette.", "label": "wrong background color"},
    "element_color":    {"fail": "CRITICAL: All text and logo elements are in BRIGHT RED, not the approved brand colors.", "label": "wrong element colors"},

    # ── TIER 2: Layout ──
    "element_position":  {"fail": "CRITICAL: The product name text is placed at TOP-LEFT directly overlapping the logo area.", "label": "elements misplaced/overlapping"},
    "element_alignment": {"fail": "CRITICAL: All text and graphic elements are scattered randomly at different angles, no alignment.", "label": "elements randomly scattered"},
    "spacing_rules":     {"fail": "CRITICAL: All elements are CROWDED together with zero spacing, overlapping edges everywhere.", "label": "no spacing between elements"},

    # ── TIER 2: Typography visual ──
    "text_color":  {"fail": "CRITICAL: All text is in DARK GRAY on a DARK background, completely unreadable.", "label": "text unreadable on background"},
    "text_effect": {"fail": "CRITICAL: The product name has NO outline and NO shadow, blending completely into the background.", "label": "missing text outline/shadow"},

    # ── TIER 2: Size & QR quality ──
    "qr_code_quality": {"fail": "CRITICAL: The QR code is extremely BLURRY and PIXELATED, clearly a low-resolution screenshot.", "label": "QR code blurry/pixelated"},
    "element_size":    {"fail": "CRITICAL: The brand logo is MASSIVELY OVERSIZED, taking up half the entire packaging surface.", "label": "element grossly oversized"},

    # ── TIER 3: Non-visual ──
    "font_family":        {"fail": "CRITICAL: All text on packaging is in COMIC SANS font instead of the approved brand font.", "label": "wrong font family (Comic Sans)"},
    "font_style":         {"fail": "CRITICAL: All text is in THIN LIGHT ITALIC style, barely readable, not the required bold.", "label": "wrong font style (thin italic)"},
    "element_dimensions": {"fail": "CRITICAL: The hang tag is in a SQUARE format instead of the required 2.5x4 inch portrait rectangle.", "label": "wrong dimensions (square instead of portrait)"},
}


# ═══════════════════════════════════════════════════════════
# PROMPT BUILDER — LEAN base, DOMINANT violation
# ═══════════════════════════════════════════════════════════

def fill(text, profile):
    for key, val in profile.items():
        text = text.replace("{" + key + "}", str(val))
    return text


def build_base_prompt(profile):
    """Lean compliant base — only essential visual elements."""
    return (
        f"Photorealistic {profile['product_type']} for {profile['property']}. "
        f"{profile['character_desc']}, {profile['pose']}. "
        f"{profile['logo_desc']} at {profile['logo_position']}, clearly visible. "
        f"{profile['background']}. "
        f"Color palette: {profile['palette']}. "
        f"2 product feature callout snipes. QR code in bottom-right corner. "
        f"Professional licensed product packaging with legal text and product name."
    )


def build_fail_prompt(profile, violation_text):
    """Violation-first prompt — violation is the DOMINANT signal."""
    base_context = (
        f"Photorealistic {profile['product_type']} for {profile['property']}. "
        f"{profile['character_desc']}. "
        f"{profile['background']}. "
        f"Color palette: {profile['palette']}. "
        f"Professional licensed product packaging."
    )
    return f"{fill(violation_text, profile)} — {base_context}"


# ═══════════════════════════════════════════════════════════
# MAIN
# ═══════════════════════════════════════════════════════════

def generate():
    prompt_rows = []
    gt_rows = []
    pid = 0

    for guide_id, profile in GUIDE_PROFILES.items():
        base = build_base_prompt(profile)
        print(f"\n{'='*60}")
        print(f"Guide: {guide_id} ({profile['property']})")

        # ── FULL PASS ──
        pid += 1
        prompt_rows.append({
            "prompt_id": f"A{pid:04d}",
            "guide_id": guide_id,
            "property": profile["property"],
            "variant": "FULL_PASS",
            "attribute_tested": "ALL",
            "tier": 0,
            "attribute_type": "baseline",
            "label": "PASS",
            "prompt": base,
        })
        for attr in ALL_ATTRS:
            gt_rows.append({
                "prompt_id": f"A{pid:04d}",
                "guide_id": guide_id,
                "attribute_name": attr,
                "tier": TIER_MAP[attr],
                "attribute_type": "independent" if is_independent(attr) else "coupled",
                "expected_label": "PASS",
                "violation_desc": "",
                "tier_note": TIER_NOTES[TIER_MAP[attr]],
            })

        # ── FAIL per attribute ──
        for attr_name in ALL_ATTRS:
            if attr_name not in VIOLATIONS:
                continue

            v = VIOLATIONS[attr_name]
            neighbors = get_coupled_neighbors(attr_name)
            tier = TIER_MAP[attr_name]

            pid += 1
            fail_prompt = build_fail_prompt(profile, v["fail"])

            prompt_rows.append({
                "prompt_id": f"A{pid:04d}",
                "guide_id": guide_id,
                "property": profile["property"],
                "variant": f"FAIL_{attr_name}",
                "attribute_tested": attr_name,
                "tier": tier,
                "attribute_type": "independent" if is_independent(attr_name) else "coupled",
                "label": "FAIL",
                "prompt": fail_prompt,
            })

            for a in ALL_ATTRS:
                if a == attr_name:
                    expected = "FAIL"
                    desc = v["label"]
                elif a in neighbors:
                    expected = "UNKNOWN"
                    desc = f"coupled with {attr_name}"
                else:
                    expected = "PASS"
                    desc = ""

                gt_rows.append({
                    "prompt_id": f"A{pid:04d}",
                    "guide_id": guide_id,
                    "attribute_name": a,
                    "tier": TIER_MAP[a],
                    "attribute_type": "independent" if is_independent(a) else "coupled",
                    "expected_label": expected,
                    "violation_desc": desc,
                    "tier_note": TIER_NOTES[TIER_MAP[a]],
                })

        print(f"  Prompts so far: {pid}")

    # Write CSVs
    with open(OUTPUT_PROMPTS, "w", encoding="utf-8", newline="") as f:
        w = csv.DictWriter(f, fieldnames=[
            "prompt_id", "guide_id", "property", "variant",
            "attribute_tested", "tier", "attribute_type", "label", "prompt",
        ])
        w.writeheader()
        w.writerows(prompt_rows)

    with open(OUTPUT_GT, "w", encoding="utf-8", newline="") as f:
        w = csv.DictWriter(f, fieldnames=[
            "prompt_id", "guide_id", "attribute_name", "tier",
            "attribute_type", "expected_label", "violation_desc", "tier_note",
        ])
        w.writeheader()
        w.writerows(gt_rows)

    # Summary
    n_pass = sum(1 for r in prompt_rows if r["label"] == "PASS")
    n_fail = sum(1 for r in prompt_rows if r["label"] == "FAIL")
    n_unknown = sum(1 for r in gt_rows if r["expected_label"] == "UNKNOWN")
    t1 = sum(1 for r in prompt_rows if r["label"] == "FAIL" and r["tier"] == 1)
    t2 = sum(1 for r in prompt_rows if r["label"] == "FAIL" and r["tier"] == 2)
    t3 = sum(1 for r in prompt_rows if r["label"] == "FAIL" and r["tier"] == 3)

    print(f"\n{'='*60}")
    print("DONE — All 33 Attributes")
    print(f"{'='*60}")
    print(f"  Guides:        {len(GUIDE_PROFILES)}")
    print(f"  Attributes:    {len(ALL_ATTRS)}")
    print(f"    Tier 1 (visual):      {sum(1 for t in TIER_MAP.values() if t==1)}")
    print(f"    Tier 2 (partial):     {sum(1 for t in TIER_MAP.values() if t==2)}")
    print(f"    Tier 3 (non-visual):  {sum(1 for t in TIER_MAP.values() if t==3)}")
    print(f"  Total prompts: {len(prompt_rows)} ({n_pass} PASS, {n_fail} FAIL)")
    print(f"    Tier 1 FAIL: {t1}")
    print(f"    Tier 2 FAIL: {t2}")
    print(f"    Tier 3 FAIL: {t3}")
    print(f"  Ground truth:  {len(gt_rows)} labels ({n_unknown} UNKNOWN)")
    print(f"\n  -> {OUTPUT_PROMPTS}")
    print(f"  -> {OUTPUT_GT}")


if __name__ == "__main__":
    generate()
