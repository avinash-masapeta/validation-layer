"""
Minimal JedAI (Disney) LLM client — drop-in for other projects.
Requires: pip install requests python-dotenv
"""
from __future__ import annotations

import base64
import os
import re
import time
import uuid
from pathlib import Path
from typing import Any
from urllib.parse import urlparse

import requests
from dotenv import load_dotenv

# Load .env from cwd, then next to this file
load_dotenv()
load_dotenv(Path(__file__).resolve().parent / ".env")

MAX_RETRIES = 4


def _strip_env_quotes(value: str) -> str:
    s = value.strip()
    if len(s) >= 2 and s[0] == s[-1] and s[0] in "'\"":
        return s[1:-1]
    return s


JEDAI_BASE_URL = os.environ.get(
    "JEDAI_BASE_URL",
    "https://jedai.wdprapps.disney.com/jedai/webapi/v1/",
)
CLIENT_ID = _strip_env_quotes(os.environ.get("CLIENT_ID", ""))
CLIENT_SECRET = _strip_env_quotes(os.environ.get("CLIENT_SECRET", ""))
TOKEN_URL = os.environ.get("TOKEN_URL", "https://stg.authorization.go.com/token").strip()
TOKEN_SCOPE = os.environ.get("TOKEN_SCOPE", "RETURN_ALL_CLIENT_SCOPES").strip()
JEDAI_STATIC_TOKEN = _strip_env_quotes(
    os.environ.get("JEDAI_API_TOKEN")
    or os.environ.get("AUTH_TOKEN")
    or os.environ.get("JEDAI_TOKEN", "")
)
JEDAI_API_URL = os.environ.get("JEDAI_API_URL", "").strip()
JEDAI_MODEL_URL_TEMPLATE = os.environ.get("JEDAI_MODEL_URL_TEMPLATE", "").strip()
JEDAI_TOP_K = int(os.environ.get("JEDAI_TOP_K", "40"))
JEDAI_TOP_P = float(os.environ.get("JEDAI_TOP_P", "0.95"))
JEDAI_PAYLOAD_FORMAT = os.environ.get("JEDAI_PAYLOAD_FORMAT", "").strip().lower()

_TOKEN_CACHE_VALUE = ""
_TOKEN_CACHE_EXPIRES_AT = 0.0


def jedai_configured() -> bool:
    """True if static token or OAuth client credentials are set."""
    return bool(JEDAI_STATIC_TOKEN) or (bool(CLIENT_ID) and bool(CLIENT_SECRET))


def ensure_jedai_configured() -> None:
    """Raise if JedAI auth is not configured (this repo is JedAI-only for LLMs)."""
    if jedai_configured():
        return
    raise RuntimeError(
        "JedAI is not configured. Set JEDAI_API_TOKEN (or AUTH_TOKEN / JEDAI_TOKEN) "
        "or CLIENT_ID + CLIENT_SECRET (+ TOKEN_URL) in .env — see .env.example."
    )


def _default_models_endpoint(base_url: str) -> str:
    path = urlparse(base_url).path.rstrip("/").lower()
    if path.endswith("/jedai/webapi/v1") or path.endswith("/jedai/llm/v1"):
        return "genai/models"
    return "jedai/llm/v1/genai/models"


JEDAI_MODELS_ENDPOINT = os.environ.get(
    "JEDAI_MODELS_ENDPOINT",
    _default_models_endpoint(JEDAI_BASE_URL),
).strip().strip("/")


def get_jedai_access_token() -> str:
    global _TOKEN_CACHE_EXPIRES_AT, _TOKEN_CACHE_VALUE

    if JEDAI_STATIC_TOKEN:
        return JEDAI_STATIC_TOKEN
    if _TOKEN_CACHE_VALUE and time.time() < _TOKEN_CACHE_EXPIRES_AT:
        return _TOKEN_CACHE_VALUE
    if not CLIENT_ID or not CLIENT_SECRET:
        raise RuntimeError(
            "Set CLIENT_ID and CLIENT_SECRET, or JEDAI_API_TOKEN / AUTH_TOKEN / JEDAI_TOKEN."
        )

    resp = requests.post(
        TOKEN_URL,
        data={
            "grant_type": "client_credentials",
            "scope": TOKEN_SCOPE,
            "client_id": CLIENT_ID,
            "client_secret": CLIENT_SECRET,
        },
        headers={"Content-Type": "application/x-www-form-urlencoded"},
        timeout=60,
    )
    resp.raise_for_status()
    data = resp.json()
    token = _strip_env_quotes(str(data.get("access_token", "")))
    if not token:
        raise RuntimeError("Token response did not include access_token")

    expires_in = float(data.get("expires_in") or 3600)
    _TOKEN_CACHE_VALUE = token
    _TOKEN_CACHE_EXPIRES_AT = time.time() + max(60, expires_in - 60)
    return token


def jedai_models_list_url() -> str:
    return f"{JEDAI_BASE_URL.rstrip('/')}/{JEDAI_MODELS_ENDPOINT}"


def jedai_request_headers() -> dict[str, str]:
    return {
        "Authorization": f"Bearer {get_jedai_access_token()}",
        "X-Disney-Internal-conversationId": str(uuid.uuid4()),
        "X-Disney-Internal-correlationId": str(uuid.uuid4()),
        "Content-Type": "application/json",
    }


def jedai_list_models() -> Any:
    url = jedai_models_list_url()
    resp = requests.get(url, headers=jedai_request_headers(), timeout=60)
    resp.raise_for_status()
    return resp.json()


def _jedai_infer_url(model_id: str) -> str:
    if JEDAI_MODEL_URL_TEMPLATE:
        return JEDAI_MODEL_URL_TEMPLATE.replace("{MODEL}", model_id)
    if "{MODEL}" in JEDAI_BASE_URL:
        return JEDAI_BASE_URL.replace("{MODEL}", model_id)
    if JEDAI_API_URL:
        return f"{JEDAI_API_URL.rstrip('/')}/{model_id.lstrip('/')}"
    return f"{jedai_models_list_url()}/{model_id}"


def _parse_data_url(data_url: str) -> tuple[str, str]:
    if "," not in data_url or not data_url.startswith("data:"):
        raise ValueError("bad image data URL")
    meta, b64 = data_url.split(",", 1)
    mime = "image/png"
    if ";" in meta:
        mime = meta.split(";")[0].split(":", 1)[1]
    return mime, b64


def _openai_multipart_to_gemini_parts(parts: list[dict]) -> list[dict[str, Any]]:
    out: list[dict[str, Any]] = []
    for p in parts:
        if p.get("type") == "text":
            out.append({"text": p.get("text", "")})
        elif p.get("type") == "image_url":
            url = (p.get("image_url") or {}).get("url", "")
            if url.startswith("data:"):
                mime, b64 = _parse_data_url(url)
                out.append({"inline_data": {"mime_type": mime, "data": b64}})
    return out


def _jedai_messages_to_gemini_body(
    messages: list[dict[str, Any]], max_tokens: int, temperature: float
) -> dict[str, Any]:
    system_text = ""
    user_parts: list[dict[str, Any]] = []
    for msg in messages:
        role = msg.get("role", "")
        content = msg.get("content")
        if role == "system":
            system_text = content if isinstance(content, str) else ""
        elif role == "user":
            if isinstance(content, str):
                user_parts.append({"text": content})
            elif isinstance(content, list):
                user_parts.extend(_openai_multipart_to_gemini_parts(content))
    body: dict[str, Any] = {
        "contents": [{"role": "user", "parts": user_parts}],
        "generationConfig": {
            "temperature": float(temperature),
            "topK": JEDAI_TOP_K,
            "topP": JEDAI_TOP_P,
            "maxOutputTokens": max_tokens,
        },
    }
    if system_text.strip():
        path = urlparse(jedai_models_list_url()).path.lower()
        system_key = "system_instruction" if "/jedai/llm/v1/" in f"{path}/" else "systemInstruction"
        body[system_key] = {"parts": [{"text": system_text}]}
    return body


def _jedai_payload_kind(model_id: str) -> str:
    if JEDAI_PAYLOAD_FORMAT in ("gemini", "anthropic", "openai"):
        return JEDAI_PAYLOAD_FORMAT
    m = model_id.lower()
    if m.startswith("claude"):
        return "openai"
    if m.startswith("gpt-") or m.startswith(("o1", "o3", "o4")):
        return "openai"
    return "gemini"


def _openai_multipart_to_anthropic_blocks(parts: list[dict]) -> list[dict[str, Any]]:
    out: list[dict[str, Any]] = []
    for p in parts:
        if p.get("type") == "text":
            out.append({"type": "text", "text": p.get("text", "")})
        elif p.get("type") == "image_url":
            url = (p.get("image_url") or {}).get("url", "")
            if url.startswith("data:"):
                mime, b64 = _parse_data_url(url)
                out.append(
                    {
                        "type": "image",
                        "source": {"type": "base64", "media_type": mime, "data": b64},
                    }
                )
    return out


def _jedai_messages_to_anthropic_body(
    model_id: str, messages: list[dict[str, Any]], max_tokens: int, temperature: float
) -> dict[str, Any]:
    system_text = ""
    user_blocks: list[dict[str, Any]] = []
    for msg in messages:
        role = msg.get("role", "")
        content = msg.get("content")
        if role == "system":
            system_text = content if isinstance(content, str) else ""
        elif role == "user":
            if isinstance(content, str):
                user_blocks.append({"type": "text", "text": content})
            elif isinstance(content, list):
                user_blocks.extend(_openai_multipart_to_anthropic_blocks(content))
    body: dict[str, Any] = {
        "model": model_id,
        "max_tokens": max_tokens,
        "temperature": float(temperature),
        "messages": [{"role": "user", "content": user_blocks}],
    }
    if system_text.strip():
        body["system"] = system_text
    return body


def _jedai_messages_to_openai_body(
    model_id: str, messages: list[dict[str, Any]], max_tokens: int, temperature: float
) -> dict[str, Any]:
    oa_messages: list[dict[str, Any]] = []
    for msg in messages:
        role = msg.get("role", "")
        content = msg.get("content")
        if role not in ("system", "user", "assistant"):
            continue
        if isinstance(content, (str, list)):
            oa_messages.append({"role": role, "content": content})
    return {
        "model": model_id,
        "messages": oa_messages,
        "max_tokens": max_tokens,
        "temperature": float(temperature),
    }


def _jedai_response_text(data: dict[str, Any]) -> str:
    cands = data.get("candidates")
    if isinstance(cands, list) and cands:
        parts = cands[0].get("content", {}).get("parts", [])
        if parts:
            return "".join(p.get("text", "") for p in parts if isinstance(p, dict))
    choices = data.get("choices")
    if isinstance(choices, list) and choices:
        msg = choices[0].get("message") or {}
        c = msg.get("content")
        if isinstance(c, str):
            return c
        if isinstance(c, list):
            chunks = [
                str(block.get("text", ""))
                for block in c
                if isinstance(block, dict) and block.get("type") == "text"
            ]
            if chunks:
                return "".join(chunks)
    content = data.get("content")
    if isinstance(content, str):
        return content
    if isinstance(content, list) and content:
        texts = [
            str(block.get("text", ""))
            for block in content
            if isinstance(block, dict) and block.get("type") == "text"
        ]
        if texts:
            return "".join(texts)
    nested = data.get("message")
    if isinstance(nested, dict) and nested.get("content"):
        return _jedai_response_text(nested)
    if isinstance(data.get("output_text"), str):
        return data["output_text"]
    raise ValueError(f"Unrecognized JedAI response shape; keys={list(data.keys())[:12]}")


def _jedai_build_request_body(
    model_id: str, kind: str, messages: list[dict], max_tokens: int, temperature: float
) -> dict[str, Any]:
    if kind == "anthropic":
        return _jedai_messages_to_anthropic_body(model_id, messages, max_tokens, temperature)
    if kind == "openai":
        return _jedai_messages_to_openai_body(model_id, messages, max_tokens, temperature)
    return _jedai_messages_to_gemini_body(messages, max_tokens, temperature)


def _sleep_backoff(attempt: int, err: str) -> None:
    m = re.search(r"try again in (\d+(?:\.\d+)?)s", err, re.I)
    wait = float(m.group(1)) + 2 if m else min(60, 5 * attempt)
    time.sleep(wait)


def jedai_complete(
    model_id: str,
    messages: list[dict[str, Any]],
    *,
    temperature: float = 0.0,
    max_tokens: int = 1024,
    timeout: int = 120,
) -> str:
    """
    Main call: OpenAI-style `messages`, returns assistant text.
    Model id examples: gpt-4o, gemini-2.5-pro, claude-...
    """
    if not model_id:
        raise ValueError("model_id is required")

    kind = _jedai_payload_kind(model_id)
    url = _jedai_infer_url(model_id)
    headers = jedai_request_headers()
    body = _jedai_build_request_body(model_id, kind, messages, max_tokens, temperature)

    last_err: str | None = None
    for attempt in range(1, MAX_RETRIES + 1):
        try:
            resp = requests.post(url, headers=headers, json=body, timeout=timeout)
            if resp.status_code >= 400:
                snippet = (resp.text or "")[:1200]
                raise RuntimeError(f"HTTP {resp.status_code}: {snippet}")
            return _jedai_response_text(resp.json())
        except Exception as e:
            last_err = str(e)
            if attempt < MAX_RETRIES:
                _sleep_backoff(attempt, last_err)
    raise RuntimeError(f"JedAI request failed after {MAX_RETRIES} retries: {last_err}")


def mime_for_path(path: Path) -> str:
    return {
        ".jpg": "image/jpeg",
        ".jpeg": "image/jpeg",
        ".png": "image/png",
        ".webp": "image/webp",
    }.get(path.suffix.lower(), "image/png")


def messages_vision_user(
    system: str,
    user_text: str,
    image_paths: list[str | Path],
) -> list[dict[str, Any]]:
    """Build OpenAI-style messages with data-URL images (works with gpt-4o / claude via gateway)."""
    content: list[dict[str, Any]] = []
    for p in image_paths:
        p = Path(p)
        b64 = base64.standard_b64encode(p.read_bytes()).decode()
        mime = mime_for_path(p)
        content.append(
            {"type": "image_url", "image_url": {"url": f"data:{mime};base64,{b64}"}}
        )
    content.append({"type": "text", "text": user_text})
    return [
        {"role": "system", "content": system},
        {"role": "user", "content": content},
    ]


# --- Example ---
if __name__ == "__main__":
    mid = os.environ.get("JEDAI_MODEL", "gpt-4.1").strip()
    out = jedai_complete(
        mid,
        [
            {"role": "system", "content": "You are a helpful assistant."},
            {"role": "user", "content": "Reply with one word: ok"},
        ],
        max_tokens=32,
    )
    print(out)
