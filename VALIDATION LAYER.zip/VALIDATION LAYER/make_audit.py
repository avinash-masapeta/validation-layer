import csv
import os
os.chdir(r'C:\Users\S Balavardhan reddy\VALIDATION LAYER')

GUIDES = ['alien_2053001', '466910', '470161', 'minnie_467122', 'disney_princess_2338550']

ATTRS = [
    'logo_presence','logo_horizontal','logo_vertical','logo_prominence','logo_proportion',
    'character_presence','character_position','character_scale','character_orientation',
    'character_proportion','character_color',
    'text_presence','text_color','text_position','text_scale','font_family',
    'background_color','background_pattern',
    'snipe_presence','snipe_density','snipe_shape',
    'barcode_presence','barcode_horizontal','barcode_vertical'
]

QUERIES = {
    'logo_presence':        'A brand logo is {v} on the packaging. Does the style guide require or restrict the presence of a brand logo? Is this compliant?',
    'logo_horizontal':      'The brand logo appears towards the {v} side of the packaging. Does the style guide specify any preferred or restricted horizontal placement for the logo? If placement guidance exists, is this compliant?',
    'logo_vertical':        'The brand logo appears towards the {v} area vertically on the packaging. Does the style guide specify any preferred vertical placement for the logo? If guidance exists, is this compliant?',
    'logo_prominence':      'The brand logo has {v} visual prominence (subtle/standard/dominant). Does the style guide specify how prominent the logo should appear relative to other elements? Is this compliant?',
    'logo_proportion':      'The brand logo appears {v} (proportional means undistorted, distorted means stretched or squished). Does the style guide prohibit distorting the logo proportions? Is this compliant?',
    'character_presence':   'A licensed character is {v} on the packaging. Does the style guide require or restrict the use of a character? Is this compliant?',
    'character_position':   'The character appears in the {v} area of the packaging. Does the style guide define any required or restricted placement for characters? If defined, is this compliant?',
    'character_scale':      'The character occupies a {v} portion of the packaging. Does the style guide specify how large or small the character should appear relative to the layout? Is this compliant?',
    'character_orientation':'The character is depicted as {v}. Does the style guide define approved character poses or orientations? If defined, is this compliant?',
    'character_proportion': 'The character appears {v} (proportional means undistorted, distorted means warped). Does the style guide prohibit distorting the character appearance? Is this compliant?',
    'character_color':      'The character appears in {v} color tones. Does the style guide specify approved or restricted colors for the character? Is this compliant?',
    'text_presence':        'Text is {v} on the packaging. Does the style guide require or restrict the presence of text or copy? Is this compliant?',
    'text_color':           'The main text color is {v}. Does the style guide specify approved or restricted text colors? Is this compliant?',
    'text_position':        'The main text appears in the {v} area of the packaging. Does the style guide specify preferred placement for text or copy? If defined, is this compliant?',
    'text_scale':           'The main text appears {v} in size relative to the packaging. Does the style guide define minimum size or prominence requirements for text? Is this compliant?',
    'font_family':          'The main text uses a {v} typeface. Does the style guide specify approved or restricted typeface styles? Is this compliant?',
    'background_color':     'The dominant background color is {v}. Does the style guide specify approved or restricted background colors? Is this compliant?',
    'background_pattern':   'The background treatment is {v} (solid/gradient/patterned/photographic/illustrated). Does the style guide specify approved background styles? Is this compliant?',
    'snipe_presence':       'Promotional callout badges are {v} on the packaging. Does the style guide allow or restrict the use of such callouts or badges? Is this compliant?',
    'snipe_density':        'The packaging has {v} promotional callout badge(s) (single=one, multiple=more than one). Does the style guide define limits on the number of such elements? Is this compliant?',
    'snipe_shape':          'The promotional callout badge has a {v} shape. Does the style guide define approved shapes or styles for such elements? Is this compliant?',
    'barcode_presence':     'A barcode or QR code is {v} on the packaging. Does the style guide require a barcode or QR code? Is this compliant?',
    'barcode_horizontal':   'The barcode appears towards the {v} side of the packaging. Does the style guide specify any placement rules for barcodes? If defined, is this compliant?',
    'barcode_vertical':     'The barcode appears towards the {v} vertical area of the packaging. Does the style guide specify any placement rules for barcodes? If defined, is this compliant?',
}

OPEN_ENDED = {'character_color', 'text_color', 'background_color', 'font_family'}

SCHEMA = [
    ['# QUERY AUDIT TEMPLATE — MANUAL REVIEW SHEET'],
    ['# -------------------------------------------------------'],
    ['# PURPOSE  : Verify that each query correctly surfaces a real rule from each style guide.'],
    ['# HOW TO USE: Go guide by guide. Open extracted_guides/<guide_id>_extracted.txt. Search for keywords. Fill columns E to J only.'],
    ['# -------------------------------------------------------'],
    ['# COLUMN SCHEMA:'],
    ['# A  guide_id                          = The style guide being audited'],
    ['# B  attribute                          = The packaging attribute (one of 24 SOW attributes)'],
    ['# C  query_used                         = Exact question sent to LLM during validation — DO NOT EDIT'],
    ['# D  attr_type                          = categorical or open_ended (for reference only)'],
    ['# E  does_guide_address_this_attribute  = YES  (explicit rule exists)'],
    ['#                                       = NO   (guide is completely silent on this attribute)'],
    ['#                                       = PARTIAL (guide hints vaguely but no explicit rule)'],
    ['# F  actual_guide_rule_text             = Paste exact sentence from guide. Write NOT MENTIONED if silent.'],
    ['# G  is_query_correctly_phrased         = YES / NO — does the query match guide language well enough?'],
    ['# H  query_needs_fix                    = YES / NO'],
    ['# I  suggested_query                    = Only fill if H=YES. Write your improved query here.'],
    ['# J  notes                              = Edge cases, flags, anything to discuss with the team'],
    ['# -------------------------------------------------------'],
    ['# GUIDES COVERED (5):  alien_2053001 | 466910 | 470161 | minnie_467122 | disney_princess_2338550'],
    ['# IMAGES COVERED    :  33 out of 50 sampled images (66%)'],
    ['# ESTIMATED TIME    :  1.5 to 2 hours total'],
    ['# PRIORITY ORDER    :  alien_2053001 first (real + 9 images), then 466910 and 470161 (most CFs)'],
    ['# -------------------------------------------------------'],
    [],
]

out_path = r'C:\Users\S Balavardhan reddy\VALIDATION LAYER\query_audit_5guides.csv'
with open(out_path, 'w', newline='', encoding='utf-8-sig') as f:
    writer = csv.writer(f)
    for row in SCHEMA:
        writer.writerow(row)
    writer.writerow([
        'guide_id', 'attribute', 'query_used', 'attr_type',
        'does_guide_address_this_attribute',
        'actual_guide_rule_text',
        'is_query_correctly_phrased',
        'query_needs_fix',
        'suggested_query',
        'notes'
    ])
    for guide in GUIDES:
        for attr in ATTRS:
            writer.writerow([
                guide,
                attr,
                QUERIES.get(attr, ''),
                'open_ended' if attr in OPEN_ENDED else 'categorical',
                '', '', '', '', '', ''
            ])
        writer.writerow([])  # blank separator between guides

print(f'Done: {out_path}')
print(f'Data rows: {len(GUIDES) * len(ATTRS)}  (5 guides x 24 attributes)')
