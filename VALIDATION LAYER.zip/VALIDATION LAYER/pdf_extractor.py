import base64
import os
from pathlib import Path

import fitz  # PyMuPDF

_here = Path(__file__).resolve().parent
try:
    from dotenv import load_dotenv
    load_dotenv(_here / ".env", override=True)
except ImportError:
    pass

from jedai_client import ensure_jedai_configured, jedai_complete

ensure_jedai_configured()

VISION_MODEL = (
    os.environ.get("JEDAI_MODEL", "").strip()
    or os.environ.get("PDF_VISION_MODEL", "").strip()
    or "gpt-4.1"
)


# ──────────────────────────────────────────
# STEP 1 — STYLE GUIDE IMAGE → TEXT
# ──────────────────────────────────────────

def guide_image2text(image_bytes: bytes) -> str:
    """
    Given a single image extracted from a style guide page,
    return a plain-text description focused on rules, diagrams,
    and visual examples — NOT product attributes.
    """
    b64 = base64.b64encode(image_bytes).decode("utf-8")

    messages = [{
        "role": "user",
        "content": [
            {
                "type": "text",
                "text": (
                    "This image is from a Disney packaging style guide.\n\n"
                    "Describe everything visible in full detail:\n\n"
                    "1. RULE BEING SHOWN — what packaging or design rule does this image demonstrate?\n"
                    "2. DO / DON'T EXAMPLE — if this shows an approved vs rejected example, "
                    "describe both clearly and state what is correct and what is wrong.\n"
                    "3. DIAGRAM / LAYOUT — if this is a layout diagram, list every numbered or "
                    "labelled element and describe its position and purpose.\n"
                    "4. CHARACTER ART — if character art is shown, describe pose, cropping, "
                    "outline, orientation, and any visible rules about its usage.\n"
                    "5. COLOR SWATCHES — list any color names, PMS codes, or values shown.\n"
                    "6. MEASUREMENTS & SPECS — include any sizes, dimensions, or spacing values.\n\n"
                    "Return plain descriptive text only. "
                    "Be specific — vague descriptions like 'shows branding elements' are not useful."
                )
            },
            {
                "type": "image_url",
                "image_url": {
                    "url"   : f"data:image/png;base64,{b64}",
                    "detail": "high"
                }
            }
        ]
    }]

    return jedai_complete(
        VISION_MODEL, messages, temperature=0.0, max_tokens=1000, timeout=180
    ).strip()


# ──────────────────────────────────────────
# STEP 2 — PROCESS STYLE GUIDE PDF
# ──────────────────────────────────────────

def process_style_guide(pdf_path: str) -> str:
    """
    Extract a style guide PDF into a single text string by:
      1. Extracting text blocks with their page positions
      2. Extracting embedded images with their page positions
      3. Running guide_image2text() on each image
      4. Merging text and image descriptions in reading order (sorted by y position)

    Returns a string with PAGE N: headers, ready to pass into guide2dodonts().
    """
    doc   = fitz.open(pdf_path)
    pages = []

    for page_num, page in enumerate(doc, start=1):
        print(f"  Processing page {page_num}/{len(doc)}...", flush=True)

        # collect all elements as (y_position, text) tuples
        elements = []

        for block in page.get_text("dict")["blocks"]:
            y_pos = block["bbox"][1]

            if block["type"] == 0:
                # text block — join all spans
                text = " ".join(
                    span["text"]
                    for line in block["lines"]
                    for span in line["spans"]
                ).strip()
                if text:
                    elements.append((y_pos, text))

            elif block["type"] == 1:
                # image block — run guide_image2text
                image_bytes = block.get("image")
                if image_bytes:
                    print(f"    -> image found at y={y_pos:.0f}, extracting...", flush=True)
                    description = guide_image2text(image_bytes)
                    elements.append((y_pos, f"[IMAGE DESCRIPTION: {description}]"))

        # sort by vertical position to preserve reading order
        elements.sort(key=lambda x: x[0])

        page_text = "\n".join(text for _, text in elements)
        pages.append(f"PAGE {page_num}:\n{page_text}")

    doc.close()
    return "\n\n".join(pages)


# ──────────────────────────────────────────
# USAGE
# ──────────────────────────────────────────

if __name__ == "__main__":
    import sys

    pdf_path = sys.argv[1] if len(sys.argv) > 1 else \
        r"C:\Users\S Balavardhan reddy\VALIDATION LAYER\submission_1\ref_data\467122_3_minnie_mouse_packaging_guide.pdf"

    print(f"Processing: {pdf_path}\n")
    guide_text = process_style_guide(pdf_path)

    out_path = pdf_path.replace(".pdf", "_extracted.txt")
    with open(out_path, "w", encoding="utf-8") as f:
        f.write(guide_text)

    print(f"\nSaved to: {out_path}")
    print(f"Total pages: {guide_text.count('PAGE ')}")
