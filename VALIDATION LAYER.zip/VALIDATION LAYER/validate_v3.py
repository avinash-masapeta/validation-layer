"""
Guide-grounded compliance validation — 24-attribute SOW schema.

Architecture: extracted_value → query → guide_text → VIOLATION/COMPLIANT
Source of truth is the style guide. GT used only for P/R benchmarking.
Reuses extraction cache from evaluate_v3.py (no extra API cost).
"""

import csv
import glob
import json
import os
import sys
import io
import time
import random

import pandas as pd

try:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    sys.stderr.reconfigure(encoding="utf-8", errors="replace")
except Exception:
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8", errors="replace", line_buffering=True)
    sys.stderr = io.TextIOWrapper(sys.stderr.buffer, encoding="utf-8", errors="replace", line_buffering=True)

_here = os.path.dirname(os.path.abspath(__file__))
try:
    from dotenv import load_dotenv
    load_dotenv(os.path.join(_here, ".env"), override=True)
except ImportError:
    pass

from jedai_client import ensure_jedai_configured, jedai_complete  # noqa: E402

ensure_jedai_configured()

# ─── CONFIG ───────────────────────────────────────────────────────────────────
_val_default = "gpt-4.1"
MODEL = (
    os.environ.get("VALIDATION_MODEL", "").strip()
    or os.environ.get("JEDAI_MODEL", "").strip()
    or _val_default
)
GT_CSV            = "ground_truth_v4.csv"
GUIDE_TEXT_DIR    = "extracted_guides"
OUTPUT_CSV        = "validation_results_v3.csv"
OUTPUT_SUMMARY    = "validation_summary_v3.json"
SLEEP_SECS        = 8
SAMPLE_N          = 50
RANDOM_SEED       = 42

EXTRACTION_CACHE_CANDIDATES = [
    "extraction_results_v3.json",
    "extraction_results_v2.json",
]

# ─── SCHEMA ───────────────────────────────────────────────────────────────────
ALL_ATTRS = [
    "logo_presence", "logo_horizontal", "logo_vertical",
    "logo_prominence", "logo_proportion",
    "character_presence", "character_position", "character_scale",
    "character_orientation", "character_proportion", "character_color",
    "text_presence", "text_color", "text_position", "text_scale", "font_family",
    "background_color", "background_pattern",
    "snipe_presence", "snipe_density", "snipe_shape",
    "barcode_presence", "barcode_horizontal", "barcode_vertical",
]

OPEN_ENDED = {"character_color", "text_color", "background_color", "font_family"}

DEPS = {
    "logo_horizontal":       ("logo_presence",      "present"),
    "logo_vertical":         ("logo_presence",      "present"),
    "logo_prominence":       ("logo_presence",      "present"),
    "logo_proportion":       ("logo_presence",      "present"),
    "character_position":    ("character_presence", "present"),
    "character_scale":       ("character_presence", "present"),
    "character_orientation": ("character_presence", "present"),
    "character_proportion":  ("character_presence", "present"),
    "character_color":       ("character_presence", "present"),
    "text_color":            ("text_presence",      "present"),
    "text_position":         ("text_presence",      "present"),
    "text_scale":            ("text_presence",      "present"),
    "font_family":           ("text_presence",      "present"),
    "snipe_density":         ("snipe_presence",     "present"),
    "snipe_shape":           ("snipe_presence",     "present"),
    "barcode_horizontal":    ("barcode_presence",   "present"),
    "barcode_vertical":      ("barcode_presence",   "present"),
}


# ─── QUERY BUILDER ────────────────────────────────────────────────────────────
def build_query(attribute, extracted_value):
    v = extracted_value

    queries = {
        "logo_presence":
            f"A brand logo is '{v}' on the packaging. "
            f"Does the style guide require or restrict the presence of a brand logo? Is this compliant?",

        "logo_horizontal":
            f"The brand logo appears towards the '{v}' side of the packaging. "
            f"Does the style guide specify any preferred or restricted horizontal placement for the logo? "
            f"If placement guidance exists, is this compliant?",

        "logo_vertical":
            f"The brand logo appears towards the '{v}' area vertically on the packaging. "
            f"Does the style guide specify any preferred vertical placement for the logo? "
            f"If guidance exists, is this compliant?",

        "logo_prominence":
            f"The brand logo has '{v}' visual prominence (subtle/standard/dominant). "
            f"Does the style guide specify how prominent the logo should appear relative to other elements? "
            f"Is this compliant?",

        "logo_proportion":
            f"The brand logo appears '{v}' (proportional means undistorted, distorted means stretched or squished). "
            f"Does the style guide prohibit distorting the logo's proportions? Is this compliant?",

        "character_presence":
            f"A licensed character is '{v}' on the packaging. "
            f"Does the style guide require or restrict the use of a character? Is this compliant?",

        "character_position":
            f"The character appears in the '{v}' area of the packaging. "
            f"Does the style guide define any required or restricted placement for characters? "
            f"If defined, is this compliant?",

        "character_scale":
            f"The character occupies a '{v}' portion of the packaging. "
            f"Does the style guide specify how large or small the character should appear relative to the layout? "
            f"Is this compliant?",

        "character_orientation":
            f"The character is depicted as '{v}'. "
            f"Does the style guide define approved character poses or orientations? "
            f"If defined, is this compliant?",

        "character_proportion":
            f"The character appears '{v}' (proportional means undistorted, distorted means warped). "
            f"Does the style guide prohibit distorting the character's appearance? Is this compliant?",

        "character_color":
            f"The character appears in '{v}' color tones. "
            f"Does the style guide specify approved or restricted colors for the character? Is this compliant?",

        "text_presence":
            f"Text is '{v}' on the packaging. "
            f"Does the style guide require or restrict the presence of text or copy? Is this compliant?",

        "text_color":
            f"The main text color is '{v}'. "
            f"Does the style guide specify approved or restricted text colors? Is this compliant?",

        "text_position":
            f"The main text appears in the '{v}' area of the packaging. "
            f"Does the style guide specify preferred placement for text or copy? "
            f"If defined, is this compliant?",

        "text_scale":
            f"The main text appears '{v}' in size relative to the packaging. "
            f"Does the style guide define minimum size or prominence requirements for text? Is this compliant?",

        "font_family":
            f"The main text uses a '{v}' typeface. "
            f"Does the style guide specify approved or restricted typeface styles? Is this compliant?",

        "background_color":
            f"The dominant background color is '{v}'. "
            f"Does the style guide specify approved or restricted background colors? Is this compliant?",

        "background_pattern":
            f"The background treatment is '{v}' (solid/gradient/patterned/photographic/illustrated). "
            f"Does the style guide specify approved background styles? Is this compliant?",

        "snipe_presence":
            f"Promotional callout badges are '{v}' on the packaging. "
            f"Does the style guide allow or restrict the use of such callouts or badges? Is this compliant?",

        "snipe_density":
            f"The packaging has '{v}' promotional callout badge(s) (single = one, multiple = more than one). "
            f"Does the style guide define limits on the number of such elements? Is this compliant?",

        "snipe_shape":
            f"The promotional callout badge has a '{v}' shape. "
            f"Does the style guide define approved shapes or styles for such elements? Is this compliant?",

        "barcode_presence":
            f"A barcode or QR code is '{v}' on the packaging. "
            f"Does the style guide require a barcode or QR code? Is this compliant?",

        "barcode_horizontal":
            f"The barcode appears towards the '{v}' side of the packaging. "
            f"Does the style guide specify any placement rules for barcodes? "
            f"If defined, is this compliant?",

        "barcode_vertical":
            f"The barcode appears towards the '{v}' vertical area of the packaging. "
            f"Does the style guide specify any placement rules for barcodes? "
            f"If defined, is this compliant?",
    }

    return queries.get(attribute,
        f"The extracted value for '{attribute}' is '{v}'. Is this compliant with the guide?")


# ─── STYLE GUIDE SEARCH ───────────────────────────────────────────────────────
_guide_cache = {}

def load_guide_text(guide_id):
    if guide_id in _guide_cache:
        return _guide_cache[guide_id]

    # Exact-name candidates first
    candidates = [
        os.path.join(GUIDE_TEXT_DIR, f"{guide_id}_extracted.txt"),
        os.path.join(GUIDE_TEXT_DIR, f"{guide_id}.txt"),
        "style_guide_extracted.txt",
    ]
    # Fuzzy fallback: any extracted_guides file that shares a numeric token with guide_id
    tokens = {t for t in guide_id.replace("_", " ").split() if t.isdigit() and len(t) >= 5}
    if os.path.isdir(GUIDE_TEXT_DIR):
        for fname in os.listdir(GUIDE_TEXT_DIR):
            if any(tok in fname for tok in tokens):
                candidates.insert(0, os.path.join(GUIDE_TEXT_DIR, fname))

    for path in candidates:
        if os.path.exists(path):
            with open(path, encoding="utf-8", errors="replace") as fh:
                _guide_cache[guide_id] = fh.read()
            return _guide_cache[guide_id]
    print(f"  [WARN] No guide text for '{guide_id}'")
    _guide_cache[guide_id] = ""
    return ""


def search(query, guide_text):
    """Returns (answer, reason). answer: 'yes'=compliant, 'no'=violation."""
    prompt = (
        f"You are a strict brand enforcement auditor for licensed merchandise packaging. "
        f"Your job is to find violations against the style guide. When in doubt, flag it.\n\n"
        f"STYLE GUIDE:\n{guide_text}\n\n"
        f"QUESTION (based on what was extracted from the packaging image):\n{query}\n\n"
        f"Instructions:\n"
        f"- Search the ENTIRE style guide above for any rule related to this attribute.\n"
        f"- Answer VIOLATION if the extracted value breaks, contradicts, or deviates from any rule.\n"
        f"- Answer COMPLIANT only if you are confident no rule in the guide is violated.\n"
        f"- Even if the guide does not name this attribute explicitly, check for related rules "
        f"(color palettes, layout specs, brand standards, positioning guidelines) that apply.\n"
        f"- You MUST answer either VIOLATION or COMPLIANT. No other answer is accepted.\n"
        f"- Cite the specific guide rule in your reason.\n\n"
        f"Answer: VIOLATION / COMPLIANT\n"
        f"Reason: <one sentence citing the guide rule>"
    )

    messages = [{"role": "user", "content": prompt}]

    max_tok = 300
    text = jedai_complete(
        MODEL, messages, temperature=0.0, max_tokens=max_tok, timeout=180
    ).strip()

    answer, reason = "yes", text   # default to compliant if parsing fails
    for line in text.split("\n"):
        low = line.lower().strip()
        if low.startswith("answer:"):
            val = low.replace("answer:", "").strip()
            if "violation" in val:
                answer = "no"
            elif "compliant" in val:
                answer = "yes"
        elif low.startswith("reason:"):
            reason = line.split(":", 1)[1].strip() if ":" in line else text

    return answer, reason


# ─── LOAD DATASET ─────────────────────────────────────────────────────────────
def load_dataset():
    images = []
    with open(GT_CSV, encoding="utf-8") as f:
        for row in csv.DictReader(f):
            if not row.get("image_file"):
                continue   # content-policy-rejected images (no file)
            images.append({
                "image_id":         row["image_id"],
                "guide_id":         row["guide_id"],
                "eval_type":        row["eval_type"],
                "label":            row["label"],        # PASS / FAIL — used only for P/R metrics
                "attribute_tested": row["attribute_tested"],
            })
    return images


def load_extraction_cache():
    for path in EXTRACTION_CACHE_CANDIDATES:
        abs_path = path if os.path.isabs(path) else os.path.join(_here, path)
        if os.path.exists(abs_path):
            with open(abs_path, encoding="utf-8") as f:
                cache = json.load(f)
            print(f"Extraction cache loaded: {abs_path} ({len(cache)} images)")
            return cache
    pattern = os.path.join(_here, "extraction_results_*.json")
    picks = sorted(glob.glob(pattern), key=os.path.getmtime, reverse=True)
    for path in picks:
        try:
            with open(path, encoding="utf-8") as f:
                cache = json.load(f)
            if isinstance(cache, dict) and cache:
                print(f"Extraction cache loaded: {path} ({len(cache)} images)")
                return cache
        except (json.JSONDecodeError, OSError):
            continue
    print("[WARN] No extraction cache found — all images will be skipped (run evaluate_v3.py first).")
    return {}


def stratified_sample(images, n=SAMPLE_N):
    random.seed(RANDOM_SEED)
    # Exclude FAIL images whose attribute_tested is not in the 24-attr SOW schema
    valid_images = [x for x in images
                    if x["eval_type"] != "controlled_fail"
                    or x["attribute_tested"] in ALL_ATTRS]

    # If n covers the full dataset, skip stratification and return everything
    if n >= len(valid_images):
        real  = sum(1 for x in valid_images if x["eval_type"] == "real_pass")
        syn   = sum(1 for x in valid_images if x["eval_type"] == "synthetic_pass")
        fail  = sum(1 for x in valid_images if x["eval_type"] == "controlled_fail")
        attrs = sorted({x["attribute_tested"] for x in valid_images
                        if x["eval_type"] == "controlled_fail" and x["attribute_tested"] != "ALL"})
        print(f"Sample: {real} real PASS | {syn} syn PASS | {fail} FAIL ({len(attrs)} violated attrs covered)")
        return valid_images

    real_pass = [x for x in valid_images if x["eval_type"] == "real_pass"]
    syn_pass  = [x for x in valid_images if x["eval_type"] == "synthetic_pass"]
    ctrl_fail = [x for x in valid_images if x["eval_type"] == "controlled_fail"]

    n_real = n // 3 + (1 if n % 3 > 0 else 0)
    n_syn  = n // 3 + (1 if n % 3 > 1 else 0)
    n_fail = n - n_real - n_syn

    sampled_real = random.sample(real_pass, min(n_real, len(real_pass)))
    sampled_syn  = random.sample(syn_pass,  min(n_syn,  len(syn_pass)))

    buckets = {}
    for img in ctrl_fail:
        buckets.setdefault(img["attribute_tested"], []).append(img)
    for b in buckets.values():
        random.shuffle(b)

    sampled_fail, keys, i = [], sorted(buckets), 0
    while len(sampled_fail) < n_fail and i < len(keys) * 20:
        attr = keys[i % len(keys)]
        idx  = i // len(keys)
        if idx < len(buckets[attr]):
            sampled_fail.append(buckets[attr][idx])
        i += 1
        seen = set()
        sampled_fail = [x for x in sampled_fail
                        if x["image_id"] not in seen and not seen.add(x["image_id"])]
    sampled_fail = sampled_fail[:n_fail]

    result = sampled_real + sampled_syn + sampled_fail
    attrs_covered = sorted({x["attribute_tested"] for x in sampled_fail if x["attribute_tested"] != "ALL"})
    print(f"Sample: {len(sampled_real)} real PASS | {len(sampled_syn)} syn PASS | "
          f"{len(sampled_fail)} FAIL ({len(attrs_covered)} violated attrs covered)")
    return result


# ─── BENCHMARK LABELING ──────────────────────────────────────────────────────
def expected_answer(image, attribute, extracted):
    """Derive expected answer for P/R benchmarking (not used in the validation loop)."""
    # Gate: if parent element absent in extracted values → not_applicable
    if attribute in DEPS:
        gate_attr, required_val = DEPS[attribute]
        if extracted.get(gate_attr, "").strip().lower() != required_val:
            return "not_applicable"

    if image["label"] == "FAIL" and image["attribute_tested"] == attribute:
        return "no"

    return "yes"


def derive_label(model_answer, expected):
    if expected == "not_applicable":
        return "SKIP"
    if expected == "no":
        return "TP" if model_answer == "no" else "FN"
    return "FP" if model_answer == "no" else "TN"


# ─── METRICS ──────────────────────────────────────────────────────────────────
def pr_stats(rows):
    tp = sum(1 for r in rows if r["label"] == "TP")
    fp = sum(1 for r in rows if r["label"] == "FP")
    fn = sum(1 for r in rows if r["label"] == "FN")
    tn = sum(1 for r in rows if r["label"] == "TN")
    total = tp + fp + fn + tn
    p  = tp / (tp + fp) if (tp + fp) > 0 else 0.0
    r  = tp / (tp + fn) if (tp + fn) > 0 else 0.0
    f1 = 2 * p * r / (p + r) if (p + r) > 0 else 0.0
    acc = (tp + tn) / total if total > 0 else 0.0
    return {"TP": tp, "FP": fp, "FN": fn, "TN": tn,
            "precision": round(p, 4), "recall": round(r, 4),
            "f1": round(f1, 4), "accuracy": round(acc, 4)}


# ─── MAIN ─────────────────────────────────────────────────────────────────────
def main():
    images    = load_dataset()
    sampled   = stratified_sample(images)
    ext_cache = load_extraction_cache()

    total_calls = len(sampled) * len(ALL_ATTRS)
    print(f"\nImages   : {len(sampled)}")
    print(f"Attrs    : {len(ALL_ATTRS)}")
    print(f"LLM calls: {total_calls}  (text only — no image re-send, uses extracted values)")
    print(f"Est. cost: ~${total_calls * 0.025:.1f}  (full guide text per call, avg 12k tokens)")
    print(f"Est. time: ~{total_calls * SLEEP_SECS // 3600}h {(total_calls * SLEEP_SECS % 3600) // 60}m")
    print(f"Model    : {MODEL}")
    print("Backend  : JedAI\n")

    # Resume
    done_keys, all_results = set(), []
    if os.path.exists(OUTPUT_CSV):
        existing = pd.read_csv(OUTPUT_CSV, encoding="utf-8").to_dict("records")
        all_results = existing
        for r in existing:
            done_keys.add((str(r["image_id"]), str(r["attribute"])))
        print(f"Resuming — {len(done_keys)} done, {total_calls - len(done_keys)} remaining\n")

    # Main validation loop
    call_count = 0
    for img in sampled:
        guide_text = load_guide_text(img["guide_id"])
        extracted  = ext_cache.get(img["image_id"], {}).get("extracted", {})

        if not extracted:
            print(f"  [SKIP] {img['image_id']} — no extraction in cache")
            continue

        for attribute in ALL_ATTRS:
            if (img["image_id"], attribute) in done_keys:
                continue

            extracted_value = extracted.get(attribute, "").strip()

            # Skip if model said not_applicable during extraction (element absent)
            if not extracted_value or extracted_value.lower() == "not_applicable":
                # Still record for completeness
                exp  = expected_answer(img, attribute, extracted)
                lbl  = derive_label("not_applicable", exp)
                all_results.append({
                    "image_id":         img["image_id"],
                    "guide_id":         img["guide_id"],
                    "eval_type":        img["eval_type"],
                    "image_label":      img["label"],
                    "attribute_tested": img["attribute_tested"],
                    "attribute":        attribute,
                    "extracted_value":  extracted_value or "not_applicable",
                    "query":            "(skipped — extracted value absent)",
                    "validation_result":"not_applicable",
                    "reason":           "Element not present in image",
                    "expected_answer":  exp,
                    "label":            lbl,
                })
                continue

            # Build guide-search query from extracted value
            query = build_query(attribute, extracted_value)

            try:
                validation_result, reason = search(query, guide_text)
            except Exception as e:
                validation_result, reason = "error", str(e)[:120]
                print(f"  [ERROR] {img['image_id']} | {attribute}: {reason}")

            # Benchmark labeling (GT used only here)
            exp = expected_answer(img, attribute, extracted)
            lbl = derive_label(validation_result, exp)

            all_results.append({
                "image_id":         img["image_id"],
                "guide_id":         img["guide_id"],
                "eval_type":        img["eval_type"],
                "image_label":      img["label"],
                "attribute_tested": img["attribute_tested"],
                "attribute":        attribute,
                "extracted_value":  extracted_value,
                "query":            query,
                "validation_result":validation_result,
                "reason":           reason,
                "expected_answer":  exp,
                "label":            lbl,
            })

            call_count += 1
            if call_count % 50 == 0:
                pd.DataFrame(all_results).to_csv(OUTPUT_CSV, index=False, encoding="utf-8")
                scored = [r for r in all_results if r["label"] not in ("SKIP", "error")]
                if scored:
                    m = pr_stats(scored)
                    print(f"  [{call_count}/{total_calls}]  P={m['precision']:.3f}  "
                          f"R={m['recall']:.3f}  F1={m['f1']:.3f}")

            time.sleep(SLEEP_SECS)

    pd.DataFrame(all_results).to_csv(OUTPUT_CSV, index=False, encoding="utf-8")
    print(f"\nSaved: {OUTPUT_CSV}  ({len(all_results)} rows)\n")

    # Final metrics
    scored = [r for r in all_results if r["label"] not in ("SKIP", "error")]

    print(f"{'='*65}")
    print(f"VALIDATION P/R/F1  [{MODEL}]")
    print("(Guide is source of truth — GT used only for benchmarking)")
    print(f"{'='*65}")
    print(f"Total: {len(all_results)} | Scored: {len(scored)} | Skipped: {len(all_results)-len(scored)}")

    for lbl, subset in [
        ("All 24 attrs",    scored),
        ("Categorical 20",  [r for r in scored if r["attribute"] not in OPEN_ENDED]),
        ("Open-ended 4",    [r for r in scored if r["attribute"] in OPEN_ENDED]),
    ]:
        m = pr_stats(subset)
        print(f"\n{lbl}:  TP={m['TP']} FP={m['FP']} FN={m['FN']} TN={m['TN']}")
        print(f"  Precision={m['precision']:.4f}  Recall={m['recall']:.4f}  "
              f"F1={m['f1']:.4f}  Accuracy={m['accuracy']:.4f}")

    print("\nPer attribute:")
    print(f"  {'Attribute':<26}  {'P':>7}  {'R':>7}  {'F1':>7}  {'TP':>4}  {'FP':>4}  {'FN':>4}  {'TN':>4}")
    print(f"  {'-'*72}")

    per_attr = {}
    for attr in ALL_ATTRS:
        rows = [r for r in scored if r["attribute"] == attr]
        if not rows:
            continue
        m = pr_stats(rows)
        per_attr[attr] = m
        print(f"  {attr:<26}  {m['precision']:>7.4f}  {m['recall']:>7.4f}  "
              f"{m['f1']:>7.4f}  {m['TP']:>4}  {m['FP']:>4}  {m['FN']:>4}  {m['TN']:>4}")

    summary = {
        "model": MODEL, "sample_n": len(sampled),
        "total_rows": len(all_results), "scored_rows": len(scored),
        "overall": pr_stats(scored), "per_attribute": per_attr,
        "note": "Validation uses extracted values + guide only. GT used only for P/R benchmarking."
    }
    with open(OUTPUT_SUMMARY, "w", encoding="utf-8") as f:
        json.dump(summary, f, indent=2, ensure_ascii=False)
    print(f"\nSaved: {OUTPUT_SUMMARY}")


if __name__ == "__main__":
    main()
