
  # Style Guide Annotator

  This is a code bundle for Style Guide Annotator. The original project is available at https://www.figma.com/design/DdIcd4epWeACrC5aSKr05F/Style-Guide-Annotator.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  