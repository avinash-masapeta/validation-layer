/**
 * Layout.tsx — Light theme shell for /app/* routes
 * Matches the clean white SaaS design from the reference image.
 */
import React from "react";
import { NavLink, Outlet, useNavigate } from "react-router";
import { LayoutDashboard, Images, Database, Download, ChevronRight, Bell, User, FileText, ShieldCheck } from "lucide-react";
import { useApp } from "../context/AppContext";

const navItems = [
  { to: "/app/dashboard",  icon: LayoutDashboard, label: "Dashboard" },
  { to: "/app/review",     icon: Images,           label: "Review Images" },
  { to: "/app/attributes", icon: Database,          label: "Attribute Store" },
  { to: "/app/export",     icon: Download,          label: "Export Results" },
];

export function Layout() {
  const { images, annotations } = useApp();
  const reviewedCount = Object.keys(annotations).length;
  const pct = images.length > 0 ? (reviewedCount / images.length) * 100 : 0;

  return (
    <div className="flex h-screen bg-gray-50 overflow-hidden font-sans">

      {/* ── Sidebar ── */}
      <aside className="flex flex-col bg-white border-r border-gray-200 shrink-0" style={{ width: 240 }}>
        {/* Logo */}
        <div className="flex items-center gap-3 px-6 border-b border-gray-100 shrink-0" style={{ height: 72 }}>
          <div className="w-8 h-8 rounded-lg bg-blue-600 flex items-center justify-center shrink-0">
            <FileText className="w-4 h-4 text-white" />
          </div>
          <div>
            <p className="text-[13px] font-bold text-gray-900 leading-tight">Style Guide</p>
            <p className="text-[11px] text-gray-400 leading-tight">Annotator</p>
          </div>
        </div>

        {/* Nav */}
        <nav className="flex-1 px-3 py-4 overflow-y-auto">
          <p className="text-[11px] font-semibold uppercase tracking-widest text-gray-400 px-3 mb-2">Navigation</p>
          <ul className="space-y-0.5">
            {navItems.map(({ to, icon: Icon, label }) => (
              <li key={to}>
                <NavLink
                  to={to}
                  className={({ isActive }) =>
                    `flex items-center gap-3 px-3 py-2.5 rounded-lg text-[14px] font-medium transition-colors ${
                      isActive
                        ? "bg-blue-50 text-blue-700"
                        : "text-gray-600 hover:bg-gray-100 hover:text-gray-900"
                    }`
                  }
                >
                  {({ isActive }) => (
                    <>
                      <Icon className={`w-4 h-4 shrink-0 ${isActive ? "text-blue-600" : "text-gray-400"}`} />
                      <span className="flex-1">{label}</span>
                      {isActive && <ChevronRight className="w-3 h-3 text-blue-400" />}
                    </>
                  )}
                </NavLink>
              </li>
            ))}
          </ul>

          {/* Guardian Audit shortcut */}
          <div className="mt-4 pt-4 border-t border-gray-100">
            <p className="text-[11px] font-semibold uppercase tracking-widest text-gray-400 px-3 mb-2">Pipeline</p>
            <NavLink
              to="/guardian"
              className={({ isActive }) =>
                `flex items-center gap-3 px-3 py-2.5 rounded-lg text-[14px] font-medium transition-colors ${
                  isActive
                    ? "bg-blue-50 text-blue-700"
                    : "text-gray-600 hover:bg-gray-100 hover:text-gray-900"
                }`
              }
            >
              {({ isActive }) => (
                <>
                  <ShieldCheck className={`w-4 h-4 shrink-0 ${isActive ? "text-blue-600" : "text-gray-400"}`} />
                  <span className="flex-1">Guardian Audit</span>
                  {isActive && <ChevronRight className="w-3 h-3 text-blue-400" />}
                </>
              )}
            </NavLink>
          </div>

          {/* Progress */}
          <div className="mt-6 px-1">
            <div className="bg-gray-50 rounded-xl p-4 border border-gray-100">
              <p className="text-[11px] font-semibold uppercase tracking-widest text-gray-400 mb-2">Review Progress</p>
              <p className="text-[14px] font-bold text-gray-800">
                {reviewedCount} / {images.length} reviewed
              </p>
              <div className="mt-2 h-1.5 bg-gray-200 rounded-full overflow-hidden">
                <div className="h-full bg-blue-500 rounded-full transition-all" style={{ width: `${pct}%` }} />
              </div>
            </div>
          </div>
        </nav>

        {/* Footer */}
        <div className="px-3 py-4 border-t border-gray-100">
          <div className="flex items-center gap-2.5 px-3 py-2">
            <div className="w-7 h-7 rounded-full bg-blue-100 flex items-center justify-center shrink-0">
              <User className="w-3.5 h-3.5 text-blue-600" />
            </div>
            <div>
              <p className="text-[12px] font-semibold text-gray-900 leading-tight">Designer</p>
              <p className="text-[11px] text-gray-400 leading-tight">Reviewer</p>
            </div>
          </div>
        </div>
      </aside>

      {/* ── Main area ── */}
      <div className="flex flex-col flex-1 min-w-0 overflow-hidden">
        {/* Top header */}
        <header className="flex items-center justify-between px-6 bg-white border-b border-gray-200 shrink-0" style={{ height: 72 }}>
          <div className="flex items-center gap-2 text-[13px] text-gray-500">
            <span className="text-blue-600 font-semibold">Style Guide Annotator</span>
            <ChevronRight className="w-3.5 h-3.5 text-gray-300" />
            <span className="px-2 py-0.5 bg-blue-50 text-blue-600 border border-blue-100 rounded text-[12px] font-semibold">Step 4 of 4</span>
            <span className="text-gray-700 font-medium">Review</span>
          </div>
          <div className="flex items-center gap-3">
            <button className="w-8 h-8 flex items-center justify-center rounded-lg text-gray-400 hover:bg-gray-100 transition-colors relative">
              <Bell className="w-4 h-4" />
              <span className="absolute top-1.5 right-1.5 w-1.5 h-1.5 bg-blue-500 rounded-full" />
            </button>
            <div className="w-px h-5 bg-gray-200" />
            <div className="flex items-center gap-2 px-2 py-1 rounded-lg hover:bg-gray-50 cursor-pointer transition-colors">
              <div className="w-7 h-7 rounded-full bg-blue-100 flex items-center justify-center shrink-0">
                <User className="w-3.5 h-3.5 text-blue-600" />
              </div>
              <div>
                <p className="text-[13px] font-semibold text-gray-800 leading-tight">Designer</p>
                <p className="text-[11px] text-gray-400 leading-tight">Reviewer</p>
              </div>
            </div>
          </div>
        </header>

        <main className="flex-1 overflow-hidden bg-gray-50" style={{ display: "flex", flexDirection: "column", minHeight: 0 }}>
          <Outlet />
        </main>
      </div>
    </div>
  );
}