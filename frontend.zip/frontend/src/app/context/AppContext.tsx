/**
 * AppContext.tsx
 * ---------------------------------------------------------------------------
 * Global state provider for the Castle Vision pipeline.
 *
 * KEY CHANGE: SAMPLE_IMAGES now references the REAL Disney assets that live in
 * the project's /data folder, served as static files by Vite from /public/data.
 *
 * To make the images available:
 *   Copy from:  disney/data/tigger.png  &  disney/data/packing-image.jpg
 *   Paste into: disney/frontend/public/data/
 *
 * PDF names are kept as labels (they cannot be rendered as <img> without a
 * PDF renderer, so we use the associated extracted images instead).
 * ---------------------------------------------------------------------------
 */

import React, { createContext, useContext, useState, useCallback } from "react";

// ---------------------------------------------------------------------------
// Types
// ---------------------------------------------------------------------------

export interface Attribute {
  id: string;
  name: string;
  type: "text" | "boolean" | "select" | "numeric";
  description: string;
  validationRule?: string;
  exampleFromStyleGuide?: string;
  usageCount: number;
}

export interface ImageItem {
  id: string;
  /** Source PDF file name this image was extracted from */
  pdfName: string;
  pageNumber: number;
  imageUrl: string;
  thumbUrl: string;
  /** Descriptive block type detected by layout engine */
  blockType?: "TEXT" | "IMAGE" | "MIXED";
}

export interface Annotation {
  imageId: string;
  checkedAttributes: string[];
  missingAttributes: string;
  notes: string;
  savedAt?: string;
}

interface AppState {
  folderPath: string;
  setFolderPath: (path: string) => void;
  pdfCount: number;
  setPdfCount: (n: number) => void;
  images: ImageItem[];
  currentIndex: number;
  setCurrentIndex: (i: number) => void;
  annotations: Record<string, Annotation>;
  saveAnnotation: (ann: Annotation) => void;
  attributes: Attribute[];
  setAttributes: React.Dispatch<React.SetStateAction<Attribute[]>>;
  processingComplete: boolean;
  setProcessingComplete: (v: boolean) => void;
  exportComplete: boolean;
  setExportComplete: (v: boolean) => void;
}

// ---------------------------------------------------------------------------
// Disney Brand Assets (real files from /data, copied to /public/data by Vite)
// ---------------------------------------------------------------------------

/**
 * These images are extracted samples from the real Disney style guide PDFs.
 * Vite serves /public/** as static files at the root URL, so we reference
 * them via  /data/<filename>.
 *
 * NOTE: If you add more extracted images to public/data, just add entries here.
 */
const DISNEY_IMAGES: ImageItem[] = [
  {
    id: "img-001",
    pdfName: "Mickey and Friends CC870_2- branding.pdf",
    pageNumber: 1,
    blockType: "IMAGE",
    imageUrl: "/data/tigger.png",
    thumbUrl: "/data/tigger.png",
  },
  {
    id: "img-002",
    pdfName: "DisneyPrincess 2338550_2_Packaging guide.pdf",
    pageNumber: 3,
    blockType: "IMAGE",
    imageUrl: "/data/packing-image.jpg",
    thumbUrl: "/data/packing-image.jpg",
  },
  // Placeholder for future extracted pages from the 3196071 style guide PDF
  {
    id: "img-003",
    pdfName: "3196071 1-styleguide.pdf",
    pageNumber: 5,
    blockType: "TEXT",
    imageUrl: "/data/packing-image.jpg",  // replace with extracted page image once available
    thumbUrl: "/data/packing-image.jpg",
  },
];

// ---------------------------------------------------------------------------
// Disney-specific Canonical Attributes
// ---------------------------------------------------------------------------

const DISNEY_ATTRIBUTES: Attribute[] = [
  {
    id: "attr-01",
    name: "Brand Character",
    type: "text",
    description: "Disney character visible in the asset (e.g. Mickey, Elsa, Tigger)",
    validationRule: "Must be an approved Disney/Pixar character",
    exampleFromStyleGuide: "Tigger, Mickey Mouse",
    usageCount: 89,
  },
  {
    id: "attr-02",
    name: "Logo Visible",
    type: "boolean",
    description: "Disney or franchise logo is present in the image",
    exampleFromStyleGuide: "true",
    usageCount: 74,
  },
  {
    id: "attr-03",
    name: "Clear Space Respected",
    type: "boolean",
    description: "Required clear space (0.5x height) is maintained around brand asset",
    validationRule: "Must comply with style guide clearance rules",
    usageCount: 68,
  },
  {
    id: "attr-04",
    name: "Color Palette",
    type: "select",
    description: "Primary palette used: Disney Blue, Princess Gold, Midnight, etc.",
    exampleFromStyleGuide: "Disney Blue (#006EBF)",
    usageCount: 55,
  },
  {
    id: "attr-05",
    name: "Aspect Ratio Correct",
    type: "boolean",
    description: "Logo / asset has not been stretched or distorted",
    usageCount: 62,
  },
  {
    id: "attr-06",
    name: "Typography Present",
    type: "boolean",
    description: "Image contains visible text using an approved Disney typeface",
    usageCount: 41,
  },
  {
    id: "attr-07",
    name: "Background Style",
    type: "select",
    description: "Background type: solid, gradient, transparent, photographic",
    exampleFromStyleGuide: "solid white",
    usageCount: 53,
  },
  {
    id: "attr-08",
    name: "Territory Compliance",
    type: "select",
    description: "Territory this asset is approved for: NA, EMEA, APAC, Global",
    validationRule: "Must match OPA contract territory field",
    usageCount: 37,
  },
  {
    id: "attr-09",
    name: "Product Category",
    type: "text",
    description: "Licensing product category (Apparel, Toy, Stationery, etc.)",
    validationRule: "Must match approved product category list",
    usageCount: 48,
  },
  {
    id: "attr-10",
    name: "Annotation Confidence",
    type: "numeric",
    description: "Reviewer confidence score for this annotation (1–5)",
    usageCount: 46,
  },
  {
    id: "attr-11",
    name: "OPA Metadata Match",
    type: "boolean",
    description: "Does this asset's extracted metadata match the OPA contract fields?",
    usageCount: 29,
  },
  {
    id: "attr-12",
    name: "Rights Validated",
    type: "boolean",
    description: "Asset rights have been validated against contract document",
    usageCount: 21,
  },
];

// ---------------------------------------------------------------------------
// Context definition & Provider
// ---------------------------------------------------------------------------

const AppContext = createContext<AppState | null>(null);

export function AppProvider({ children }: { children: React.ReactNode }) {
  const [folderPath, setFolderPath] = useState("c:/Users/avina/Documents/Projects/disney/data");
  const [pdfCount, setPdfCount] = useState(0);
  const [images] = useState<ImageItem[]>(DISNEY_IMAGES);
  const [currentIndex, setCurrentIndex] = useState(0);
  const [annotations, setAnnotations] = useState<Record<string, Annotation>>({});
  const [attributes, setAttributes] = useState<Attribute[]>(DISNEY_ATTRIBUTES);
  const [processingComplete, setProcessingComplete] = useState(false);
  const [exportComplete, setExportComplete] = useState(false);

  const saveAnnotation = useCallback((ann: Annotation) => {
    setAnnotations((prev) => ({
      ...prev,
      [ann.imageId]: { ...ann, savedAt: new Date().toISOString() },
    }));
  }, []);

  return (
    <AppContext.Provider
      value={{
        folderPath,
        setFolderPath,
        pdfCount,
        setPdfCount,
        images,
        currentIndex,
        setCurrentIndex,
        annotations,
        saveAnnotation,
        attributes,
        setAttributes,
        processingComplete,
        setProcessingComplete,
        exportComplete,
        setExportComplete,
      }}
    >
      {children}
    </AppContext.Provider>
  );
}

export function useApp() {
  const ctx = useContext(AppContext);
  if (!ctx) throw new Error("useApp must be used within AppProvider");
  return ctx;
}
