import React, { useState } from "react";
import {
  Search,
  Plus,
  Filter,
  Edit2,
  Trash2,
  ChevronDown,
  X,
  Save,
  RotateCcw,
  Database,
  ArrowUpDown,
} from "lucide-react";
import { useApp, Attribute } from "../context/AppContext";

const TYPE_OPTIONS = ["text", "boolean", "select", "numeric"] as const;
const TYPE_COLORS: Record<string, string> = {
  text: "bg-purple-50 text-purple-700",
  boolean: "bg-green-50 text-green-700",
  select: "bg-amber-50 text-amber-700",
  numeric: "bg-blue-50 text-blue-700",
};

const BLANK_FORM = {
  name: "",
  type: "text" as Attribute["type"],
  description: "",
  validationRule: "",
  exampleFromStyleGuide: "",
};

export function AttributeStore() {
  const { attributes, setAttributes } = useApp();
  const [search, setSearch] = useState("");
  const [filterType, setFilterType] = useState<string>("all");
  const [showPanel, setShowPanel] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [form, setForm] = useState(BLANK_FORM);
  const [formError, setFormError] = useState("");
  const [deleteConfirm, setDeleteConfirm] = useState<string | null>(null);

  const filtered = attributes.filter((a) => {
    const matchSearch =
      a.name.toLowerCase().includes(search.toLowerCase()) ||
      a.description.toLowerCase().includes(search.toLowerCase());
    const matchType = filterType === "all" || a.type === filterType;
    return matchSearch && matchType;
  });

  function openAdd() {
    setEditingId(null);
    setForm(BLANK_FORM);
    setFormError("");
    setShowPanel(true);
  }

  function openEdit(attr: Attribute) {
    setEditingId(attr.id);
    setForm({
      name: attr.name,
      type: attr.type,
      description: attr.description,
      validationRule: attr.validationRule || "",
      exampleFromStyleGuide: attr.exampleFromStyleGuide || "",
    });
    setFormError("");
    setShowPanel(true);
  }

  function handleReset() {
    setForm(editingId ? form : BLANK_FORM);
    setFormError("");
  }

  function handleCancel() {
    setShowPanel(false);
    setEditingId(null);
    setFormError("");
  }

  function handleSave() {
    if (!form.name.trim()) {
      setFormError("Attribute name is required.");
      return;
    }
    if (!form.description.trim()) {
      setFormError("Description is required.");
      return;
    }

    if (editingId) {
      setAttributes((prev) =>
        prev.map((a) =>
          a.id === editingId
            ? {
                ...a,
                name: form.name.trim(),
                type: form.type,
                description: form.description.trim(),
                validationRule: form.validationRule.trim() || undefined,
                exampleFromStyleGuide: form.exampleFromStyleGuide.trim() || undefined,
              }
            : a
        )
      );
    } else {
      const newAttr: Attribute = {
        id: `attr-${Date.now()}`,
        name: form.name.trim(),
        type: form.type,
        description: form.description.trim(),
        validationRule: form.validationRule.trim() || undefined,
        exampleFromStyleGuide: form.exampleFromStyleGuide.trim() || undefined,
        usageCount: 0,
      };
      setAttributes((prev) => [...prev, newAttr]);
    }

    setShowPanel(false);
    setEditingId(null);
    setFormError("");
  }

  function handleDelete(id: string) {
    setAttributes((prev) => prev.filter((a) => a.id !== id));
    setDeleteConfirm(null);
    if (editingId === id) {
      setShowPanel(false);
      setEditingId(null);
    }
  }

  return (
    <div className="flex h-full overflow-hidden">
      {/* Add/Edit side panel */}
      {showPanel && (
        <div className="bg-white border-r border-gray-200 flex flex-col shrink-0 overflow-hidden" style={{ width: 360 }}>
          {/* Panel header */}
          <div className="px-5 py-4 border-b border-gray-100 flex items-center justify-between">
            <div>
              <h3 className="text-[15px] font-semibold text-gray-900">
                {editingId ? "Edit Attribute" : "Add New Attribute"}
              </h3>
              <p className="text-[12px] text-gray-400 mt-0.5">
                {editingId ? "Modify the attribute details" : "Define a new canonical attribute"}
              </p>
            </div>
            <button onClick={handleCancel} className="w-7 h-7 flex items-center justify-center rounded-lg text-gray-400 hover:bg-gray-100 transition-colors">
              <X className="w-4 h-4" />
            </button>
          </div>

          {/* Form */}
          <div className="flex-1 overflow-y-auto px-5 py-4 space-y-4">
            {/* Attribute Name */}
            <div>
              <label className="block text-[13px] font-medium text-gray-700 mb-1.5">
                Attribute Name <span className="text-red-500">*</span>
              </label>
              <input
                type="text"
                value={form.name}
                onChange={(e) => setForm({ ...form, name: e.target.value })}
                placeholder="e.g. Primary Color"
                className="w-full px-3 py-2.5 border border-gray-200 rounded-lg text-[14px] text-gray-800 placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-blue-100 focus:border-blue-300 transition-all"
              />
            </div>

            {/* Attribute Type */}
            <div>
              <label className="block text-[13px] font-medium text-gray-700 mb-1.5">
                Attribute Type <span className="text-red-500">*</span>
              </label>
              <div className="relative">
                <select
                  value={form.type}
                  onChange={(e) => setForm({ ...form, type: e.target.value as Attribute["type"] })}
                  className="w-full px-3 py-2.5 border border-gray-200 rounded-lg text-[14px] text-gray-800 bg-white appearance-none focus:outline-none focus:ring-2 focus:ring-blue-100 focus:border-blue-300 transition-all pr-9"
                >
                  {TYPE_OPTIONS.map((t) => (
                    <option key={t} value={t}>
                      {t.charAt(0).toUpperCase() + t.slice(1)}
                    </option>
                  ))}
                </select>
                <ChevronDown className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400 pointer-events-none" />
              </div>
            </div>

            {/* Description */}
            <div>
              <label className="block text-[13px] font-medium text-gray-700 mb-1.5">
                Description <span className="text-red-500">*</span>
              </label>
              <textarea
                value={form.description}
                onChange={(e) => setForm({ ...form, description: e.target.value })}
                placeholder="What does this attribute capture?"
                rows={3}
                className="w-full px-3 py-2.5 border border-gray-200 rounded-lg text-[14px] text-gray-700 placeholder-gray-400 resize-none focus:outline-none focus:ring-2 focus:ring-blue-100 focus:border-blue-300 transition-all"
              />
            </div>

            {/* Validation Rule */}
            <div>
              <label className="block text-[13px] font-medium text-gray-700 mb-1.5">
                Validation Rule <span className="text-[12px] font-normal text-gray-400">(optional)</span>
              </label>
              <input
                type="text"
                value={form.validationRule}
                onChange={(e) => setForm({ ...form, validationRule: e.target.value })}
                placeholder="e.g. Hex color, 1–5 scale, ISO date"
                className="w-full px-3 py-2.5 border border-gray-200 rounded-lg text-[14px] text-gray-800 placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-blue-100 focus:border-blue-300 transition-all"
              />
            </div>

            {/* Example */}
            <div>
              <label className="block text-[13px] font-medium text-gray-700 mb-1.5">
                Example from Style Guide <span className="text-[12px] font-normal text-gray-400">(optional)</span>
              </label>
              <input
                type="text"
                value={form.exampleFromStyleGuide}
                onChange={(e) => setForm({ ...form, exampleFromStyleGuide: e.target.value })}
                placeholder="e.g. #1A2B3C, solid white, portrait"
                className="w-full px-3 py-2.5 border border-gray-200 rounded-lg text-[14px] text-gray-800 placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-blue-100 focus:border-blue-300 transition-all"
              />
            </div>

            {/* Error */}
            {formError && (
              <div className="flex items-center gap-2 px-3 py-2 bg-red-50 border border-red-100 rounded-lg text-[13px] text-red-700">
                {formError}
              </div>
            )}
          </div>

          {/* Panel actions */}
          <div className="px-5 py-4 border-t border-gray-100 bg-gray-50 space-y-2 shrink-0">
            <button
              onClick={handleSave}
              className="w-full flex items-center justify-center gap-2 px-4 py-2.5 bg-blue-600 text-white rounded-lg text-[14px] font-semibold hover:bg-blue-700 transition-colors"
            >
              <Save className="w-4 h-4" />
              {editingId ? "Save Changes" : "Save Attribute"}
            </button>
            <div className="flex gap-2">
              <button
                onClick={handleReset}
                className="flex-1 flex items-center justify-center gap-1.5 px-3 py-2 border border-gray-200 rounded-lg text-[13px] font-medium text-gray-600 bg-white hover:bg-gray-50 transition-colors"
              >
                <RotateCcw className="w-3.5 h-3.5" />
                Reset
              </button>
              <button
                onClick={handleCancel}
                className="flex-1 flex items-center justify-center gap-1.5 px-3 py-2 border border-gray-200 rounded-lg text-[13px] font-medium text-gray-600 bg-white hover:bg-gray-50 transition-colors"
              >
                <X className="w-3.5 h-3.5" />
                Cancel
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Main table area */}
      <div className="flex-1 flex flex-col min-w-0 overflow-hidden">
        {/* Page header */}
        <div className="bg-white border-b border-gray-200 px-6 py-4 shrink-0">
          <div className="flex items-start justify-between mb-4">
            <div>
              <h1 className="text-[17px] font-semibold text-gray-900 flex items-center gap-2">
                <Database className="w-5 h-5 text-blue-500" />
                Attributes
              </h1>
              <p className="text-[13px] text-gray-500 mt-0.5">
                Manage the canonical attributes used during image annotation
              </p>
            </div>
            <button
              onClick={openAdd}
              className="flex items-center gap-2 px-4 py-2.5 bg-blue-600 text-white rounded-lg text-[14px] font-medium hover:bg-blue-700 transition-colors"
            >
              <Plus className="w-4 h-4" />
              Add Attribute
            </button>
          </div>

          {/* Search + filter */}
          <div className="flex items-center gap-3">
            <div className="flex items-center gap-2 flex-1 px-3 py-2 border border-gray-200 rounded-lg bg-gray-50">
              <Search className="w-4 h-4 text-gray-400 shrink-0" />
              <input
                type="text"
                placeholder="Search attributes by name or description…"
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                className="flex-1 bg-transparent text-[14px] text-gray-700 placeholder-gray-400 outline-none"
              />
            </div>
            <div className="relative">
              <select
                value={filterType}
                onChange={(e) => setFilterType(e.target.value)}
                className="pl-9 pr-3 py-2 border border-gray-200 rounded-lg text-[14px] text-gray-700 bg-white appearance-none focus:outline-none focus:ring-2 focus:ring-blue-100 focus:border-blue-300 transition-all"
              >
                <option value="all">All Types</option>
                {TYPE_OPTIONS.map((t) => (
                  <option key={t} value={t}>{t.charAt(0).toUpperCase() + t.slice(1)}</option>
                ))}
              </select>
              <Filter className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400 pointer-events-none" />
            </div>
            <span className="text-[13px] text-gray-500 whitespace-nowrap">
              {filtered.length} of {attributes.length}
            </span>
          </div>
        </div>

        {/* Table */}
        <div className="flex-1 overflow-y-auto">
          <table className="w-full text-left border-collapse">
            <thead className="sticky top-0 bg-gray-50 border-b border-gray-200 z-10">
              <tr>
                <th className="px-5 py-3 text-[12px] font-semibold text-gray-500 uppercase tracking-wide">
                  <div className="flex items-center gap-1 cursor-pointer hover:text-gray-700">
                    Attribute Name <ArrowUpDown className="w-3 h-3" />
                  </div>
                </th>
                <th className="px-4 py-3 text-[12px] font-semibold text-gray-500 uppercase tracking-wide w-24">Type</th>
                <th className="px-4 py-3 text-[12px] font-semibold text-gray-500 uppercase tracking-wide">Description</th>
                <th className="px-4 py-3 text-[12px] font-semibold text-gray-500 uppercase tracking-wide w-28">
                  <div className="flex items-center gap-1 cursor-pointer hover:text-gray-700">
                    Usage <ArrowUpDown className="w-3 h-3" />
                  </div>
                </th>
                <th className="px-4 py-3 text-[12px] font-semibold text-gray-500 uppercase tracking-wide">Validation</th>
                <th className="px-4 py-3 text-[12px] font-semibold text-gray-500 uppercase tracking-wide text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-100">
              {filtered.length === 0 ? (
                <tr>
                  <td colSpan={6} className="px-5 py-12 text-center text-[14px] text-gray-400">
                    No attributes found. Try adjusting your search or filters.
                  </td>
                </tr>
              ) : (
                filtered.map((attr) => (
                  <tr
                    key={attr.id}
                    className={`hover:bg-gray-50 transition-colors ${
                      editingId === attr.id ? "bg-blue-50" : ""
                    }`}
                  >
                    <td className="px-5 py-3.5">
                      <p className="text-[14px] font-medium text-gray-900">{attr.name}</p>
                      {attr.exampleFromStyleGuide && (
                        <p className="text-[12px] text-gray-400 mt-0.5">e.g. {attr.exampleFromStyleGuide}</p>
                      )}
                    </td>
                    <td className="px-4 py-3.5">
                      <span className={`text-[12px] px-2 py-0.5 rounded-full font-medium ${TYPE_COLORS[attr.type]}`}>
                        {attr.type}
                      </span>
                    </td>
                    <td className="px-4 py-3.5">
                      <p className="text-[13px] text-gray-600 line-clamp-2">{attr.description}</p>
                    </td>
                    <td className="px-4 py-3.5">
                      <div className="flex items-center gap-2">
                        <div className="flex-1 h-1.5 bg-gray-100 rounded-full overflow-hidden" style={{ maxWidth: 60 }}>
                          <div
                            className="h-full bg-blue-400 rounded-full"
                            style={{ width: `${Math.min((attr.usageCount / 90) * 100, 100)}%` }}
                          />
                        </div>
                        <span className="text-[12px] text-gray-500">{attr.usageCount}</span>
                      </div>
                    </td>
                    <td className="px-4 py-3.5">
                      {attr.validationRule ? (
                        <span className="text-[12px] text-gray-600 leading-relaxed">
                          {attr.validationRule}
                        </span>
                      ) : (
                        <span className="text-[12px] text-gray-300">—</span>
                      )}
                    </td>
                    <td className="px-4 py-3.5">
                      <div className="flex items-center justify-end gap-1">
                        <button
                          onClick={() => openEdit(attr)}
                          className="w-7 h-7 flex items-center justify-center rounded-lg text-gray-400 hover:bg-blue-50 hover:text-blue-600 transition-colors"
                          title="Edit"
                        >
                          <Edit2 className="w-3.5 h-3.5" />
                        </button>
                        {deleteConfirm === attr.id ? (
                          <div className="flex items-center gap-1">
                            <button
                              onClick={() => handleDelete(attr.id)}
                              className="text-[12px] px-2 py-0.5 bg-red-600 text-white rounded hover:bg-red-700 transition-colors"
                            >
                              Confirm
                            </button>
                            <button
                              onClick={() => setDeleteConfirm(null)}
                              className="text-[12px] px-2 py-0.5 border border-gray-200 text-gray-600 rounded hover:bg-gray-50 transition-colors"
                            >
                              Cancel
                            </button>
                          </div>
                        ) : (
                          <button
                            onClick={() => setDeleteConfirm(attr.id)}
                            className="w-7 h-7 flex items-center justify-center rounded-lg text-gray-400 hover:bg-red-50 hover:text-red-600 transition-colors"
                            title="Delete"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        )}
                      </div>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>

        {/* Table footer */}
        <div className="px-5 py-3 border-t border-gray-200 bg-white flex items-center justify-between shrink-0">
          <p className="text-[13px] text-gray-500">
            Showing <span className="font-medium text-gray-700">{filtered.length}</span> attributes
          </p>
          <p className="text-[13px] text-gray-400">
            Last updated: {new Date().toLocaleDateString()}
          </p>
        </div>
      </div>
    </div>
  );
}
