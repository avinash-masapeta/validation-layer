import React from "react";
import { useNavigate } from "react-router";
import {
  FileText,
  Images,
  Database,
  Download,
  ArrowRight,
  CheckCircle2,
  Clock,
  TrendingUp,
} from "lucide-react";
import { useApp } from "../context/AppContext";

export function Dashboard() {
  const navigate = useNavigate();
  const { images, annotations, attributes, processingComplete } = useApp();

  const reviewedCount = Object.keys(annotations).length;
  const totalImages = images.length;
  const progressPct = totalImages > 0 ? Math.round((reviewedCount / totalImages) * 100) : 0;

  const recentAnnotations = Object.entries(annotations)
    .slice(-3)
    .reverse()
    .map(([imageId, ann]) => {
      const img = images.find((i) => i.id === imageId);
      return { img, ann };
    });

  const quickActions = [
    {
      icon: FileText,
      label: "Load PDFs",
      description: "Add new style guide files",
      to: "/",
      color: "bg-blue-50 text-blue-600",
      iconBg: "bg-blue-100",
    },
    {
      icon: Images,
      label: "Review Images",
      description: `${totalImages - reviewedCount} images pending`,
      to: "/app/review",
      color: "bg-purple-50 text-purple-600",
      iconBg: "bg-purple-100",
    },
    {
      icon: Database,
      label: "Attribute Store",
      description: `${attributes.length} canonical attributes`,
      to: "/app/attributes",
      color: "bg-green-50 text-green-600",
      iconBg: "bg-green-100",
    },
    {
      icon: Download,
      label: "Export Results",
      description: `${reviewedCount} annotations ready`,
      to: "/app/export",
      color: "bg-amber-50 text-amber-700",
      iconBg: "bg-amber-100",
    },
  ];

  return (
    <div className="h-full overflow-y-auto bg-gray-50">
      <div className="max-w-[900px] mx-auto px-6 py-8">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-gray-900 mb-2" style={{ fontSize: 26, fontWeight: 600 }}>
            Dashboard
          </h1>
          <p className="text-[15px] text-gray-500">
            Overview of your style guide annotation session.
          </p>
        </div>

        {/* Stats row */}
        <div className="grid grid-cols-4 gap-4 mb-6">
          {[
            { label: "PDFs Loaded", value: processingComplete ? 3 : 0, icon: FileText, sub: "source files" },
            { label: "Images Extracted", value: processingComplete ? totalImages + 80 : 0, icon: Images, sub: "in queue" },
            { label: "Annotations Done", value: reviewedCount, icon: CheckCircle2, sub: `${progressPct}% complete` },
            { label: "Attributes Defined", value: attributes.length, icon: Database, sub: "canonical attrs" },
          ].map((stat, i) => {
            const Icon = stat.icon;
            return (
              <div key={i} className="bg-white rounded-xl border border-gray-200 shadow-sm px-5 py-4">
                <div className="flex items-start justify-between mb-2">
                  <p className="text-[12px] text-gray-500 uppercase tracking-wide">{stat.label}</p>
                  <Icon className="w-4 h-4 text-gray-300" />
                </div>
                <p className="text-gray-900 font-semibold" style={{ fontSize: 28 }}>{stat.value}</p>
                <p className="text-[12px] text-gray-400 mt-1">{stat.sub}</p>
              </div>
            );
          })}
        </div>

        {/* Progress bar */}
        {reviewedCount > 0 && (
          <div className="bg-white rounded-xl border border-gray-200 shadow-sm px-5 py-4 mb-6">
            <div className="flex items-center justify-between mb-2">
              <div className="flex items-center gap-2">
                <TrendingUp className="w-4 h-4 text-blue-500" />
                <p className="text-[14px] font-semibold text-gray-800">Annotation Progress</p>
              </div>
              <span className="text-[13px] font-semibold text-blue-600">{progressPct}%</span>
            </div>
            <div className="h-2.5 bg-gray-100 rounded-full overflow-hidden mb-2">
              <div
                className="h-full bg-blue-500 rounded-full transition-all duration-700"
                style={{ width: `${progressPct}%` }}
              />
            </div>
            <p className="text-[13px] text-gray-500">
              {reviewedCount} of {totalImages} sample images reviewed
              {totalImages - reviewedCount > 0 && ` · ${totalImages - reviewedCount} remaining`}
            </p>
          </div>
        )}

        <div className="grid grid-cols-2 gap-6">
          {/* Quick actions */}
          <div className="bg-white rounded-xl border border-gray-200 shadow-sm overflow-hidden">
            <div className="px-5 py-4 border-b border-gray-100">
              <h3 className="text-[15px] font-semibold text-gray-800">Quick Actions</h3>
            </div>
            <div className="divide-y divide-gray-100">
              {quickActions.map((action, i) => {
                const Icon = action.icon;
                return (
                  <button
                    key={i}
                    onClick={() => navigate(action.to)}
                    className="w-full flex items-center gap-4 px-5 py-3.5 hover:bg-gray-50 transition-colors text-left"
                  >
                    <div className={`w-9 h-9 rounded-lg ${action.iconBg} flex items-center justify-center shrink-0`}>
                      <Icon className={`w-4.5 h-4.5 ${action.color.split(" ")[1]}`} />
                    </div>
                    <div className="flex-1">
                      <p className="text-[14px] font-medium text-gray-800">{action.label}</p>
                      <p className="text-[12px] text-gray-400">{action.description}</p>
                    </div>
                    <ArrowRight className="w-4 h-4 text-gray-300" />
                  </button>
                );
              })}
            </div>
          </div>

          {/* Recent annotations */}
          <div className="bg-white rounded-xl border border-gray-200 shadow-sm overflow-hidden">
            <div className="px-5 py-4 border-b border-gray-100">
              <h3 className="text-[15px] font-semibold text-gray-800">Recent Annotations</h3>
            </div>
            {recentAnnotations.length === 0 ? (
              <div className="px-5 py-8 text-center">
                <Clock className="w-8 h-8 text-gray-200 mx-auto mb-2" />
                <p className="text-[14px] text-gray-400">No annotations yet</p>
                <p className="text-[13px] text-gray-400 mt-1">
                  Start reviewing images to see activity here
                </p>
                <button
                  onClick={() => navigate("/app/review")}
                  className="mt-4 flex items-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-lg text-[13px] font-medium hover:bg-blue-700 transition-colors mx-auto"
                >
                  Start Review <ArrowRight className="w-3.5 h-3.5" />
                </button>
              </div>
            ) : (
              <div className="divide-y divide-gray-100">
                {recentAnnotations.map(({ img, ann }, i) => (
                  <div key={i} className="px-5 py-3.5 flex items-start gap-3">
                    {img && (
                      <div className="w-10 h-8 rounded overflow-hidden bg-gray-100 shrink-0">
                        <img src={img.thumbUrl} alt="" className="w-full h-full object-cover" />
                      </div>
                    )}
                    <div className="flex-1 min-w-0">
                      <p className="text-[13px] font-medium text-gray-800 truncate">{img?.id ?? "Unknown"}</p>
                      <p className="text-[12px] text-gray-400">
                        {ann.checkedAttributes.length} attributes · {ann.notes ? "With notes" : "No notes"}
                      </p>
                    </div>
                    <CheckCircle2 className="w-4 h-4 text-green-500 shrink-0" />
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}