/**
 * GuardianPrototype.tsx — Step 3 of 4: Guardian Audit Engine
 * Light/white SaaS theme. Implements all 10 pipeline capabilities.
 */
import React, { useState, useEffect, useCallback, useMemo } from "react";
import {
  FileText, Palette, CheckCircle2, ChevronRight, ShieldCheck,
  AlertCircle, X, FileUp, ArrowRight, Download, FileSpreadsheet,
  Loader2, Database, BookOpen, Scale, Map, Layers, ScanText,
  Cpu, Zap, ExternalLink,
} from "lucide-react";
import { useNavigate } from "react-router";

// ── Types ────────────────────────────────────────────────────────────────────
type PipelineStep = "idle"|"layout"|"ocr"|"llm"|"opa"|"dcp"|"validate"|"complete";
type Tab = "canvas"|"ocr"|"llm"|"dcp"|"validation"|"rights"|"mapping"|"export";

interface LayoutBlock { id:number; type:"TEXT"|"IMAGE"; label:string; x:number; y:number; w:number; h:number; ocrText?:string; imageCaption?:string; }
interface LLMRule { type:"do"|"dont"|"constraint"; rule:string; sourceBlock:number; confidence:number; }
interface OPAField { field:string; extractedValue:string; opaValue:string; status:"match"|"mismatch"|"missing"|"gap"; }
interface ValidationResult { checkId:string; category:string; description:string; status:"pass"|"fail"|"warning"|"gap"; detail:string; }
interface DataMappingRow { extractedAttribute:string; llmRule:string; opaField:string; contractField:string; alignmentStatus:"aligned"|"partial"|"conflict"|"unmapped"; }

// ── Mock Data ─────────────────────────────────────────────────────────────────
const LAYOUT_BLOCKS: LayoutBlock[] = [
  { id:1, type:"TEXT", label:"Title Block", x:5, y:4, w:55, h:7, ocrText:"MICKEY AND FRIENDS BRAND GUIDELINES — CC870_2\nLicensee Packaging Standards & Character Usage Rules" },
  { id:2, type:"IMAGE", label:"Character Art Block", x:62, y:5, w:32, h:28, imageCaption:"Official character art: Winnie the Pooh, Tigger, Piglet. Clear space = 0.5× character height." },
  { id:3, type:"TEXT", label:"Usage Rules Block", x:5, y:13, w:55, h:18, ocrText:"USAGE RULES\n✓ DO: Maintain minimum clear space of 0.5× character height on all sides.\n✓ DO: Use only approved Disney Blue (#006EBF) and Princess Gold (#FFD700).\n✗ DO NOT: Alter the aspect ratio of any character or logo asset.\n✗ DO NOT: Apply drop shadows or effects not specified in this guide." },
  { id:4, type:"TEXT", label:"Territory & Rights", x:5, y:33, w:88, h:10, ocrText:"TERRITORY: North America (NA) | Product Category: Apparel, Accessories\nContract Ref: OPA-2024-CC870 | Expiry: 31-Dec-2027\nNOT PERMITTED: Digital media, OOH advertising, broadcast without separate license." },
  { id:5, type:"IMAGE", label:"Color Palette", x:5, y:45, w:40, h:15, imageCaption:"Approved: Disney Blue #006EBF, Princess Gold #FFD700, Midnight Black #1A1A2E, Pure White #FFFFFF." },
  { id:6, type:"TEXT", label:"Typography", x:47, y:45, w:47, h:15, ocrText:"TYPOGRAPHY\nPrimary: Disney (proprietary) | Secondary: Helvetica Neue Bold\nMinimum: 8pt body, 14pt headlines\nDO NOT use non-approved typefaces." },
];

const LLM_RULES: LLMRule[] = [
  { type:"do", rule:"Maintain minimum clear space of 0.5× character height around all brand assets.", sourceBlock:3, confidence:97 },
  { type:"do", rule:"Use only Disney Blue (#006EBF) and Princess Gold (#FFD700) for primary brand elements.", sourceBlock:5, confidence:95 },
  { type:"do", rule:"Reproduce character art at a minimum height of 25mm on all printed materials.", sourceBlock:3, confidence:91 },
  { type:"do", rule:"Include the franchise lockup alongside any character usage.", sourceBlock:3, confidence:88 },
  { type:"dont", rule:"Alter the aspect ratio of any character or logo asset in any way.", sourceBlock:3, confidence:99 },
  { type:"dont", rule:"Apply drop shadows, glows, outlines, or unapproved visual effects to characters.", sourceBlock:3, confidence:98 },
  { type:"dont", rule:"Place characters on backgrounds with less than 4.5:1 contrast ratio.", sourceBlock:3, confidence:93 },
  { type:"dont", rule:"Use assets in digital media, OOH advertising, or broadcast without separate license.", sourceBlock:4, confidence:96 },
  { type:"constraint", rule:"Territory: North America (NA) only. All other territories require separate approval.", sourceBlock:4, confidence:99 },
  { type:"constraint", rule:"Product scope: Apparel and Accessories packaging only.", sourceBlock:4, confidence:97 },
  { type:"constraint", rule:"License expiry: 31-Dec-2027. Usage after this date is a rights violation.", sourceBlock:4, confidence:99 },
];

const OPA_FIELDS: OPAField[] = [
  { field:"License Number", extractedValue:"OPA-2024-CC870", opaValue:"OPA-2024-CC870", status:"match" },
  { field:"Licensee Name", extractedValue:"Acme Corp", opaValue:"Acme Corporation Ltd", status:"mismatch" },
  { field:"Territory", extractedValue:"North America (NA)", opaValue:"NA", status:"match" },
  { field:"Product Category", extractedValue:"Apparel, Accessories", opaValue:"Apparel", status:"mismatch" },
  { field:"Contract Start", extractedValue:"Not found", opaValue:"01-Jan-2024", status:"missing" },
  { field:"Contract Expiry", extractedValue:"31-Dec-2027", opaValue:"31-Dec-2027", status:"match" },
  { field:"Rights Granted", extractedValue:"Physical packaging", opaValue:"Packaging & In-store display", status:"mismatch" },
  { field:"Digital Rights", extractedValue:"NOT PERMITTED", opaValue:"Not granted", status:"match" },
];

const DCP_ASSETS = [
  { id:"DCP-001", name:"Pooh_CharacterArt_Approved_v3.png", type:"Reference Art", date:"2024-03-15", status:"current" },
  { id:"DCP-002", name:"CC870_PackagingMockup_NA_Q1.jpg", type:"Packaging Sample", date:"2024-04-01", status:"current" },
  { id:"DCP-003", name:"DisneyBlue_PaletteChip_2024.png", type:"Color Reference", date:"2024-01-10", status:"current" },
  { id:"DCP-004", name:"TiggerPiglet_PoseSheet_v2.pdf", type:"Model Sheet", date:"2024-02-20", status:"current" },
  { id:"DCP-005", name:"CC870_Typography_Spec.pdf", type:"Type Spec", date:"2023-12-01", status:"outdated" },
];

const VALIDATION: ValidationResult[] = [
  { checkId:"V-001", category:"Clear Space", description:"Character clear space rule compliance", status:"pass", detail:"0.5× height rule confirmed in layout block and DCP reference." },
  { checkId:"V-002", category:"Color Palette", description:"Brand color within approved palette", status:"pass", detail:"Disney Blue #006EBF and Princess Gold #FFD700 match OPA reference." },
  { checkId:"V-003", category:"Aspect Ratio", description:"No character distortion detected", status:"pass", detail:"Character art dimensions validate against DCP-001 reference art." },
  { checkId:"V-004", category:"Territory", description:"Asset territory vs OPA territory", status:"warning", detail:"Both 'NA' but licensee name mismatch may indicate wrong doc version." },
  { checkId:"V-005", category:"Contract Scope", description:"Product category alignment", status:"warning", detail:"Style guide includes 'Accessories' but OPA lists only 'Apparel'." },
  { checkId:"V-006", category:"Expiry Date", description:"License expiry validation", status:"pass", detail:"Extracted 31-Dec-2027 matches OPA record exactly." },
  { checkId:"V-007", category:"Digital Rights", description:"Digital usage restriction check", status:"pass", detail:"Style guide prohibits digital use; aligns with OPA grant." },
  { checkId:"V-008", category:"Rights Scope", description:"Packaging vs in-store display", status:"fail", detail:"OPA grants 'Packaging & In-store display' but guide only mentions packaging." },
  { checkId:"V-009", category:"Contract Start", description:"Start date not in style guide", status:"gap", detail:"01-Jan-2024 (from OPA) not present in style guide. Cannot validate." },
];

const DATA_MAPPING: DataMappingRow[] = [
  { extractedAttribute:"Brand Character", llmRule:"Use only approved character list", opaField:"Character Approved", contractField:"Schedule A — Characters", alignmentStatus:"aligned" },
  { extractedAttribute:"Clear Space", llmRule:"Maintain 0.5× height clear space", opaField:"Brand Usage Rules", contractField:"Clause 4.2", alignmentStatus:"aligned" },
  { extractedAttribute:"Color Palette", llmRule:"Disney Blue + Princess Gold only", opaField:"N/A (Brand doc)", contractField:"Exhibit B — Artwork Standards", alignmentStatus:"partial" },
  { extractedAttribute:"Territory", llmRule:"North America only", opaField:"Territory: NA", contractField:"Clause 1.1 — Grant", alignmentStatus:"aligned" },
  { extractedAttribute:"Product Category", llmRule:"Apparel & Accessories", opaField:"Product Category: Apparel", contractField:"Schedule B", alignmentStatus:"conflict" },
  { extractedAttribute:"Expiry Date", llmRule:"Valid until 31-Dec-2027", opaField:"Expiry: 31-Dec-2027", contractField:"Clause 3.1 — Term", alignmentStatus:"aligned" },
  { extractedAttribute:"Digital Rights", llmRule:"Digital NOT permitted", opaField:"Digital: Not granted", contractField:"Clause 2.3 — Restrictions", alignmentStatus:"aligned" },
  { extractedAttribute:"Renewal Option", llmRule:"Not specified", opaField:"2-year renewal option", contractField:"Clause 3.2 — Renewal", alignmentStatus:"unmapped" },
];

const PIPELINE_ORDER: PipelineStep[] = ["layout","ocr","llm","opa","dcp","validate","complete"];
const STEP_DELAYS: Record<string,number> = { layout:1800, ocr:2000, llm:2500, opa:1500, dcp:1200, validate:2000 };

const TABS: {id:Tab; label:string; icon:React.ElementType; req:PipelineStep|"always"}[] = [
  { id:"canvas",     label:"Document",   icon:Layers,      req:"always" },
  { id:"ocr",        label:"OCR",        icon:ScanText,    req:"ocr" },
  { id:"llm",        label:"LLM Rules",  icon:Cpu,         req:"llm" },
  { id:"dcp",        label:"DCP Vault",  icon:BookOpen,    req:"dcp" },
  { id:"validation", label:"Validation", icon:ShieldCheck, req:"validate" },
  { id:"rights",     label:"Rights",     icon:Scale,       req:"validate" },
  { id:"mapping",    label:"Data Map",   icon:Map,         req:"validate" },
  { id:"export",     label:"Export",     icon:Download,    req:"complete" },
];

function stepIdx(s:PipelineStep) { return ["idle","layout","ocr","llm","opa","dcp","validate","complete"].indexOf(s); }
function reached(cur:PipelineStep, req:PipelineStep|"always") { return req==="always" || stepIdx(cur)>=stepIdx(req as PipelineStep); }

// ── Component ─────────────────────────────────────────────────────────────────
export function GuardianPrototype() {
  const navigate = useNavigate();
  const [step, setStep] = useState<PipelineStep>("idle");
  const [tab, setTab] = useState<Tab>("canvas");
  const [selBlock, setSelBlock] = useState<LayoutBlock|null>(null);
  const [exporting, setExporting] = useState(false);
  const [exported, setExported] = useState(false);

  // Files are already loaded from Steps 1 & 2 — no re-upload needed
  const VAULT_FILES = [
    { name: "Mickey and Friends CC870_2- branding.pdf", pages: 18, size: "5.3 MB" },
    { name: "DisneyPrincess 2338550_2_Packaging guide.pdf", pages: 31, size: "12.0 MB" },
    { name: "3196071 1-styleguide.pdf", pages: 48, size: "22.0 MB" },
  ];

  const isRunning = step !== "idle" && step !== "complete";
  const accuracyScore = Math.round((VALIDATION.filter(v=>v.status==="pass").length / VALIDATION.length)*100);

  useEffect(()=> {
    if (step==="idle"||step==="complete") return;
    const idx = PIPELINE_ORDER.indexOf(step);
    if (idx<0||idx>=PIPELINE_ORDER.length-1) return;
    const next = PIPELINE_ORDER[idx+1];
    const t = setTimeout(()=>{
      setStep(next);
      const m:Partial<Record<PipelineStep,Tab>> = {ocr:"ocr",llm:"llm",opa:"opa",dcp:"dcp",validate:"validation",complete:"export"};
      if (m[next]) setTab(m[next]!);
    }, STEP_DELAYS[step]??1500);
    return ()=>clearTimeout(t);
  },[step]);

  function handleExport() {
    setExporting(true);
    setTimeout(()=>{
      setExporting(false); setExported(true);
      const rows=[
        ["LLM Rules"],["Type","Rule","Block","Confidence %"],
        ...LLM_RULES.map(r=>[r.type.toUpperCase(),r.rule,`Block ${r.sourceBlock}`,r.confidence]),
        [],["OPA Mapping"],["Field","Extracted","OPA Value","Status"],
        ...OPA_FIELDS.map(f=>[f.field,f.extractedValue,f.opaValue,f.status.toUpperCase()]),
        [],["Validation"],["ID","Category","Check","Status","Detail"],
        ...VALIDATION.map(v=>[v.checkId,v.category,v.description,v.status.toUpperCase(),v.detail]),
      ];
      const csv=rows.map(r=>r.map(c=>`"${String(c).replace(/"/g,'""')}"`).join(",")).join("\n");
      const a=document.createElement("a");
      a.href=URL.createObjectURL(new Blob([csv],{type:"text/csv"}));
      a.download=`CastleVision_Audit_${new Date().toISOString().slice(0,10)}.csv`;
      a.click();
    },2500);
  }

  // ── Tab renders ─────────────────────────────────────────────────────────────

  function TabCanvas() {
    const blocksVis = reached(step,"ocr");
    return (
      <div className="h-full flex flex-col overflow-hidden">
        <div className="bg-gray-50 border-b border-gray-200 px-5 py-2.5 flex items-center gap-2 shrink-0">
          <Layers className="w-4 h-4 text-blue-500" />
          <span className="text-[13px] font-semibold text-gray-700">Layout Analysis</span>
          <span className="ml-auto text-[12px] text-gray-400">
            {blocksVis ? `${LAYOUT_BLOCKS.length} blocks detected — click to inspect` : "Awaiting layout extraction…"}
          </span>
        </div>
        <div className="flex-1 overflow-auto flex items-start justify-center py-8 px-6">
          {step==="idle" ? (
            <div className="text-center text-gray-400 mt-20">
              <ShieldCheck className="w-14 h-14 mx-auto mb-4 text-gray-300" />
              <p className="text-[16px] font-semibold text-gray-600">Ready to Analyze</p>
              <p className="text-sm mt-1">Click "Start Full Pipeline" to begin analysis.</p>
            </div>
          ) : (
            <div className="relative bg-white shadow-lg border border-gray-200 rounded-lg overflow-hidden" style={{width:720,minHeight:1020,flexShrink:0}}>
              {/* Static preview of the Disney style guide pages loaded from vault */}
              <img
                src="/data/tigger.png"
                alt="Style Guide Preview"
                className="absolute inset-0 w-full object-contain p-4"
                onError={(e) => { (e.target as HTMLImageElement).style.display = "none"; }}
              />
              {blocksVis && LAYOUT_BLOCKS.map(b=>(
                <div key={b.id} onClick={()=>setSelBlock(b)}
                  style={{left:`${b.x}%`,top:`${b.y}%`,width:`${b.w}%`,height:`${b.h}%`}}
                  className={`absolute border-2 cursor-pointer transition-all z-10 ${
                    selBlock?.id===b.id
                      ? b.type==="IMAGE" ? "bg-orange-500/20 border-orange-500" : "bg-blue-500/20 border-blue-500"
                      : b.type==="IMAGE" ? "bg-orange-100/40 border-orange-400 hover:bg-orange-200/40" : "bg-blue-100/40 border-blue-400 hover:bg-blue-200/40"
                  }`}
                >
                  <span className={`absolute -top-[22px] left-0 px-2 py-0.5 text-[9px] font-bold uppercase text-white rounded-t ${b.type==="IMAGE"?"bg-orange-500":"bg-blue-500"}`}>
                    {b.type} · {b.label}
                  </span>
                </div>
              ))}
              {isRunning && (
                <div className="absolute inset-0 bg-white/70 flex items-center justify-center z-30">
                  <div className="text-center">
                    <Loader2 className="w-10 h-10 animate-spin mx-auto mb-3 text-blue-500" />
                    <p className="text-[13px] font-bold text-blue-600 uppercase tracking-widest">
                      {step==="layout"?"Detecting layout blocks…":step==="ocr"?"Running OCR engine…":step==="llm"?"LLM extracting rules…":step==="opa"?"Mapping OPA fields…":step==="dcp"?"Fetching DCP Vault…":"Running validation…"}
                    </p>
                  </div>
                </div>
              )}
            </div>
          )}
        </div>
        {selBlock && (
          <div className="shrink-0 bg-white border-t border-gray-200 px-5 py-4">
            <div className="flex items-start gap-4">
              <span className={`text-[10px] font-bold uppercase px-2 py-0.5 rounded shrink-0 mt-0.5 ${selBlock.type==="IMAGE"?"bg-orange-100 text-orange-700 border border-orange-200":"bg-blue-100 text-blue-700 border border-blue-200"}`}>
                {selBlock.type}
              </span>
              <div className="flex-1">
                <p className="text-[12px] font-bold text-gray-900 mb-1">{selBlock.label}</p>
                {selBlock.ocrText && <pre className="text-[11px] text-gray-600 font-mono whitespace-pre-wrap leading-relaxed">{selBlock.ocrText}</pre>}
                {selBlock.imageCaption && <p className="text-[11px] text-orange-700 italic">{selBlock.imageCaption}</p>}
              </div>
              <button onClick={()=>setSelBlock(null)} className="text-gray-400 hover:text-gray-700"><X className="w-4 h-4" /></button>
            </div>
          </div>
        )}
      </div>
    );
  }

  function TabOCR() {
    return (
      <div className="h-full overflow-y-auto p-6 space-y-4">
        <div className="flex items-center gap-2 mb-4">
          <ScanText className="w-5 h-5 text-blue-500" />
          <h3 className="text-[15px] font-bold text-gray-900">OCR Extraction Results</h3>
          <span className="ml-auto text-[12px] text-gray-400">{LAYOUT_BLOCKS.length} blocks</span>
        </div>
        {LAYOUT_BLOCKS.map(b=>(
          <div key={b.id} className="bg-white rounded-xl border border-gray-200 shadow-sm overflow-hidden">
            <div className="flex items-center gap-3 px-4 py-3 bg-gray-50 border-b border-gray-100">
              <span className={`text-[9px] font-bold uppercase px-2 py-0.5 rounded ${b.type==="IMAGE"?"bg-orange-100 text-orange-700":"bg-blue-100 text-blue-700"}`}>{b.type}</span>
              <span className="text-[13px] font-semibold text-gray-800">{b.label}</span>
              <span className="ml-auto text-[11px] text-gray-400 font-mono">Block #{b.id}</span>
            </div>
            <div className="px-4 py-4">
              {b.type==="TEXT" && b.ocrText && (
                <>
                  <p className="text-[10px] font-bold uppercase tracking-widest text-blue-600 mb-2">Extracted Text (OCR)</p>
                  <pre className="text-[12px] text-gray-700 font-mono whitespace-pre-wrap bg-gray-50 p-3 rounded-lg border border-gray-100 leading-relaxed">{b.ocrText}</pre>
                </>
              )}
              {b.type==="IMAGE" && (
                <>
                  <p className="text-[10px] font-bold uppercase tracking-widest text-orange-600 mb-2">Image-to-Text Caption (LLM Vision)</p>
                  <p className="text-[12px] text-orange-800 italic bg-orange-50 p-3 rounded-lg border border-orange-100 leading-relaxed">{b.imageCaption}</p>
                </>
              )}
            </div>
          </div>
        ))}
      </div>
    );
  }

  function TabLLM() {
    const dos = LLM_RULES.filter(r=>r.type==="do");
    const donts = LLM_RULES.filter(r=>r.type==="dont");
    const cons = LLM_RULES.filter(r=>r.type==="constraint");
    return (
      <div className="h-full overflow-y-auto p-6">
        <div className="flex items-center gap-2 mb-6">
          <Cpu className="w-5 h-5 text-blue-500" />
          <h3 className="text-[15px] font-bold text-gray-900">LLM Rules Extraction</h3>
          <span className="ml-auto text-[12px] text-gray-400">{LLM_RULES.length} rules from style guide</span>
        </div>
        {/* Do's */}
        <div className="mb-5">
          <h4 className="text-[11px] font-bold uppercase tracking-widest text-green-600 mb-3">✅ Do's ({dos.length})</h4>
          <div className="space-y-2">
            {dos.map((r,i)=>(
              <div key={i} className="flex items-start gap-3 bg-green-50 border border-green-100 rounded-xl px-4 py-3">
                <CheckCircle2 className="w-4 h-4 text-green-500 shrink-0 mt-0.5" />
                <p className="text-[13px] text-gray-700 flex-1 leading-relaxed">{r.rule}</p>
                <div className="text-right shrink-0">
                  <p className="text-[10px] font-bold text-green-600">{r.confidence}%</p>
                  <p className="text-[9px] text-gray-400 font-mono">Blk #{r.sourceBlock}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
        {/* Don'ts */}
        <div className="mb-5">
          <h4 className="text-[11px] font-bold uppercase tracking-widest text-red-600 mb-3">❌ Don'ts ({donts.length})</h4>
          <div className="space-y-2">
            {donts.map((r,i)=>(
              <div key={i} className="flex items-start gap-3 bg-red-50 border border-red-100 rounded-xl px-4 py-3">
                <X className="w-4 h-4 text-red-500 shrink-0 mt-0.5" />
                <p className="text-[13px] text-gray-700 flex-1 leading-relaxed">{r.rule}</p>
                <div className="text-right shrink-0">
                  <p className="text-[10px] font-bold text-red-600">{r.confidence}%</p>
                  <p className="text-[9px] text-gray-400 font-mono">Blk #{r.sourceBlock}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
        {/* Constraints */}
        <div>
          <h4 className="text-[11px] font-bold uppercase tracking-widest text-amber-600 mb-3">📏 Constraints ({cons.length})</h4>
          <div className="space-y-2">
            {cons.map((r,i)=>(
              <div key={i} className="flex items-start gap-3 bg-amber-50 border border-amber-100 rounded-xl px-4 py-3">
                <AlertCircle className="w-4 h-4 text-amber-500 shrink-0 mt-0.5" />
                <p className="text-[13px] text-gray-700 flex-1 leading-relaxed">{r.rule}</p>
                <p className="text-[10px] font-bold text-amber-600 shrink-0">{r.confidence}%</p>
              </div>
            ))}
          </div>
        </div>
      </div>
    );
  }

  function TabOPA() {
    const sIcon = (s:OPAField["status"]) => ({ match:<CheckCircle2 className="w-4 h-4 text-green-500"/>, mismatch:<AlertCircle className="w-4 h-4 text-amber-500"/>, missing:<X className="w-4 h-4 text-red-500"/>, gap:<AlertCircle className="w-4 h-4 text-amber-400"/> }[s]);
    const sBadge = (s:OPAField["status"]) => {
      const m = { match:"bg-green-100 text-green-700 border-green-200", mismatch:"bg-amber-100 text-amber-700 border-amber-200", missing:"bg-red-100 text-red-700 border-red-200", gap:"bg-amber-50 text-amber-600 border-amber-200" }[s];
      return <span className={`text-[9px] font-bold uppercase px-2 py-0.5 rounded border ${m}`}>{s}</span>;
    };
    return (
      <div className="h-full overflow-y-auto p-6">
        <div className="flex items-center gap-2 mb-4">
          <Database className="w-5 h-5 text-blue-500" />
          <h3 className="text-[15px] font-bold text-gray-900">OPA Field Mapping</h3>
          <span className="ml-auto text-[12px] text-gray-400">{OPA_FIELDS.filter(f=>f.status==="match").length}/{OPA_FIELDS.length} matched</span>
        </div>
        {!opaFile ? (
          <label className="flex items-center gap-3 border border-dashed border-gray-300 hover:border-blue-400 rounded-xl p-4 mb-5 cursor-pointer hover:bg-blue-50 transition-all">
            <FileSpreadsheet className="w-5 h-5 text-gray-400" />
            <div>
              <p className="text-[13px] font-semibold text-gray-700">Connect OPA Output (Excel)</p>
              <p className="text-[11px] text-gray-400">Click to upload OPA metadata .xlsx file</p>
            </div>
            <input type="file" className="hidden" accept=".xlsx,.xls,.csv" onChange={e=>e.target.files?.[0]&&setOpaFile(e.target.files[0])} />
          </label>
        ) : (
          <div className="flex items-center gap-3 bg-green-50 border border-green-200 rounded-xl p-3 mb-5">
            <FileSpreadsheet className="w-4 h-4 text-green-500" /><span className="text-[13px] text-green-700 font-semibold">{opaFile.name}</span>
            <CheckCircle2 className="w-4 h-4 text-green-500 ml-auto" />
          </div>
        )}
        <div className="bg-white rounded-xl border border-gray-200 shadow-sm overflow-hidden">
          <table className="w-full text-left">
            <thead><tr className="bg-gray-50 border-b border-gray-100">
              {["Field","Extracted","OPA Value","Status"].map(h=><th key={h} className="px-4 py-3 text-[11px] font-bold uppercase tracking-wider text-gray-400">{h}</th>)}
            </tr></thead>
            <tbody>
              {OPA_FIELDS.map((f,i)=>(
                <tr key={i} className="border-b border-gray-100 hover:bg-gray-50 last:border-0">
                  <td className="px-4 py-3 text-[12px] font-semibold text-gray-800">{f.field}</td>
                  <td className="px-4 py-3 text-[12px] text-gray-500 font-mono">{f.extractedValue}</td>
                  <td className="px-4 py-3 text-[12px] text-gray-500 font-mono">{f.opaValue}</td>
                  <td className="px-4 py-3"><div className="flex items-center gap-2">{sIcon(f.status)}{sBadge(f.status)}</div></td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    );
  }

  function TabDCP() {
    return (
      <div className="h-full overflow-y-auto p-6">
        <div className="flex items-center gap-2 mb-5">
          <BookOpen className="w-5 h-5 text-blue-500" />
          <h3 className="text-[15px] font-bold text-gray-900">DCP Vault — Reference Assets</h3>
          <span className="ml-auto text-[12px] text-gray-400">{DCP_ASSETS.length} assets</span>
        </div>
        <div className="space-y-2">
          {DCP_ASSETS.map(a=>(
            <div key={a.id} className="flex items-center gap-4 bg-white border border-gray-200 shadow-sm rounded-xl px-4 py-3.5 hover:border-blue-300 hover:bg-blue-50/30 transition-all group">
              <div className="w-9 h-9 rounded-lg bg-blue-50 border border-blue-100 flex items-center justify-center shrink-0">
                <FileText className="w-4 h-4 text-blue-500" />
              </div>
              <div className="flex-1 min-w-0">
                <p className="text-[13px] font-semibold text-gray-800 truncate">{a.name}</p>
                <div className="flex items-center gap-2 mt-0.5">
                  <span className="text-[10px] text-gray-400 font-mono">{a.id}</span>
                  <span className="text-gray-300">·</span>
                  <span className="text-[11px] text-blue-600 font-semibold">{a.type}</span>
                  <span className="text-gray-300">·</span>
                  <span className="text-[11px] text-gray-400">{a.date}</span>
                </div>
              </div>
              <span className={`text-[9px] font-bold uppercase px-2 py-0.5 rounded border ${a.status==="current"?"bg-green-100 text-green-700 border-green-200":"bg-amber-100 text-amber-700 border-amber-200"}`}>{a.status}</span>
              <ExternalLink className="w-4 h-4 text-gray-300 group-hover:text-blue-500 transition-colors" />
            </div>
          ))}
        </div>
        <div className="mt-5 p-4 bg-blue-50 border border-blue-100 rounded-xl">
          <p className="text-[12px] font-semibold text-blue-700 mb-1">DCP Vault Integration</p>
          <p className="text-[12px] text-blue-600">Assets retrieved from the Disney Content Portal using license reference OPA-2024-CC870. Used in automated validation for accuracy scoring.</p>
        </div>
      </div>
    );
  }

  function TabValidation() {
    const counts = { pass:VALIDATION.filter(v=>v.status==="pass").length, warning:VALIDATION.filter(v=>v.status==="warning").length, fail:VALIDATION.filter(v=>v.status==="fail").length, gap:VALIDATION.filter(v=>v.status==="gap").length };
    const badge = (s:ValidationResult["status"])=>{
      const m={pass:"bg-green-100 text-green-700 border-green-200",warning:"bg-amber-100 text-amber-700 border-amber-200",fail:"bg-red-100 text-red-700 border-red-200",gap:"bg-orange-100 text-orange-700 border-orange-200"}[s];
      return <span className={`text-[9px] font-bold uppercase px-2 py-0.5 rounded border ${m}`}>{s}</span>;
    };
    return (
      <div className="h-full overflow-y-auto p-6">
        <div className="flex items-center gap-2 mb-5">
          <ShieldCheck className="w-5 h-5 text-blue-500" />
          <h3 className="text-[15px] font-bold text-gray-900">Automated Validation</h3>
        </div>
        <div className="grid grid-cols-5 gap-3 mb-6">
          <div className="col-span-1 bg-blue-600 rounded-xl p-4 flex flex-col items-center justify-center shadow-sm">
            <p className="text-[30px] font-black text-white">{accuracyScore}%</p>
            <p className="text-[10px] text-blue-200 uppercase tracking-widest font-bold">Score</p>
          </div>
          {[{label:"Pass",v:counts.pass,cls:"text-green-600 bg-green-50 border-green-100"},{label:"Warning",v:counts.warning,cls:"text-amber-600 bg-amber-50 border-amber-100"},{label:"Fail",v:counts.fail,cls:"text-red-600 bg-red-50 border-red-100"},{label:"Gap",v:counts.gap,cls:"text-orange-600 bg-orange-50 border-orange-100"}].map(s=>(
            <div key={s.label} className={`rounded-xl p-4 flex flex-col items-center border ${s.cls}`}>
              <p className={`text-[24px] font-black ${s.cls.split(" ")[0]}`}>{s.v}</p>
              <p className="text-[10px] text-gray-500 uppercase tracking-widest font-bold">{s.label}</p>
            </div>
          ))}
        </div>
        <div className="bg-white rounded-xl border border-gray-200 shadow-sm overflow-hidden">
          <table className="w-full text-left">
            <thead><tr className="bg-gray-50 border-b border-gray-100">
              {["ID","Category","Check","Detail","Result"].map(h=><th key={h} className="px-4 py-3 text-[11px] font-bold uppercase tracking-wider text-gray-400">{h}</th>)}
            </tr></thead>
            <tbody>
              {VALIDATION.map(v=>(
                <tr key={v.checkId} className="border-b border-gray-100 hover:bg-gray-50 last:border-0 text-[12px]">
                  <td className="px-4 py-3 font-mono text-blue-600">{v.checkId}</td>
                  <td className="px-4 py-3 font-semibold text-gray-700">{v.category}</td>
                  <td className="px-4 py-3 text-gray-600">{v.description}</td>
                  <td className="px-4 py-3 text-gray-400 max-w-[180px] text-[11px]">{v.detail}</td>
                  <td className="px-4 py-3">{badge(v.status)}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    );
  }

  function TabRights() {
    const gaps = OPA_FIELDS.filter(f=>f.status==="gap"||f.status==="missing");
    return (
      <div className="h-full overflow-y-auto p-6">
        <div className="flex items-center gap-2 mb-5">
          <Scale className="w-5 h-5 text-blue-500" />
          <h3 className="text-[15px] font-bold text-gray-900">Rights Validation</h3>
        </div>
        <div className="grid grid-cols-3 gap-3 mb-6">
          <div className="bg-white border border-gray-200 shadow-sm rounded-xl p-4">
            <p className="text-[10px] font-bold uppercase tracking-widest text-blue-600 mb-2">Contract Status</p>
            <p className="text-[18px] font-black text-green-600">Available</p>
            <p className="text-[11px] text-gray-400 mt-1">OPA-2024-CC870</p>
          </div>
          <div className="bg-white border border-gray-200 shadow-sm rounded-xl p-4">
            <p className="text-[10px] font-bold uppercase tracking-widest text-blue-600 mb-2">Fields Validated</p>
            <p className="text-[18px] font-black text-gray-900">{OPA_FIELDS.filter(f=>f.status==="match").length}<span className="text-gray-400 text-[13px]">/{OPA_FIELDS.length}</span></p>
          </div>
          <div className="bg-red-50 border border-red-100 shadow-sm rounded-xl p-4">
            <p className="text-[10px] font-bold uppercase tracking-widest text-red-500 mb-2">Gaps Flagged</p>
            <p className="text-[18px] font-black text-red-600">{gaps.length}</p>
          </div>
        </div>
        <div className="space-y-2 mb-5">
          {OPA_FIELDS.map((f,i)=>(
            <div key={i} className={`flex items-center gap-4 px-4 py-3 rounded-xl border ${f.status==="match"?"bg-green-50 border-green-100":f.status==="mismatch"?"bg-amber-50 border-amber-100":"bg-red-50 border-red-100"}`}>
              {f.status==="match"?<CheckCircle2 className="w-4 h-4 text-green-500 shrink-0"/>:f.status==="mismatch"?<AlertCircle className="w-4 h-4 text-amber-500 shrink-0"/>:<X className="w-4 h-4 text-red-500 shrink-0"/>}
              <span className="text-[13px] font-semibold text-gray-800 w-36 shrink-0">{f.field}</span>
              <span className="text-[12px] text-gray-500 font-mono flex-1 truncate">Extracted: {f.extractedValue}</span>
              <span className="text-[12px] text-gray-500 font-mono flex-1 truncate">OPA: {f.opaValue}</span>
            </div>
          ))}
        </div>
        <h4 className="text-[11px] font-bold uppercase tracking-widest text-red-600 mb-3">Validation Gaps</h4>
        <div className="space-y-2">
          {gaps.map((g,i)=>(
            <div key={i} className="flex items-start gap-3 bg-red-50 border border-red-100 rounded-xl px-4 py-3">
              <AlertCircle className="w-4 h-4 text-red-500 shrink-0 mt-0.5" />
              <div>
                <p className="text-[13px] font-semibold text-red-700">{g.field}</p>
                <p className="text-[12px] text-gray-500 mt-0.5">{g.status==="missing"?"Field not found in style guide document.":"Field exists in OPA but not mapped in extracted data."}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    );
  }

  function TabMapping() {
    const alignCls = (s:DataMappingRow["alignmentStatus"]) => ({aligned:"bg-green-100 text-green-700 border-green-200",partial:"bg-amber-100 text-amber-700 border-amber-200",conflict:"bg-red-100 text-red-700 border-red-200",unmapped:"bg-gray-100 text-gray-500 border-gray-200"}[s]);
    return (
      <div className="h-full overflow-y-auto p-6">
        <div className="flex items-center gap-2 mb-5">
          <Map className="w-5 h-5 text-blue-500" />
          <h3 className="text-[15px] font-bold text-gray-900">Data Mapping & Alignment</h3>
        </div>
        <div className="bg-white rounded-xl border border-gray-200 shadow-sm overflow-hidden">
          <table className="w-full text-left">
            <thead><tr className="bg-gray-50 border-b border-gray-100">
              {["Extracted Attribute","LLM Rule","Contract Clause","Alignment"].map(h=><th key={h} className="px-4 py-3 text-[11px] font-bold uppercase tracking-wider text-gray-400">{h}</th>)}
            </tr></thead>
            <tbody>
              {DATA_MAPPING.map((row,i)=>(
                <tr key={i} className="border-b border-gray-100 hover:bg-gray-50 last:border-0">
                  <td className="px-4 py-3 text-[12px] font-semibold text-gray-800">{row.extractedAttribute}</td>
                  <td className="px-4 py-3 text-[11px] text-gray-500 max-w-[180px]">{row.llmRule}</td>
                  <td className="px-4 py-3 text-[12px] font-mono text-purple-600">{row.contractField}</td>
                  <td className="px-4 py-3"><span className={`text-[9px] font-bold uppercase px-2 py-0.5 rounded border ${alignCls(row.alignmentStatus)}`}>{row.alignmentStatus}</span></td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    );
  }

  function TabExport() {
    const sheets = [
      { name:"OCR Extraction", rows:LAYOUT_BLOCKS.length, desc:"Raw text and image captions per block" },
      { name:"LLM Rules", rows:LLM_RULES.length, desc:"Do's, Don'ts, and Constraints" },
      { name:"OPA Field Mapping", rows:OPA_FIELDS.length, desc:"Extracted vs OPA comparison" },
      { name:"DCP Vault Assets", rows:DCP_ASSETS.length, desc:"Retrieved reference assets" },
      { name:"Validation Results", rows:VALIDATION.length, desc:"Automated compliance checks" },
      { name:"Data Mapping Schema", rows:DATA_MAPPING.length, desc:"Unified attribute alignment" },
    ];
    return (
      <div className="h-full overflow-y-auto p-6">
        <div className="flex items-center gap-2 mb-5">
          <Download className="w-5 h-5 text-blue-500" />
          <h3 className="text-[15px] font-bold text-gray-900">Output Generation</h3>
        </div>
        <div className="grid grid-cols-4 gap-3 mb-6">
          {[{l:"PDFs Processed",v:"3",c:"text-blue-600"},{l:"Blocks Detected",v:String(LAYOUT_BLOCKS.length),c:"text-purple-600"},{l:"Rules Extracted",v:String(LLM_RULES.length),c:"text-green-600"},{l:"Accuracy Score",v:`${accuracyScore}%`,c:"text-amber-600"}].map(s=>(
            <div key={s.l} className="bg-white rounded-xl border border-gray-200 shadow-sm p-4">
              <p className={`text-[24px] font-black ${s.c}`}>{s.v}</p>
              <p className="text-[11px] text-gray-400 uppercase tracking-wider font-semibold">{s.l}</p>
            </div>
          ))}
        </div>
        <div className="bg-white rounded-xl border border-gray-200 shadow-sm overflow-hidden mb-5">
          {sheets.map((s,i)=>(
            <div key={i} className="flex items-center gap-4 px-4 py-3.5 border-b border-gray-100 last:border-0 hover:bg-gray-50">
              <FileSpreadsheet className="w-4 h-4 text-green-500 shrink-0" />
              <div className="flex-1">
                <p className="text-[13px] font-semibold text-gray-800">{s.name}</p>
                <p className="text-[11px] text-gray-400">{s.desc}</p>
              </div>
              <span className="text-[11px] text-gray-400 font-mono">{s.rows} rows</span>
            </div>
          ))}
        </div>
        {exported ? (
          <div className="flex items-center gap-4 bg-green-50 border border-green-200 rounded-xl p-4">
            <CheckCircle2 className="w-8 h-8 text-green-500" />
            <div>
              <p className="text-[14px] font-bold text-green-800">Export Complete!</p>
              <p className="text-[12px] text-green-600 font-mono mt-0.5">CastleVision_Audit_{new Date().toISOString().slice(0,10)}.csv downloaded.</p>
            </div>
            <button onClick={()=>setExported(false)} className="ml-auto text-[12px] text-gray-500 border border-gray-200 px-3 py-1.5 rounded-lg hover:bg-gray-50">Again</button>
          </div>
        ) : (
          <button onClick={handleExport} disabled={exporting}
            className="w-full flex items-center justify-center gap-2 py-3.5 bg-blue-600 hover:bg-blue-700 text-white rounded-xl text-[15px] font-bold transition-colors disabled:opacity-50">
            {exporting ? <><Loader2 className="w-5 h-5 animate-spin"/>Generating…</> : <><FileSpreadsheet className="w-5 h-5"/>Download Full Audit Report (CSV)</>}
          </button>
        )}

      </div>
    );
  }

  // ── Sidebar steps ─────────────────────────────────────────────────────────
  const sidebarSteps = [
    { key:"layout" as PipelineStep, label:"Layout Extraction", icon:Layers },
    { key:"ocr"    as PipelineStep, label:"OCR + Image-to-Text", icon:ScanText },
    { key:"llm"    as PipelineStep, label:"LLM Rules Analysis", icon:Cpu },
    { key:"opa"    as PipelineStep, label:"OPA Integration", icon:Database },
    { key:"dcp"    as PipelineStep, label:"DCP Vault Fetch", icon:BookOpen },
    { key:"validate" as PipelineStep, label:"Validation Layer", icon:ShieldCheck },
  ];

  return (
    <div className="flex flex-col h-screen bg-gray-50 font-sans overflow-hidden">

      {/* Header */}
      <header className="bg-white border-b border-gray-200 px-6 h-[72px] shrink-0 flex items-center justify-between shadow-sm z-50">
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 rounded-xl bg-blue-600 flex items-center justify-center">
            <ShieldCheck className="w-4 h-4 text-white" />
          </div>
          <div>
            <p className="text-[14px] font-bold text-gray-900 leading-tight">Style Guide</p>
            <p className="text-[11px] text-gray-400 leading-tight">Annotator</p>
          </div>
        </div>
        <div className="flex items-center gap-2 text-[13px] text-gray-400">
          <span>Load PDFs</span><ChevronRight className="w-3.5 h-3.5 text-gray-300"/>
          <span>Process</span><ChevronRight className="w-3.5 h-3.5 text-gray-300"/>
          <span className="px-2 py-0.5 bg-blue-50 text-blue-600 border border-blue-100 rounded text-[12px] font-bold">Step 3 of 4</span>
          <span className="text-gray-800 font-semibold ml-1">Guardian Audit</span>
          <ChevronRight className="w-3.5 h-3.5 text-gray-300"/>
          <span>Review</span>
        </div>
      </header>

      {/* Body */}
      <div className="flex-1 overflow-hidden" style={{ display:"grid", gridTemplateColumns:"272px 1fr", minHeight:0 }}>

        {/* Sidebar */}
        <aside className="bg-white border-r border-gray-200 flex flex-col overflow-y-auto">
          <div className="p-5 space-y-5 flex-1">
            {/* Vault files — pre-loaded from Steps 1 & 2 */}
            <section>
              <h3 className="text-[10px] font-bold uppercase tracking-widest text-blue-600 mb-2">Loaded from Vault</h3>
              <div className="space-y-1.5">
                {VAULT_FILES.map((f, i) => (
                  <div key={i} className="flex items-start gap-2.5 bg-blue-50 border border-blue-100 rounded-xl px-3 py-2.5">
                    <FileText className="w-3.5 h-3.5 text-blue-500 shrink-0 mt-0.5" />
                    <div className="flex-1 min-w-0">
                      <p className="text-[11px] font-semibold text-blue-800 leading-snug truncate">{f.name}</p>
                      <p className="text-[10px] text-blue-400 mt-0.5">{f.pages} pages · {f.size}</p>
                    </div>
                    <CheckCircle2 className="w-3.5 h-3.5 text-green-500 shrink-0 mt-0.5" />
                  </div>
                ))}
              </div>
            </section>

            {/* CTA */}
            {step==="idle" ? (
              <button onClick={()=>setStep("layout")}
                className="w-full py-3 bg-blue-600 hover:bg-blue-700 text-white rounded-xl font-bold text-[14px] transition-colors flex items-center justify-center gap-2">
                <Zap className="w-4 h-4" /> Start Full Pipeline
              </button>
            ) : step==="complete" ? (
              <button onClick={()=>navigate("/app/review")}
                className="w-full py-3 bg-green-600 hover:bg-green-700 text-white rounded-xl font-bold text-[14px] transition-colors flex items-center justify-center gap-2">
                Continue to Review <ArrowRight className="w-4 h-4" />
              </button>
            ) : (
              <div className="flex items-center justify-center gap-2 py-3 text-[13px] text-blue-600 font-semibold">
                <Loader2 className="w-4 h-4 animate-spin" /> Processing…
              </div>
            )}

            {/* Progress steps */}
            <div className="space-y-2 pt-2 border-t border-gray-100">
              {sidebarSteps.map(({key,label,icon:Icon})=>{
                const r = reached(step, key); const cur = step===key;
                return (
                  <div key={key} className={`flex items-center gap-3 py-1.5 transition-all ${r?"opacity-100":"opacity-30"}`}>
                    {cur ? <Loader2 className="w-4 h-4 animate-spin text-blue-500 shrink-0"/> : r ? <CheckCircle2 className="w-4 h-4 text-green-500 shrink-0"/> : <div className="w-4 h-4 rounded-full border-2 border-gray-300 shrink-0"/>}
                    <span className={`text-[12px] font-semibold ${cur?"text-blue-600":r?"text-gray-700":"text-gray-400"}`}>{label}</span>
                  </div>
                );
              })}
            </div>
          </div>
        </aside>

        {/* Tab area */}
        <div className="flex flex-col overflow-hidden">
          {/* Tab bar */}
          <div className="bg-white border-b border-gray-200 flex items-center px-2 gap-0.5 shrink-0 overflow-x-auto">
            {TABS.map(({id,label,icon:Icon,req})=>{
              const en = reached(step,req); const active = tab===id;
              return (
                <button key={id} disabled={!en} onClick={()=>setTab(id)}
                  className={`flex items-center gap-2 px-4 py-3.5 text-[13px] font-semibold whitespace-nowrap transition-all border-b-2 ${active?"text-blue-600 border-blue-500":en?"text-gray-500 border-transparent hover:text-gray-800 hover:bg-gray-50":"text-gray-300 border-transparent cursor-not-allowed"}`}>
                  <Icon className={`w-3.5 h-3.5 ${active?"text-blue-500":""}`} />
                  {label}
                  {id==="validation" && step==="complete" && <span className="ml-1 text-[9px] bg-blue-100 text-blue-600 border border-blue-200 px-1.5 py-0.5 rounded font-bold">{accuracyScore}%</span>}
                </button>
              );
            })}
          </div>

          {/* Content */}
          <div className="flex-1 overflow-hidden bg-gray-50">
            {tab==="canvas"     && <TabCanvas/>}
            {tab==="ocr"        && reached(step,"ocr")      && <TabOCR/>}
            {tab==="llm"        && reached(step,"llm")      && <TabLLM/>}
            {tab==="dcp"        && reached(step,"dcp")      && <TabDCP/>}
            {tab==="validation" && reached(step,"validate") && <TabValidation/>}
            {tab==="rights"     && reached(step,"validate") && <TabRights/>}
            {tab==="mapping"    && reached(step,"validate") && <TabMapping/>}
            {tab==="export"     && reached(step,"complete") && <TabExport/>}
            {tab!=="canvas" && !reached(step, TABS.find(t=>t.id===tab)?.req??"always") && (
              <div className="h-full flex flex-col items-center justify-center text-center p-10 text-gray-400">
                <ShieldCheck className="w-12 h-12 mb-4 text-gray-200" />
                <p className="text-[15px] font-semibold text-gray-500">Run the pipeline to unlock this panel</p>
                <p className="text-sm mt-1">Upload your files and click "Start Full Pipeline"</p>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
