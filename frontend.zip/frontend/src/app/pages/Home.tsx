/**
 * Home.tsx — Step 1 of 4: Load PDFs
 * Light/white SaaS theme matching the reference design.
 */
import React, { useState } from "react";
import { useNavigate } from "react-router";
import { FolderOpen, FileText, ChevronRight, ArrowRight, Info, CheckCircle2 } from "lucide-react";
import { useApp } from "../context/AppContext";

const DISNEY_PDFS = [
  { name: "3196071 1-styleguide.pdf", size: "22.0 MB", pages: 48 },
  { name: "DisneyPrincess 2338550_2_Packaging guide.pdf", size: "12.0 MB", pages: 31 },
  { name: "Mickey and Friends CC870_2- branding.pdf", size: "5.3 MB", pages: 18 },
];

export function Home() {
  const navigate = useNavigate();
  const { folderPath, setFolderPath, setPdfCount } = useApp();
  const [loaded, setLoaded] = useState(false);
  const [loading, setLoading] = useState(false);

  function handleBrowse() {
    // Simulate folder selection
    setFolderPath("c:/Users/avina/Documents/Projects/disney/data");
  }

  function handleRead() {
    setLoading(true);
    setTimeout(() => {
      setLoading(false);
      setLoaded(true);
      setPdfCount(DISNEY_PDFS.length);
    }, 1200);
  }

  return (
    <div className="flex-1 overflow-y-auto bg-gray-50 p-8">
      <div className="max-w-2xl mx-auto">

        {/* Page header */}
        <div className="mb-8">
          {/* Breadcrumb */}
          <div className="flex items-center gap-2 text-[13px] text-gray-500 mb-4">
            <span className="px-2 py-0.5 bg-blue-50 text-blue-600 border border-blue-100 rounded font-semibold text-[12px]">Step 1 of 4</span>
            <span className="font-semibold text-gray-800">Load PDFs</span>
            <ChevronRight className="w-3.5 h-3.5 text-gray-300" />
            <span>Process</span>
            <ChevronRight className="w-3.5 h-3.5 text-gray-300" />
            <span>Guardian Audit</span>
            <ChevronRight className="w-3.5 h-3.5 text-gray-300" />
            <span>Review</span>
          </div>

          <h1 className="text-[28px] font-bold text-gray-900 mb-1">Load Style Guide Vault</h1>
          <p className="text-[15px] text-gray-500">
            Point the intake engine to the folder containing your Disney Style Guide PDFs.
          </p>
        </div>

        {/* Vault selection card */}
        <div className="bg-white rounded-2xl border border-gray-200 shadow-sm p-6 mb-4">
          <h2 className="text-[15px] font-semibold text-gray-900 mb-1">Vault Selection</h2>
          <p className="text-[13px] text-gray-400 mb-5">
            Point the intake engine to the folder containing your PDFs.
          </p>

          <label className="block text-[11px] font-semibold uppercase tracking-widest text-gray-400 mb-1.5">
            Origin Folder Path
          </label>
          <div className="flex gap-2">
            <div className="flex-1 flex items-center gap-2 px-3 py-2.5 border border-gray-200 rounded-lg bg-gray-50">
              <FolderOpen className="w-4 h-4 text-blue-500 shrink-0" />
              <span className="text-[13px] text-gray-700 font-mono truncate">{folderPath}</span>
            </div>
            <button
              onClick={handleBrowse}
              className="px-4 py-2.5 border border-gray-200 rounded-lg text-[13px] font-semibold text-gray-700 bg-white hover:bg-gray-50 transition-colors"
            >
              Browse Vault
            </button>
          </div>
          <p className="text-[12px] text-gray-400 mt-2">
            Permissions will automatically propagate through all valid subdirectories.
          </p>

          <button
            onClick={handleRead}
            disabled={loading || loaded}
            className="mt-5 flex items-center gap-2 px-5 py-2.5 bg-blue-600 hover:bg-blue-700 disabled:bg-blue-400 text-white rounded-lg text-[14px] font-semibold transition-colors"
          >
            <FolderOpen className="w-4 h-4" />
            {loading ? "Reading Vault…" : loaded ? "Vault Loaded" : "Read Active Vault"}
          </button>
        </div>

        {/* Info box */}
        <div className="bg-blue-50 border border-blue-100 rounded-2xl p-4 mb-6 flex gap-3">
          <Info className="w-4 h-4 text-blue-500 shrink-0 mt-0.5" />
          <div>
            <p className="text-[12px] font-semibold text-blue-700 uppercase tracking-widest mb-1">Pipeline Instructions</p>
            <p className="text-[13px] text-blue-600">
              Map your local or cloud directory. Click "Read Active Vault" to safely mount the credentials,
              then proceed to the extraction step where vectors will be analysed.
            </p>
          </div>
        </div>

        {/* PDF list after load */}
        {loaded && (
          <div className="bg-white rounded-2xl border border-gray-200 shadow-sm overflow-hidden mb-6 animate-in fade-in slide-in-from-bottom-2 duration-300">
            <div className="px-5 py-4 border-b border-gray-100 flex items-center justify-between">
              <div>
                <h3 className="text-[14px] font-semibold text-gray-900">Discovered PDFs</h3>
                <p className="text-[12px] text-gray-400">{DISNEY_PDFS.length} style guides found in vault</p>
              </div>
              <span className="text-[12px] font-semibold text-green-600 bg-green-50 border border-green-100 px-3 py-1 rounded-full flex items-center gap-1">
                <CheckCircle2 className="w-3.5 h-3.5" /> Ready
              </span>
            </div>
            <ul className="divide-y divide-gray-100">
              {DISNEY_PDFS.map((pdf, i) => (
                <li key={i} className="flex items-center gap-4 px-5 py-3.5 hover:bg-gray-50 transition-colors">
                  <div className="w-8 h-8 rounded-lg bg-blue-50 border border-blue-100 flex items-center justify-center shrink-0">
                    <FileText className="w-4 h-4 text-blue-500" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-[13px] font-semibold text-gray-800 truncate">{pdf.name}</p>
                    <p className="text-[12px] text-gray-400">{pdf.pages} pages · {pdf.size}</p>
                  </div>
                  <CheckCircle2 className="w-4 h-4 text-green-500 shrink-0" />
                </li>
              ))}
            </ul>

            <div className="px-5 py-4 border-t border-gray-100">
              <button
                onClick={() => navigate("/processing")}
                className="flex items-center gap-2 px-6 py-2.5 bg-blue-600 hover:bg-blue-700 text-white rounded-lg text-[14px] font-semibold transition-colors"
              >
                Proceed to Processing <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
