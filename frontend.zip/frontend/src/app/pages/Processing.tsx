/**
 * Processing.tsx — Step 2 of 4: PDF Extraction Engine
 * Light/white SaaS theme.
 */
import React, { useState, useEffect } from "react";
import { useNavigate } from "react-router";
import { CheckCircle2, Loader2, ChevronRight, ArrowRight, FileText, Layers, ScanText, Image as ImageIcon } from "lucide-react";

type Stage = "idle" | "layout" | "ocr" | "images" | "done";

const STAGES: { key: Stage; label: string; desc: string; icon: React.ElementType }[] = [
  { key: "layout", label: "Layout Analysis", desc: "Detecting text and image blocks per page", icon: Layers },
  { key: "ocr",    label: "OCR Extraction", desc: "Running optical character recognition on text blocks", icon: ScanText },
  { key: "images", label: "Image Extraction", desc: "Isolating image blocks and generating captions", icon: ImageIcon },
];

const STAGE_ORDER: Stage[] = ["layout", "ocr", "images"];

const PDF_NAMES = [
  "Mickey and Friends CC870_2- branding.pdf",
  "DisneyPrincess 2338550_2_Packaging guide.pdf",
  "3196071 1-styleguide.pdf",
];

export function Processing() {
  const navigate = useNavigate();
  const [stage, setStage] = useState<Stage>("idle");
  const [pdfIndex, setPdfIndex] = useState(0);
  const [started, setStarted] = useState(false);

  useEffect(() => {
    if (!started) return;
    const order: Stage[] = ["layout", "ocr", "images", "done"];
    let s = 0;
    const advance = () => {
      s++;
      if (s >= order.length) return;
      setStage(order[s]);
      if (order[s] !== "done") setTimeout(advance, 2000);
    };
    setStage("layout");
    setTimeout(advance, 2000);
  }, [started]);

  // Cycle through PDFs while processing
  useEffect(() => {
    if (stage === "idle" || stage === "done") return;
    const t = setInterval(() => {
      setPdfIndex((i) => (i + 1) % PDF_NAMES.length);
    }, 1800);
    return () => clearInterval(t);
  }, [stage]);

  const stageIndex = (s: Stage) => ["idle","layout","ocr","images","done"].indexOf(s);

  // Progress: how many stages are fully done
  const completedCount = STAGE_ORDER.filter(s => stageIndex(stage) > stageIndex(s)).length;
  const progressPct = stage === "done" ? 100 : stage === "idle" ? 0 : Math.round((completedCount / STAGE_ORDER.length) * 100);

  return (
    <div className="flex-1 overflow-y-auto bg-gray-50 p-8">
      <div className="max-w-2xl mx-auto">

        {/* Breadcrumb */}
        <div className="flex items-center gap-2 text-[13px] text-gray-500 mb-6">
          <span className="text-gray-400">Load PDFs</span>
          <ChevronRight className="w-3.5 h-3.5 text-gray-300" />
          <span className="px-2 py-0.5 bg-blue-50 text-blue-600 border border-blue-100 rounded font-semibold text-[12px]">Step 2 of 4</span>
          <span className="font-semibold text-gray-800">Process</span>
          <ChevronRight className="w-3.5 h-3.5 text-gray-300" />
          <span className="text-gray-400">Guardian Audit</span>
          <ChevronRight className="w-3.5 h-3.5 text-gray-300" />
          <span className="text-gray-400">Review</span>
        </div>

        <h1 className="text-[28px] font-bold text-gray-900 mb-1">Extraction Engine</h1>
        <p className="text-[15px] text-gray-500 mb-8">
          Layout analysis, OCR, and image extraction across all 3 style guide PDFs.
        </p>

        {/* PDF in progress */}
        {stage !== "idle" && stage !== "done" && (
          <div className="bg-white rounded-2xl border border-gray-200 shadow-sm p-5 mb-4 flex items-center gap-4">
            <div className="w-10 h-10 rounded-xl bg-blue-50 border border-blue-100 flex items-center justify-center shrink-0">
              <FileText className="w-5 h-5 text-blue-500" />
            </div>
            <div className="flex-1 min-w-0">
              <p className="text-[13px] font-semibold text-gray-800 truncate">{PDF_NAMES[pdfIndex]}</p>
              <p className="text-[12px] text-blue-500 font-medium">Processing…</p>
            </div>
            <Loader2 className="w-5 h-5 text-blue-500 animate-spin shrink-0" />
          </div>
        )}

        {/* Progress bar */}
        {stage !== "idle" && (
          <div className="bg-white rounded-2xl border border-gray-200 shadow-sm p-5 mb-4">
            <div className="flex items-center justify-between mb-2">
              <span className="text-[13px] font-semibold text-gray-700">Extraction Progress</span>
              <span className="text-[13px] font-bold text-blue-600">{progressPct}%</span>
            </div>
            <div className="h-2 bg-gray-100 rounded-full overflow-hidden">
              <div
                className="h-full bg-blue-500 rounded-full transition-all duration-700 ease-out"
                style={{ width: `${progressPct}%` }}
              />
            </div>
            <p className="text-[11px] text-gray-400 mt-2">
              {stage === "done" ? "All stages complete" : `${completedCount} of ${STAGE_ORDER.length} stages complete`}
            </p>
          </div>
        )}

        {/* Stages */}
        <div className="bg-white rounded-2xl border border-gray-200 shadow-sm overflow-hidden mb-6">
          {STAGES.map(({ key, label, desc, icon: Icon }, i) => {
            const current = stage === key;
            const done = stageIndex(stage) > stageIndex(key);
            return (
              <div key={key} className={`flex items-center gap-4 px-5 py-4 ${i < STAGES.length - 1 ? "border-b border-gray-100" : ""} ${current ? "bg-blue-50/50" : ""}`}>
                <div className={`w-9 h-9 rounded-xl flex items-center justify-center shrink-0 ${done ? "bg-green-50 border border-green-100" : current ? "bg-blue-50 border border-blue-200" : "bg-gray-50 border border-gray-200"}`}>
                  {done
                    ? <CheckCircle2 className="w-4 h-4 text-green-500" />
                    : current
                    ? <Loader2 className="w-4 h-4 text-blue-500 animate-spin" />
                    : <Icon className="w-4 h-4 text-gray-400" />}
                </div>
                <div className="flex-1">
                  <p className={`text-[14px] font-semibold ${done ? "text-green-700" : current ? "text-blue-700" : "text-gray-500"}`}>{label}</p>
                  <p className="text-[12px] text-gray-400">{desc}</p>
                </div>
                {done && (
                  <span className="text-[11px] font-semibold text-green-600 bg-green-50 border border-green-100 px-2.5 py-0.5 rounded-full">Done</span>
                )}
                {current && (
                  <span className="text-[11px] font-semibold text-blue-600 bg-blue-50 border border-blue-200 px-2.5 py-0.5 rounded-full">Running…</span>
                )}
              </div>
            );
          })}
        </div>

        {/* Result / action */}
        {stage === "idle" && (
          <button
            onClick={() => setStarted(true)}
            className="flex items-center gap-2 px-6 py-3 bg-blue-600 hover:bg-blue-700 text-white rounded-xl text-[15px] font-bold transition-colors shadow-sm"
          >
            Start Extraction
          </button>
        )}

        {stage === "done" && (
          <div className="bg-green-50 border border-green-200 rounded-2xl p-5 flex items-center gap-4">
            <CheckCircle2 className="w-8 h-8 text-green-500 shrink-0" />
            <div className="flex-1">
              <p className="text-[15px] font-bold text-green-800">Extraction Complete</p>
              <p className="text-[13px] text-green-700 mt-0.5">All PDFs processed. 6 layout blocks detected, 4 text blocks, 2 image blocks.</p>
            </div>
            <button
              onClick={() => navigate("/guardian")}
              className="flex items-center gap-2 px-5 py-2.5 bg-blue-600 hover:bg-blue-700 text-white rounded-xl text-[14px] font-bold transition-colors shrink-0"
            >
              Proceed <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        )}
      </div>
    </div>
  );
}