/**
 * ReviewImages.tsx — Step 4 of 4, Light SaaS theme
 * Clean white panels, blue accents, gray-50 background.
 */
import React, { useState, useEffect } from "react";
import { useNavigate } from "react-router";
import {
  Search, ChevronLeft, ChevronRight, SkipForward, Save,
  Check, StickyNote, Tag, AlertCircle, CheckCircle2, ZoomIn, ZoomOut, ArrowLeft,
} from "lucide-react";
import { useApp } from "../context/AppContext";

export function ReviewImages() {
  const { images, currentIndex, setCurrentIndex, annotations, saveAnnotation, attributes } = useApp();
  const navigate = useNavigate();

  const [searchQuery, setSearchQuery] = useState("");
  const [checkedAttrs, setCheckedAttrs] = useState<string[]>([]);
  const [missingAttrs, setMissingAttrs] = useState("");
  const [notes, setNotes] = useState("");
  const [savedFlash, setSavedFlash] = useState(false);
  const [previewZoom, setPreviewZoom] = useState(false);

  const currentImage = images[currentIndex] ?? null;
  const currentAnnotation = currentImage ? annotations[currentImage.id] : undefined;
  const reviewedCount = Object.keys(annotations).length;
  const totalImages = images.length;
  const pct = totalImages > 0 ? (reviewedCount / totalImages) * 100 : 0;
  const isEmpty = checkedAttrs.length === 0 && !missingAttrs && !notes;
  const filtered = attributes.filter((a) => a.name.toLowerCase().includes(searchQuery.toLowerCase()));

  useEffect(() => {
    if (currentAnnotation) {
      setCheckedAttrs(currentAnnotation.checkedAttributes);
      setMissingAttrs(currentAnnotation.missingAttributes);
      setNotes(currentAnnotation.notes);
    } else {
      setCheckedAttrs([]);
      setMissingAttrs("");
      setNotes("");
    }
    setSavedFlash(false);
  }, [currentIndex]);

  function toggleAttr(id: string) {
    setCheckedAttrs((p) => p.includes(id) ? p.filter((x) => x !== id) : [...p, id]);
  }

  function handleSave() {
    if (!currentImage) return;
    saveAnnotation({ imageId: currentImage.id, checkedAttributes: checkedAttrs, missingAttributes: missingAttrs, notes });
    setSavedFlash(true);
    setTimeout(() => setSavedFlash(false), 2000);
  }

  function handleSaveAndNext() {
    handleSave();
    if (currentIndex < images.length - 1) setTimeout(() => setCurrentIndex(currentIndex + 1), 100);
  }

  return (
    // h-full fills the <main> in Layout.tsx
    <div className="flex flex-col h-full bg-gray-50 font-sans overflow-hidden">

      {/* Sub-header */}
      <div className="bg-white border-b border-gray-200 px-6 shrink-0 flex items-center justify-between" style={{ height: 52 }}>
        <div className="flex items-center gap-3">
          <button
            onClick={() => navigate("/guardian")}
            className="flex items-center gap-1.5 text-[13px] font-semibold text-gray-500 hover:text-blue-600 transition-colors mr-2"
          >
            <ArrowLeft className="w-4 h-4" /> Guardian Audit
          </button>
          <span className="text-gray-200">|</span>
          <h2 className="text-[14px] font-bold text-gray-900">Image Review</h2>
          <span className="text-gray-300">|</span>
          <span className="text-[13px] text-gray-500">Annotate extracted Disney brand assets</span>
        </div>
        <div className="flex items-center gap-2 text-[12px] text-gray-500">
          <span className="font-bold text-blue-600">{reviewedCount}</span>
          <span>/ {totalImages} annotated</span>
          <div className="w-20 h-1.5 bg-gray-200 rounded-full overflow-hidden ml-2">
            <div className="h-full bg-blue-500 rounded-full transition-all" style={{ width: `${pct}%` }} />
          </div>
        </div>
      </div>

      {/* Three-column grid */}
      <div
        className="flex-1 overflow-hidden"
        style={{ display: "grid", gridTemplateColumns: "256px 1fr 360px", minHeight: 0 }}
      >
        {/* LEFT: image info + thumbs */}
        <div className="bg-white border-r border-gray-200 flex flex-col overflow-y-auto">
          <div className="p-5 border-b border-gray-100">
            <h3 className="text-[11px] font-bold uppercase tracking-widest text-blue-600 mb-3">Image Info</h3>
            {currentImage ? (
              <div className="space-y-3">
                <div>
                  <p className="text-[11px] text-gray-400 uppercase tracking-wider font-semibold">PDF Origin</p>
                  <p className="text-[12px] font-semibold text-gray-800 break-words leading-snug mt-0.5">{currentImage.pdfName}</p>
                </div>
                <div>
                  <p className="text-[11px] text-gray-400 uppercase tracking-wider font-semibold">Page</p>
                  <p className="text-[13px] font-bold text-gray-800 mt-0.5">Page {currentImage.pageNumber}</p>
                </div>
                <div>
                  <p className="text-[11px] text-gray-400 uppercase tracking-wider font-semibold">Asset ID</p>
                  <p className="text-[12px] font-mono text-blue-600 mt-0.5">{currentImage.id}</p>
                </div>
                <div>
                  <p className="text-[11px] text-gray-400 uppercase tracking-wider font-semibold">Status</p>
                  <div className="mt-1">
                    {currentAnnotation ? (
                      <span className="inline-flex items-center gap-1 text-[11px] font-semibold text-green-700 bg-green-50 border border-green-100 px-2.5 py-0.5 rounded-full">
                        <Check className="w-3 h-3" /> Annotated
                      </span>
                    ) : (
                      <span className="inline-flex items-center gap-1 text-[11px] font-semibold text-amber-600 bg-amber-50 border border-amber-100 px-2.5 py-0.5 rounded-full">
                        <AlertCircle className="w-3 h-3" /> Pending
                      </span>
                    )}
                  </div>
                </div>
              </div>
            ) : (
              <p className="text-[13px] text-gray-400 italic">No image selected</p>
            )}
          </div>

          {/* Navigation */}
          <div className="p-5 flex-1">
            <h3 className="text-[11px] font-bold uppercase tracking-widest text-blue-600 mb-3">Queue Navigation</h3>
            <div className="grid grid-cols-3 gap-1.5 mb-3">
              {[
                { onClick: () => currentIndex > 0 && setCurrentIndex(currentIndex - 1), disabled: currentIndex === 0, icon: ChevronLeft },
                { onClick: () => currentIndex < images.length - 1 && setCurrentIndex(currentIndex + 1), disabled: currentIndex >= images.length - 1, icon: SkipForward },
                { onClick: () => currentIndex < images.length - 1 && setCurrentIndex(currentIndex + 1), disabled: currentIndex >= images.length - 1, icon: ChevronRight },
              ].map(({ onClick, disabled, icon: Icon }, i) => (
                <button key={i} onClick={onClick} disabled={disabled}
                  className="flex items-center justify-center p-2 rounded-lg border border-gray-200 text-gray-500 hover:bg-gray-50 disabled:opacity-30 disabled:cursor-not-allowed transition-colors">
                  <Icon className="w-4 h-4" />
                </button>
              ))}
            </div>
            <p className="text-[12px] text-gray-400 text-center mb-4 font-medium">{currentIndex + 1} / {totalImages}</p>

            {/* Thumbnails */}
            <div className="space-y-1.5">
              {images.map((img, i) => (
                <button key={img.id} onClick={() => setCurrentIndex(i)}
                  className={`w-full flex items-center gap-3 p-2.5 rounded-xl border transition-all ${
                    i === currentIndex
                      ? "border-blue-200 bg-blue-50"
                      : "border-gray-100 hover:bg-gray-50 opacity-70 hover:opacity-100"
                  }`}
                >
                  <div className="w-10 h-8 rounded-lg border border-gray-200 overflow-hidden shrink-0 bg-gray-100">
                    <img src={img.thumbUrl} alt="" className="w-full h-full object-cover" onError={(e) => { (e.target as HTMLImageElement).style.display = "none"; }} />
                  </div>
                  <div className="text-left min-w-0">
                    <p className={`text-[11px] font-bold truncate ${i === currentIndex ? "text-blue-700" : "text-gray-700"}`}>{img.id}</p>
                    <p className="text-[10px] text-gray-400">Pg {img.pageNumber}</p>
                  </div>
                  {annotations[img.id] && <CheckCircle2 className="w-3.5 h-3.5 text-green-500 shrink-0 ml-auto" />}
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* CENTER: image preview */}
        <div className="relative bg-gray-100 overflow-hidden">
          <div className="absolute inset-0 flex items-center justify-center p-8">
            {currentImage ? (
              <div className={`relative overflow-hidden rounded-2xl border border-gray-200 shadow-lg transition-transform duration-300 ${previewZoom ? "scale-110" : "scale-100"}`}
                style={{ maxWidth: "90%", maxHeight: "90%" }}>
                <img
                  src={currentImage.imageUrl}
                  alt={currentImage.id}
                  className="block max-w-full object-contain"
                  style={{ maxHeight: "calc(100vh - 280px)", minHeight: 200 }}
                  onError={(e) => {
                    (e.target as HTMLImageElement).src = "data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='400' height='300'%3E%3Crect fill='%23f3f4f6' width='400' height='300'/%3E%3Ctext fill='%239ca3af' x='50%25' y='50%25' text-anchor='middle' font-family='sans-serif' font-size='14'%3EImage unavailable%3C/text%3E%3C/svg%3E";
                  }}
                />
                {/* Footer overlay */}
                <div className="absolute bottom-0 left-0 right-0 bg-white/90 backdrop-blur px-4 py-2.5 border-t border-gray-200">
                  <p className="text-[11px] text-gray-500 font-mono truncate">{currentImage.pdfName}</p>
                  <p className="text-[10px] font-bold text-blue-600">{currentImage.blockType ?? "IMAGE"} · Page {currentImage.pageNumber}</p>
                </div>
                <button onClick={() => setPreviewZoom(!previewZoom)}
                  className="absolute top-3 right-3 w-8 h-8 bg-white border border-gray-200 shadow rounded-lg flex items-center justify-center text-gray-500 hover:text-gray-900 transition-all">
                  {previewZoom ? <ZoomOut className="w-4 h-4" /> : <ZoomIn className="w-4 h-4" />}
                </button>
              </div>
            ) : (
              <div className="text-center text-gray-400">
                <AlertCircle className="w-12 h-12 mx-auto mb-3 opacity-40" />
                <p className="text-[15px] font-semibold text-gray-500">No image selected</p>
              </div>
            )}
          </div>
        </div>

        {/* RIGHT: annotations */}
        <div className="bg-white border-l border-gray-200 flex flex-col overflow-hidden">
          {/* Header */}
          <div className="px-5 py-4 border-b border-gray-100 flex items-center justify-between shrink-0">
            <div>
              <div className="flex items-center gap-2">
                <Tag className="w-4 h-4 text-blue-500" />
                <h3 className="text-[14px] font-bold text-gray-900">Property Annotations</h3>
              </div>
              <p className="text-[12px] text-gray-400 mt-0.5">
                {isEmpty ? "No attributes selected" : `${checkedAttrs.length} attribute${checkedAttrs.length !== 1 ? "s" : ""} selected`}
              </p>
            </div>
            {currentAnnotation && (
              <span className="inline-flex items-center gap-1 text-[11px] font-semibold text-green-700 bg-green-50 border border-green-100 px-2.5 py-1 rounded-full">
                <CheckCircle2 className="w-3 h-3" /> Saved
              </span>
            )}
          </div>

          {/* Scrollable list */}
          <div className="flex-1 overflow-y-auto">
            {/* Search */}
            <div className="px-4 pt-4 pb-2">
              <div className="flex items-center gap-2 px-3 py-2 border border-gray-200 rounded-lg bg-gray-50">
                <Search className="w-4 h-4 text-gray-400 shrink-0" />
                <input type="text" placeholder="Filter properties…" value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="flex-1 bg-transparent text-[13px] text-gray-700 placeholder-gray-400 outline-none" />
              </div>
            </div>

            <div className="px-4 pb-2 pt-1">
              <p className="text-[10px] font-bold uppercase tracking-widest text-blue-600">Canonical Model Graph</p>
            </div>

            {/* Attributes */}
            <div className="px-4 space-y-1 pb-4">
              {filtered.map((attr) => {
                const checked = checkedAttrs.includes(attr.id);
                return (
                  <label key={attr.id}
                    className={`flex items-start gap-3 p-2.5 rounded-xl cursor-pointer transition-all border ${
                      checked ? "bg-blue-50 border-blue-100" : "bg-transparent border-transparent hover:bg-gray-50"
                    }`}
                  >
                    <div
                      className={`w-4 h-4 mt-0.5 rounded border-2 flex items-center justify-center shrink-0 transition-all ${
                        checked ? "bg-blue-600 border-blue-600" : "border-gray-300 bg-white"
                      }`}
                      onClick={() => toggleAttr(attr.id)}
                    >
                      {checked && <Check className="w-2.5 h-2.5 text-white" />}
                    </div>
                    <div className="flex-1 min-w-0" onClick={() => toggleAttr(attr.id)}>
                      <p className={`text-[13px] font-semibold ${checked ? "text-blue-700" : "text-gray-700"}`}>{attr.name}</p>
                      <p className="text-[11px] text-gray-400 line-clamp-1">{attr.description}</p>
                    </div>
                    <span className={`text-[9px] font-bold uppercase tracking-wider px-1.5 py-0.5 rounded shrink-0 mt-0.5 ${
                      checked ? "bg-blue-100 text-blue-600" : "bg-gray-100 text-gray-400"
                    }`}>{attr.type}</span>
                  </label>
                );
              })}
            </div>

            {/* Custom attrs */}
            <div className="px-4 border-t border-gray-100 pt-4 pb-4">
              <label className="block text-[10px] font-bold uppercase tracking-widest text-blue-600 mb-2">Out-of-Schema Properties</label>
              <textarea value={missingAttrs} onChange={(e) => setMissingAttrs(e.target.value)}
                placeholder="List unbound attributes, one per line…" rows={3}
                className="w-full px-3 py-2.5 bg-gray-50 border border-gray-200 rounded-xl text-[13px] text-gray-700 placeholder-gray-400 resize-none focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-400 transition-all font-mono" />
            </div>

            <div className="px-4 pb-6">
              <label className="flex items-center gap-1.5 text-[10px] font-bold uppercase tracking-widest text-blue-600 mb-2">
                <StickyNote className="w-3 h-3" /> Notes
              </label>
              <textarea value={notes} onChange={(e) => setNotes(e.target.value)}
                placeholder="Optional notes…" rows={3}
                className="w-full px-3 py-2.5 bg-gray-50 border border-gray-200 rounded-xl text-[13px] text-gray-700 placeholder-gray-400 resize-none focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-400 transition-all font-mono" />
            </div>
          </div>

          {/* Actions */}
          <div className="px-4 py-4 border-t border-gray-100 space-y-2 shrink-0">
            {savedFlash && (
              <div className="flex items-center gap-2 px-3 py-2 bg-green-50 border border-green-100 rounded-xl text-[13px] font-semibold text-green-700">
                <CheckCircle2 className="w-4 h-4" /> Annotation saved successfully.
              </div>
            )}
            <button onClick={handleSaveAndNext} disabled={!currentImage}
              className="w-full flex items-center justify-center gap-2 px-4 py-3 bg-blue-600 text-white rounded-xl text-[14px] font-bold hover:bg-blue-700 disabled:opacity-40 disabled:cursor-not-allowed transition-colors">
              <Save className="w-4 h-4" /> Save and Next
            </button>
            <div className="flex gap-2">
              <button onClick={handleSave} disabled={!currentImage}
                className="flex-1 flex items-center justify-center gap-1.5 px-3 py-2.5 border border-gray-200 rounded-xl text-[12px] font-semibold text-gray-600 bg-white hover:bg-gray-50 disabled:opacity-40 transition-colors">
                <Save className="w-3.5 h-3.5" /> Save
              </button>
              <button onClick={() => currentIndex < images.length - 1 && setCurrentIndex(currentIndex + 1)}
                disabled={currentIndex >= images.length - 1}
                className="flex-1 flex items-center justify-center gap-1.5 px-3 py-2.5 border border-gray-200 rounded-xl text-[12px] font-semibold text-gray-600 bg-white hover:bg-gray-50 disabled:opacity-40 transition-colors">
                <SkipForward className="w-3.5 h-3.5" /> Skip
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
